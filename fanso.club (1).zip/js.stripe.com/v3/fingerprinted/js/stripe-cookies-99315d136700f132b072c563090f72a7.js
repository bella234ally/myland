"use strict";
(window.webpackChunkStripeJSinner = window.webpackChunkStripeJSinner || []).push([
    [3422], {
        67581: function(e, t, i) {
            function r(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && n(e, t)
            }

            function n(e, t) {
                return (n = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }

            function o(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var i, r = s(e);
                    if (t) {
                        var n = s(this).constructor;
                        i = Reflect.construct(r, arguments, n)
                    } else i = r.apply(this, arguments);
                    return a(this, i)
                }
            }

            function a(e, t) {
                if (t && ("object" === g(t) || "function" == typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return function(e) {
                    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return e
                }(e)
            }

            function s(e) {
                return (s = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                })(e)
            }

            function c(e, t) {
                var i = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (!i) {
                    if (Array.isArray(e) || (i = h(e)) || t && e && "number" == typeof e.length) {
                        i && (e = i);
                        var r = 0,
                            n = function() {};
                        return {
                            s: n,
                            n: function() {
                                return r >= e.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: e[r++]
                                }
                            },
                            e: function(e) {
                                throw e
                            },
                            f: n
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                var o, a = !0,
                    s = !1;
                return {
                    s: function() {
                        i = i.call(e)
                    },
                    n: function() {
                        var e = i.next();
                        return a = e.done, e
                    },
                    e: function(e) {
                        s = !0, o = e
                    },
                    f: function() {
                        try {
                            a || null == i.return || i.return()
                        } finally {
                            if (s) throw o
                        }
                    }
                }
            }

            function l() {
                function e(e, t, i) {
                    return Object.defineProperty(e, t, {
                        value: i,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }

                function t(e, t, i, n) {
                    var o = t && t.prototype instanceof r ? t : r,
                        a = Object.create(o.prototype),
                        s = new f(n || []);
                    return _(a, "_invoke", {
                        value: c(e, i, s)
                    }), a
                }

                function i(e, t, i) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, i)
                        }
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        }
                    }
                }

                function r() {}

                function n() {}

                function o() {}

                function a(t) {
                    ["next", "throw", "return"].forEach((function(i) {
                        e(t, i, (function(e) {
                            return this._invoke(i, e)
                        }))
                    }))
                }

                function s(e, t) {
                    var r;
                    _(this, "_invoke", {
                        value: function(n, o) {
                            function a() {
                                return new t((function(r, a) {
                                    ! function r(n, o, a, s) {
                                        var c = i(e[n], e, o);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                m = l.value;
                                            return m && "object" == g(m) && k.call(m, "__await") ? t.resolve(m.__await).then((function(e) {
                                                r("next", e, a, s)
                                            }), (function(e) {
                                                r("throw", e, a, s)
                                            })) : t.resolve(m).then((function(e) {
                                                l.value = e, a(l)
                                            }), (function(e) {
                                                return r("throw", e, a, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(n, o, r, a)
                                }))
                            }
                            return r = r ? r.then(a, a) : a()
                        }
                    })
                }

                function c(e, t, r) {
                    var n = "suspendedStart";
                    return function(o, a) {
                        if ("executing" === n) throw new Error("Generator is already running");
                        if ("completed" === n) {
                            if ("throw" === o) throw a;
                            return {
                                value: void 0,
                                done: !0
                            }
                        }
                        for (r.method = o, r.arg = a;;) {
                            var s = r.delegate;
                            if (s) {
                                var c = m(s, r);
                                if (c) {
                                    if (c === L) continue;
                                    return c
                                }
                            }
                            if ("next" === r.method) r.sent = r._sent = r.arg;
                            else if ("throw" === r.method) {
                                if ("suspendedStart" === n) throw n = "completed", r.arg;
                                r.dispatchException(r.arg)
                            } else "return" === r.method && r.abrupt("return", r.arg);
                            n = "executing";
                            var l = i(e, t, r);
                            if ("normal" === l.type) {
                                if (n = r.done ? "completed" : "suspendedYield", l.arg === L) continue;
                                return {
                                    value: l.arg,
                                    done: r.done
                                }
                            }
                            "throw" === l.type && (n = "completed", r.method = "throw", r.arg = l.arg)
                        }
                    }
                }

                function m(e, t) {
                    var r = t.method,
                        n = e.iterator[r];
                    if (void 0 === n) return t.delegate = null, "throw" === r && e.iterator.return && (t.method = "return", t.arg = void 0, m(e, t), "throw" === t.method) || "return" !== r && (t.method = "throw", t.arg = new TypeError("The iterator does not provide a '" + r + "' method")), L;
                    var o = i(n, e.iterator, t.arg);
                    if ("throw" === o.type) return t.method = "throw", t.arg = o.arg, t.delegate = null, L;
                    var a = o.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, L) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, L)
                }

                function u(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function p(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function f(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(u, this), this.reset(!0)
                }

                function d(e) {
                    if (e) {
                        var t = e[S];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var i = -1,
                                r = function t() {
                                    for (; ++i < e.length;)
                                        if (k.call(e, i)) return t.value = e[i], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return r.next = r
                        }
                    }
                    return {
                        next: h
                    }
                }

                function h() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                l = function() {
                    return y
                };
                var y = {},
                    v = Object.prototype,
                    k = v.hasOwnProperty,
                    _ = Object.defineProperty || function(e, t, i) {
                        e[t] = i.value
                    },
                    b = "function" == typeof Symbol ? Symbol : {},
                    S = b.iterator || "@@iterator",
                    x = b.asyncIterator || "@@asyncIterator",
                    w = b.toStringTag || "@@toStringTag";
                try {
                    e({}, "")
                } catch (y) {
                    e = function(e, t, i) {
                        return e[t] = i
                    }
                }
                y.wrap = t;
                var L = {},
                    E = {};
                e(E, S, (function() {
                    return this
                }));
                var A = Object.getPrototypeOf,
                    C = A && A(A(d([])));
                C && C !== v && k.call(C, S) && (E = C);
                var j = o.prototype = r.prototype = Object.create(E);
                return n.prototype = o, _(j, "constructor", {
                    value: o,
                    configurable: !0
                }), _(o, "constructor", {
                    value: n,
                    configurable: !0
                }), n.displayName = e(o, w, "GeneratorFunction"), y.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === n || "GeneratorFunction" === (t.displayName || t.name))
                }, y.mark = function(t) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(t, o) : (t.__proto__ = o, e(t, w, "GeneratorFunction")), t.prototype = Object.create(j), t
                }, y.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, a(s.prototype), e(s.prototype, x, (function() {
                    return this
                })), y.AsyncIterator = s, y.async = function(e, i, r, n, o) {
                    void 0 === o && (o = O);
                    var a = new s(t(e, i, r, n), o);
                    return y.isGeneratorFunction(i) ? a : a.next().then((function(e) {
                        return e.done ? e.value : a.next()
                    }))
                }, a(j), e(j, w, "Generator"), e(j, S, (function() {
                    return this
                })), e(j, "toString", (function() {
                    return "[object Generator]"
                })), y.keys = function(e) {
                    var t = Object(e),
                        i = [];
                    for (var r in t) i.push(r);
                    return i.reverse(),
                        function e() {
                            for (; i.length;) {
                                var r = i.pop();
                                if (r in t) return e.value = r, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, y.values = d, f.prototype = {
                    constructor: f,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(p), !e)
                            for (var t in this) "t" === t.charAt(0) && k.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        function t(t, r) {
                            return o.type = "throw", o.arg = e, i.next = t, r && (i.method = "next", i.arg = void 0), !!r
                        }
                        if (this.done) throw e;
                        for (var i = this, r = this.tryEntries.length - 1; r >= 0; --r) {
                            var n = this.tryEntries[r],
                                o = n.completion;
                            if ("root" === n.tryLoc) return t("end");
                            if (n.tryLoc <= this.prev) {
                                var a = k.call(n, "catchLoc"),
                                    s = k.call(n, "finallyLoc");
                                if (a && s) {
                                    if (this.prev < n.catchLoc) return t(n.catchLoc, !0);
                                    if (this.prev < n.finallyLoc) return t(n.finallyLoc)
                                } else if (a) {
                                    if (this.prev < n.catchLoc) return t(n.catchLoc, !0)
                                } else {
                                    if (!s) throw new Error("try statement without catch or finally");
                                    if (this.prev < n.finallyLoc) return t(n.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
                            var r = this.tryEntries[i];
                            if (r.tryLoc <= this.prev && k.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                                var n = r;
                                break
                            }
                        }
                        n && ("break" === e || "continue" === e) && n.tryLoc <= t && t <= n.finallyLoc && (n = null);
                        var o = n ? n.completion : {};
                        return o.type = e, o.arg = t, n ? (this.method = "next", this.next = n.finallyLoc, L) : this.complete(o)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), L
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var i = this.tryEntries[t];
                            if (i.finallyLoc === e) return this.complete(i.completion, i.afterLoc), p(i), L
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var i = this.tryEntries[t];
                            if (i.tryLoc === e) {
                                var r = i.completion;
                                if ("throw" === r.type) {
                                    var n = r.arg;
                                    p(i)
                                }
                                return n
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, i) {
                        return this.delegate = {
                            iterator: d(e),
                            resultName: t,
                            nextLoc: i
                        }, "next" === this.method && (this.arg = void 0), L
                    }
                }, y
            }

            function m(e) {
                return function(e) {
                    if (Array.isArray(e)) return y(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                }(e) || h(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function u(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }

            function p(e, t) {
                for (var i = 0; i < t.length; i++) {
                    var r = t[i];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, (void 0, n = function(e, t) {
                        if ("object" !== g(e) || null === e) return e;
                        var i = e[Symbol.toPrimitive];
                        if (void 0 !== i) {
                            var r = i.call(e, t);
                            if ("object" !== g(r)) return r;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return String(e)
                    }(r.key, "string"), "symbol" === g(n) ? n : String(n)), r)
                }
                var n
            }

            function f(e, t, i) {
                return t && p(e.prototype, t), i && p(e, i), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), e
            }

            function d(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var i = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != i) {
                        var r, n, o, a, s = [],
                            c = !0,
                            l = !1;
                        try {
                            if (o = (i = i.call(e)).next, 0 === t) {
                                if (Object(i) !== i) return;
                                c = !1
                            } else
                                for (; !(c = (r = o.call(i)).done) && (s.push(r.value), s.length !== t); c = !0);
                        } catch (e) {
                            l = !0, n = e
                        } finally {
                            try {
                                if (!c && null != i.return && (a = i.return(), Object(a) !== a)) return
                            } finally {
                                if (l) throw n
                            }
                        }
                        return s
                    }
                }(e, t) || h(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function h(e, t) {
                if (e) {
                    if ("string" == typeof e) return y(e, t);
                    var i = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === i && e.constructor && (i = e.constructor.name), "Map" === i || "Set" === i ? Array.from(e) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? y(e, t) : void 0
                }
            }

            function y(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var i = 0, r = new Array(t); i < t; i++) r[i] = e[i];
                return r
            }

            function g(e) {
                return (g = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function v(e, t, i, r) {
                return new(i || (i = O))((function(n, o) {
                    function a(e) {
                        try {
                            c(r.next(e))
                        } catch (e) {
                            o(e)
                        }
                    }

                    function s(e) {
                        try {
                            c(r.throw(e))
                        } catch (e) {
                            o(e)
                        }
                    }

                    function c(e) {
                        var t;
                        e.done ? n(e.value) : (t = e.value, t instanceof i ? t : new i((function(e) {
                            e(t)
                        }))).then(a, s)
                    }
                    c((r = r.apply(e, t || [])).next())
                }))
            }

            function k(e) {
                if (!A) return !1;
                var t;
                try {
                    t = window[e];
                    var i = "__storage_test__";
                    return t.setItem(i, i), t.removeItem(i), !0
                } catch (e) {
                    return !(!(e instanceof DOMException) || 22 !== e.code && 1014 !== e.code && "QuotaExceededError" !== e.name && "NS_ERROR_DOM_QUOTA_REACHED" !== e.name || !t || 0 === t.length)
                }
            }

            function _(e) {
                return "string" == typeof e && !!e.trim()
            }

            function b(e, t) {
                var i = e.split(";").filter(_),
                    r = i.shift().split("="),
                    n = r.shift(),
                    o = r.join("=");
                t = t ? (0, w.A)({}, K, t) : K;
                try {
                    o = t.decodeValues ? decodeURIComponent(o) : o
                } catch (e) {
                    console.error("set-cookie-parser encountered an error while decoding a cookie with value '" + o + "'. Set options.decodeValues to false to disable this feature.", e)
                }
                var a = {
                    name: n,
                    value: o
                };
                return i.forEach((function(e) {
                    var t = e.split("="),
                        i = t.shift().trimLeft().toLowerCase(),
                        r = t.join("=");
                    "expires" === i ? a.expires = new Date(r) : "max-age" === i ? a.maxAge = parseInt(r, 10) : "secure" === i ? a.secure = !0 : "httponly" === i ? a.httpOnly = !0 : "samesite" === i ? a.sameSite = r : a[i] = r
                })), a
            }

            function S(e, t) {
                if (t = t ? (0, w.A)({}, K, t) : K, !e) return t.map ? {} : [];
                if (e.headers && e.headers["set-cookie"]) e = e.headers["set-cookie"];
                else if (e.headers) {
                    var i = e.headers[Object.keys(e.headers).find((function(e) {
                        return "set-cookie" === e.toLowerCase()
                    }))];
                    i || !e.headers.cookie || t.silent || console.warn("Warning: set-cookie-parser appears to have been called on a request object. It is designed to parse Set-Cookie headers from responses, not Cookie headers from requests. Set the option {silent: true} to suppress this warning."), e = i
                }
                return Array.isArray(e) || (e = [e]), (t = t ? (0, w.A)({}, K, t) : K).map ? e.filter(_).reduce((function(e, i) {
                    var r = b(i, t);
                    return e[r.name] = r, e
                }), {}) : e.filter(_).map((function(e) {
                    return b(e, t)
                }))
            }
            i.r(t), i.d(t, {
                COOKIE_POLICY_URL: function() {
                    return de
                },
                COOKIE_SETTINGS_PAGE_URL: function() {
                    return fe
                },
                Categories: function() {
                    return L
                },
                Cookies: function() {
                    return ee
                },
                ENFORCEMENT_MODE_URL: function() {
                    return he
                },
                LocalStorage: function() {
                    return ae
                },
                PERMISSIONS_COOKIE_NAME: function() {
                    return H
                },
                Permissions: function() {
                    return D
                },
                SessionStorage: function() {
                    return pe
                }
            });
            var x, w = i(13252),
                O = i(61776).K7,
                L = {
                    authentication: {
                        necessary: !0
                    },
                    "fraud-prevention": {
                        necessary: !0
                    },
                    security: {
                        necessary: !0
                    },
                    functionality: {
                        necessary: !0
                    },
                    preferences: {
                        necessary: !1,
                        token: "p"
                    },
                    statistics: {
                        necessary: !1,
                        token: "s"
                    },
                    advertising: {
                        necessary: !1,
                        token: "a"
                    },
                    essential: {
                        necessary: !0
                    },
                    functional: {
                        necessary: !1,
                        token: "f"
                    }
                },
                E = function(e, t, i) {
                    return function(e) {
                        var t;
                        t = function() {
                            function e() {
                                for (var e = 0, t = {}; e < arguments.length; e++) {
                                    var i = arguments[e];
                                    for (var r in i) t[r] = i[r]
                                }
                                return t
                            }

                            function t(e) {
                                return e.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent)
                            }
                            return function i(r) {
                                function n() {}

                                function o(t, i, o) {
                                    if ("undefined" != typeof document) {
                                        "number" == typeof(o = e({
                                            path: "/"
                                        }, n.defaults, o)).expires && (o.expires = new Date(1 * new Date + 864e5 * o.expires)), o.expires = o.expires ? o.expires.toUTCString() : "";
                                        try {
                                            var a = JSON.stringify(i);
                                            /^[\{\[]/.test(a) && (i = a)
                                        } catch (e) {}
                                        i = r.write ? r.write(i, t) : encodeURIComponent(String(i)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent), t = encodeURIComponent(String(t)).replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent).replace(/[\(\)]/g, escape);
                                        var s = "";
                                        for (var c in o) o[c] && (s += "; " + c, !0 !== o[c] && (s += "=" + o[c].split(";")[0]));
                                        return document.cookie = t + "=" + i + s
                                    }
                                }

                                function a(e, i) {
                                    if ("undefined" != typeof document) {
                                        for (var n = {}, o = document.cookie ? document.cookie.split("; ") : [], a = 0; a < o.length; a++) {
                                            var s = o[a].split("="),
                                                c = s.slice(1).join("=");
                                            i || '"' !== c.charAt(0) || (c = c.slice(1, -1));
                                            try {
                                                var l = t(s[0]);
                                                if (c = (r.read || r)(c, l) || t(c), i) try {
                                                    c = JSON.parse(c)
                                                } catch (e) {}
                                                if (n[l] = c, e === l) break
                                            } catch (e) {}
                                        }
                                        return e ? n[e] : n
                                    }
                                }
                                return n.set = o, n.get = function(e) {
                                    return a(e, !1)
                                }, n.getJSON = function(e) {
                                    return a(e, !0)
                                }, n.remove = function(t, i) {
                                    o(t, "", e(i, {
                                        expires: -1
                                    }))
                                }, n.defaults = {}, n.withConverter = i, n
                            }((function() {}))
                        }, e.exports = t()
                    }(i = {
                        path: void 0,
                        exports: {},
                        require: function(e, t) {
                            return function() {
                                throw new Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs")
                            }(null == t && i.path)
                        }
                    }, i.exports), i.exports
                }(),
                A = function() {
                    try {
                        return !!window
                    } catch (e) {
                        return !1
                    }
                }() && "object" === ("undefined" == typeof window ? "undefined" : g(window)) && "object" === ("undefined" == typeof document ? "undefined" : g(document)) && 9 === document.nodeType,
                C = function(e, t) {
                    return !!t && (e === t || 0 !== t.length && "." === t[0] && (t === ".".concat(e) || e.length > t.length && e.endsWith(t)))
                },
                j = function(e) {
                    return !!(e.match(/(\.)?link.com?\//i) || e.match("mkt-mydev.dev.stripe.me") && e.match("host=link") || e.match("-mkt.tunnel.stripe.me") && e.match("host=link") || e.match(/mkt(\.qa)?\.corp\.stripe\.com/i) && e.match("host=link") || e.match("link_app-mydev.dev.stripe.me") || e.match("link_support_site-mydev.dev.stripe.com"))
                },
                I = A && (x = window.location.hostname, ["stripe.com", "stripe.dev", "stripe.global", "stripe.partners", "increment.com", "link.co", "link.com"].some((function(e) {
                    var t = "(^|.)".concat(e.replace(/\./g, "\\."), "$");
                    return new RegExp(t).test(x)
                }))),
                P = "[stripe-cookies]",
                M = function(e) {
                    if (!I) {
                        for (var t, i = arguments.length, r = new Array(i > 1 ? i - 1 : 0), n = 1; n < i; n++) r[n - 1] = arguments[n];
                        (t = console).warn.apply(t, ["".concat(P, " ").concat(e)].concat(r))
                    }
                },
                R = function(e) {
                    if (!I) {
                        for (var t, i = arguments.length, r = new Array(i > 1 ? i - 1 : 0), n = 1; n < i; n++) r[n - 1] = arguments[n];
                        (t = console).error.apply(t, ["".concat(P, " ").concat(e)].concat(r))
                    }
                },
                N = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : A ? window.location.href : "";
                    return j(e) ? e.match(/(\.)?link.co([^m]|\b)/i) ? "https://link.co" : "https://link.com" : "https://stripe.com"
                },
                q = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : A ? window.location.href : "",
                        i = N(t) + e;
                    if (!A || !window.URL || !window.URLSearchParams) return i;
                    var r = new URL(t),
                        n = new URL(i);
                    if (r.hostname.match("-mydev.dev.stripe.me") || r.hostname.match("-stripejs.tunnel.stripe.me")) {
                        var o, a = r.hostname.split(".", 1),
                            s = d(a, 1),
                            c = s[0];
                        if (c.split("--", 1)[0] !== c) {
                            var l = c.split("--", 1),
                                m = d(l, 1);
                            o = m[0], o += "-"
                        } else {
                            var u = c.split("-", 1),
                                p = d(u, 1);
                            o = p[0]
                        }
                        return n.hostname = "".concat(o, "-mkt-mydev.dev.stripe.me"), c.includes("manage-dashboard-proxy-mydev") ? n.hostname = "stripe.com" : c.includes("manage-qa-dashboard-proxy-mydev") && (n.hostname = "qa.stripe.com"), i.includes("link.co") && (n.search = new URLSearchParams({
                            $host: "link"
                        }).toString()), n.toString()
                    }
                    return r.hostname.match(/(^|-)(dev|iso|corpiso|corpdev)\.dev\.stripe\.me$/) ? i.replace("stripe.com", r.hostname) : r.hostname.match(/(^|\.)qa\.stripe\.com$/) || r.hostname.match(/(^|\.)(link|admin)\.qa\.corp\.stripe\.com$/) || r.hostname.match(/(^|\.)qa-dashboard\.stripe\.com$/) ? i.replace("stripe.com", "qa.stripe.com") : r.hostname.match(/(^|\.)preprod\.stripe\.com$/) || r.hostname.match(/(^|\.)(link|admin)\.preprod\.corp\.stripe\.com$/) || r.hostname.match(/(^|\.)preprod-dashboard\.stripe\.com$/) ? i.replace("stripe.com", "preprod.stripe.com") : r.hostname.match(/(^|\.)qa\.link\.co$/) || r.hostname.match(/(^|\.)qa-app\.stripe\.co$/) ? i.replace("link.co", "qa.link.co") : r.hostname.match(/(^|\.)qa\.link\.com$/) || r.hostname.match(/(^|\.)qa-app\.link\.com$/) ? i.replace("link.com", "qa.link.com") : r.hostname.match(/(^|\.)preprod\.link\.co$/) || r.hostname.match(/(^|\.)preprod-app\.stripe\.co$/) ? i.replace("link.co", "preprod.link.co") : r.hostname.match(/(^|\.)preprod\.link\.com$/) || r.hostname.match(/(^|\.)preprod-app\.link\.com$/) ? i.replace("link.com", "preprod.link.com") : r.hostname.match(/mkt(\.qa)?\.corp\.stripe\.com/i) || r.hostname.match("-mkt.tunnel.stripe.me") ? (n.hostname = r.hostname, i.includes("link.co") && (n.search = new URLSearchParams({
                        $host: "link"
                    }).toString()), n.toString()) : n.toString()
                },
                H = "cookie-perms",
                T = ["https://c.stripe.dev/cookie", "https://c.stripe.global/cookie", "https://c.stripe.partners/cookie", "https://c.increment.com/cookie"],
                U = Object.keys(L),
                D = function() {
                    function e(t, i, r) {
                        u(this, e), this._version = t, this._permissions = r, this._timestamp = i
                    }
                    return f(e, [{
                        key: "version",
                        get: function() {
                            return this._version
                        }
                    }, {
                        key: "timestamp",
                        get: function() {
                            return this._timestamp
                        }
                    }, {
                        key: "get",
                        value: function(e) {
                            return this._permissions[e]
                        }
                    }, {
                        key: "getAll",
                        value: function() {
                            return (0, w.A)({}, this._permissions)
                        }
                    }, {
                        key: "toString",
                        value: function() {
                            var e = this,
                                t = U.reduce((function(t, i) {
                                    var r = L[i];
                                    return r && !r.necessary && e._permissions[i] ? [].concat(m(t), [r.token]) : t
                                }), []).sort(),
                                i = Math.floor(this.timestamp.valueOf() / 1e3);
                            return "".concat(this._version, ":").concat(i, "|").concat(t.join(""))
                        }
                    }], [{
                        key: "deserialize",
                        value: function(t) {
                            var i = d(t.split(":", 2), 2),
                                r = i[0],
                                n = i[1].split("|"),
                                o = new Date(1e3 * Number(n[0])),
                                a = n[1].split("");
                            return new e(r, o, U.reduce((function(e, t) {
                                var i = L[t];
                                return i.necessary ? e[t] = !0 : i.token && (e[t] = a.indexOf(i.token) >= 0), e
                            }), {}))
                        }
                    }, {
                        key: "get",
                        value: function() {
                            try {
                                var t = E.get("cookie-perms");
                                if (t) return e.deserialize(t)
                            } catch (e) {}
                            return null
                        }
                    }, {
                        key: "set",
                        value: function(t) {
                            return v(this, void 0, void 0, l().mark((function i() {
                                var r, n, o = this;
                                return l().wrap((function(i) {
                                    for (;;) switch (i.prev = i.next) {
                                        case 0:
                                            if (r = function(e) {
                                                    return v(o, void 0, void 0, l().mark((function i() {
                                                        return l().wrap((function(i) {
                                                            for (;;) switch (i.prev = i.next) {
                                                                case 0:
                                                                    return i.prev = 0, i.next = 3, fetch(e, {
                                                                        method: "post",
                                                                        body: JSON.stringify(t),
                                                                        credentials: "include",
                                                                        headers: {
                                                                            "Content-Type": "application/json",
                                                                            "X-Requested-With": "cookies"
                                                                        }
                                                                    });
                                                                case 3:
                                                                    return i.abrupt("return", i.sent);
                                                                case 6:
                                                                    i.prev = 6, i.t0 = i.catch(0), i.t0 instanceof Error ? R(i.t0.message) : R("Unexpected error", i.t0);
                                                                case 9:
                                                                case "end":
                                                                    return i.stop()
                                                            }
                                                        }), i, null, [
                                                            [0, 6]
                                                        ])
                                                    })))
                                                }, n = q("/cookie-settings/update"), !j(n)) {
                                                i.next = 7;
                                                break
                                            }
                                            return i.next = 5, r(n);
                                        case 5:
                                            i.next = 9;
                                            break;
                                        case 7:
                                            return i.next = 9, O.all([n].concat(T).map(r));
                                        case 9:
                                            return i.abrupt("return", e.get());
                                        case 10:
                                        case "end":
                                            return i.stop()
                                    }
                                }), i)
                            })))
                        }
                    }, {
                        key: "allowAll",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function t() {
                                var i;
                                return l().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return i = U.reduce((function(e, t) {
                                                return L[t].necessary || (e[t] = !0), e
                                            }), {}), t.abrupt("return", e.set(i));
                                        case 2:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))
                        }
                    }, {
                        key: "rejectAll",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function t() {
                                var i;
                                return l().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return i = U.reduce((function(e, t) {
                                                return L[t].necessary || (e[t] = !1), e
                                            }), {}), t.abrupt("return", e.set(i));
                                        case 2:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))
                        }
                    }]), e
                }(),
                $ = function() {
                    function e(t) {
                        u(this, e), this._getPermissions = t, this._callbacks = []
                    }
                    return f(e, [{
                        key: "addCallback",
                        value: function(e) {
                            this._callbacks.indexOf(e) >= 0 ? R("PermissionsWatcher.addCallback() was called for a function that was already registered with the PermissionsWatcher.") : (this._callbacks.push(e), this._interval || this._pollForPermissionsChanges())
                        }
                    }, {
                        key: "removeCallback",
                        value: function(e) {
                            var t = this._callbacks.indexOf(e);
                            t < 0 ? R("PermissionsWatcher.removeCallback() was called for a function that wasn't registered with the PermissionsWatcher.") : (this._callbacks.splice(t, 1), this._interval && 0 === this._callbacks.length && (clearInterval(this._interval), this._interval = null))
                        }
                    }, {
                        key: "_pollForPermissionsChanges",
                        value: function() {
                            var e = this,
                                t = this._getPermissions();
                            this._interval = setInterval((function() {
                                var i = e._getPermissions();
                                if (null !== i) {
                                    var r = null === t && null !== i,
                                        n = t && i && t.timestamp !== i.timestamp;
                                    (r || n) && e._callbacks.forEach((function(e) {
                                        return e(i)
                                    })), t = i
                                }
                            }), 100)
                        }
                    }]), e
                }(),
                G = null,
                F = function() {
                    function e(t) {
                        u(this, e), this._watcher = new $((function() {
                            return D.get()
                        })), t.enforcementMode && (this._enforcementModeValue = t.enforcementMode)
                    }
                    return f(e, [{
                        key: "getEnforcementMode",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", this.getEnforcementModeMaybeSync());
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })))
                        }
                    }, {
                        key: "getEnforcementModeMaybeSync",
                        value: function() {
                            var e = this;
                            if (!this._enforcementModeValue) {
                                var t = (G || (G = O.race([v(void 0, void 0, void 0, l().mark((function e() {
                                    var t, i, r, n;
                                    return l().wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return t = "restricted", e.prev = 1, e.next = 4, fetch(q("/cookie-settings/enforcement-mode"));
                                            case 4:
                                                return i = e.sent, e.next = 7, i.json();
                                            case 7:
                                                r = e.sent, "restricted" !== (n = r.mode) && "open" !== n && "functional" !== n || (t = n), e.next = 14;
                                                break;
                                            case 12:
                                                e.prev = 12, e.t0 = e.catch(1);
                                            case 14:
                                                return e.abrupt("return", t);
                                            case 15:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, null, [
                                        [1, 12]
                                    ])
                                }))), new O((function(e) {
                                    setTimeout((function() {
                                        return e("restricted")
                                    }), 1e3)
                                }))])), G);
                                t.then((function(t) {
                                    e._enforcementModeValue = t
                                })), this._enforcementModeValue = t
                            }
                            return this._enforcementModeValue
                        }
                    }, {
                        key: "getPermissions",
                        value: function() {
                            return D.get()
                        }
                    }, {
                        key: "setPermissions",
                        value: function(e) {
                            return v(this, void 0, void 0, l().mark((function t() {
                                return l().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.abrupt("return", D.set(e));
                                        case 1:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))
                        }
                    }, {
                        key: "allowAll",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", D.allowAll());
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }, {
                        key: "rejectAll",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", D.rejectAll());
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }, {
                        key: "isCategoryAllowed",
                        value: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                            return v(this, void 0, void 0, l().mark((function i() {
                                return l().wrap((function(i) {
                                    for (;;) switch (i.prev = i.next) {
                                        case 0:
                                            return i.abrupt("return", this.isCategoryAllowedMaybeSync(e, t));
                                        case 1:
                                        case "end":
                                            return i.stop()
                                    }
                                }), i, this)
                            })))
                        }
                    }, {
                        key: "isCategoryAllowedMaybeSync",
                        value: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                                i = D.get();
                            if (L[e].necessary) return !0;
                            if (!t && "advertising" === e && "undefined" != typeof navigator) {
                                var r = navigator;
                                if (null == r ? void 0 : r.globalPrivacyControl) return !1
                            }
                            if (i) return "1" === i.version && "functional" === e ? !!i.get("statistics") || !!i.get("preferences") : "2" !== i.version || "statistics" !== e && "preferences" !== e ? !!i.get(e) : !!i.get("functional");
                            var n = this.getEnforcementModeMaybeSync();
                            return "string" == typeof n ? "functional" === n ? "advertising" !== e : "restricted" !== n : n.then((function(t) {
                                return "functional" === t ? "advertising" !== e : "restricted" !== t
                            }))
                        }
                    }, {
                        key: "areCategoriesAllowed",
                        value: function() {
                            for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++) t[i] = arguments[i];
                            return v(this, void 0, void 0, l().mark((function e() {
                                var i, r, n;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            i = 0, r = t;
                                        case 1:
                                            if (!(i < r.length)) {
                                                e.next = 11;
                                                break
                                            }
                                            return n = r[i], e.next = 5, this.isCategoryAllowed(n);
                                        case 5:
                                            if (e.sent) {
                                                e.next = 8;
                                                break
                                            }
                                            return e.abrupt("return", !1);
                                        case 8:
                                            i++, e.next = 1;
                                            break;
                                        case 11:
                                            return e.abrupt("return", !0);
                                        case 12:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })))
                        }
                    }, {
                        key: "shouldShowBanner",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                var t;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (!this.getPermissions()) {
                                                e.next = 3;
                                                break
                                            }
                                            return e.abrupt("return", !1);
                                        case 3:
                                            return e.next = 5, this.getEnforcementMode();
                                        case 5:
                                            return t = e.sent, e.abrupt("return", "restricted" === t || "functional" === t);
                                        case 7:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })))
                        }
                    }, {
                        key: "watchPermissions",
                        value: function(e) {
                            this._watcher.addCallback(e)
                        }
                    }, {
                        key: "unwatchPermissions",
                        value: function(e) {
                            this._watcher.removeCallback(e)
                        }
                    }]), e
                }(),
                V = function() {
                    function e(t, i) {
                        u(this, e), this.name = t, this.category = i.category, this.lifetime = i.lifetime, this.domains = i.domains, this.secure = !(!1 === i.secure), this.httpOnly = !(!1 === i.httpOnly), this.sameSite = i.sameSite || "Lax", this.name.indexOf("*") >= 0 ? (this.inexact = !0, this._regexp = new RegExp(t.replace("*", ".+"))) : this.inexact = !1
                    }
                    return f(e, [{
                        key: "isMatch",
                        value: function(e) {
                            return this.name === e || this._regexp && this._regexp.test(e)
                        }
                    }, {
                        key: "resolveDomain",
                        value: function(e, t) {
                            if (!this.name.startsWith("__Host-")) {
                                var i = [];
                                this.domains && (i = this.domains.map((function(e) {
                                    return t[e] || e
                                })));
                                var r = e;
                                if (!r && A && (r = document.location.host), r && r.match("dev.stripe.me")) return ".dev.stripe.me";
                                if (r && !i.some((function(e) {
                                        return C(r, e)
                                    }))) throw new Error("The ".concat(this.name, " cookie is not allowed to be set on the ").concat(r, " domain."));
                                return r || i[0]
                            }
                        }
                    }, {
                        key: "resolveExpiry",
                        value: function(e) {
                            if ("forever" !== this.lifetime) {
                                if ("session" !== this.lifetime) {
                                    var t = this.lifetime || 0;
                                    if (e) {
                                        if (t < e) throw new Error("The ".concat(this.name, " cookie has a maximum lifetime of ").concat(this.lifetime, " seconds."));
                                        t = e
                                    }
                                    return new Date(Date.now() + 1e3 * t)
                                }
                                if (e) throw new Error("The ".concat(this.name, " cookie cannot have a lifetime, because it is a session cookie."))
                            }
                        }
                    }]), e
                }(),
                W = {
                    __stripe_mid: {
                        category: "essential",
                        domains: [".checkout.stripe.com", ".link.co", ".link.com", "request"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __stripe_orig_props: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    __stripe_sid: {
                        category: "essential",
                        domains: [".checkout.stripe.com", ".link.co", ".link.com", "request"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _cfduid: {
                        category: "advertising",
                        domains: [".stripecdn.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _fbp: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _forum_session: {
                        category: "authentication",
                        domains: [".discuss.stripe.community"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    _ga: {
                        category: "advertising",
                        domains: [".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "_ga*": {
                        category: "functional",
                        domains: [".stripe.com", ".stripe.events", ".go.stripe.global", ".link.co", ".link.com", ".portal.stripe.partners"],
                        lifetime: 5184e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _gat: {
                        category: "functional",
                        domains: [".stripe.com", ".stripe.events", ".go.stripe.global", ".portal.stripe.partners"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _gat_stripe_com: {
                        category: "functional",
                        domains: [".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "_gat_UA-12675062-5": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "_gat_UA-12675062-14": {
                        category: "functional",
                        domains: [".link.co", ".link.com"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "_gac_gb_G-SEKFWD1C9J": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global"],
                        lifetime: 5184e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _gcl_au: {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _gid: {
                        category: "functional",
                        domains: [".stripe.com", ".go.stripe.global", ".link.co", ".link.com", ".portal.stripe.partners"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _GRECAPTCHA: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    _guid: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _mkto_trk: {
                        category: "advertising",
                        domains: [".stripecdn.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _pxhd: {
                        category: "advertising",
                        domains: [".stripecdn.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _t: {
                        category: "authentication",
                        domains: [".discuss.stripe.community"],
                        lifetime: 5270400,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    aam_uuid: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    act_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "allow-unsupported-browser": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "AMCV_*": {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    AnalyticsSyncHistory: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    anonymous_overrides: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 1209600,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    ark_in_cad_opt_out: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    art_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    atlas_invite: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    bcookie: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    c_user: {
                        category: "advertising",
                        domains: [".clearbit.com", ".facebook.com", ".go.stripe.global", ".stripe.com", ".stripe.events"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    cbt_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com", "connect.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    eid: {
                        category: "functional",
                        domains: [".checkout.stripe.com"],
                        lifetime: 5270400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    cid: {
                        category: "functional",
                        domains: [".stripe.com", ".link.com", ".link.co"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-cliauth_token": {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 180,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "color-scheme": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    connect_locale: {
                        category: "essential",
                        domains: [".connect.stripe.com", ".express.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "cookie-perms": {
                        category: "essential",
                        domains: [".stripe.com", ".stripe.dev", ".go.stripe.global", ".increment.com", ".link.co", ".link.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    country: {
                        category: "essential",
                        domains: [".link.co", ".link.com", ".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    csv: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    datr: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    disable_cmd_f_override: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "docs.prefs": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    double_cmd_f_uses: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    dpr: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    edgebucket: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 39484800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    ev: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 5270400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "expanded-topics": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    fr: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-f-visitor-id": {
                        category: "essential",
                        domains: [".link.com", ".stripe.com", ".stripecdn.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    gh_src: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    GPS: {
                        category: "advertising",
                        domains: [".youtube.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    handoff: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 9e4,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    has_intentionally_selected_curl: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-has_recently_requested_netsuite_connector_*": {
                        category: "essential",
                        domains: ["marketplace.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-has_recently_requested_salesforce_cpq_connector_*": {
                        category: "essential",
                        domains: ["marketplace.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-has_recently_requested_sap_connector_*": {
                        category: "essential",
                        domains: ["marketplace.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    IDE: {
                        category: "advertising",
                        domains: [".doubleclick.net"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    invite: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    lang: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    lc_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    _ldbrbid: {
                        category: "advertising",
                        domains: [".line.me", ".stripe.com", ".go.stripe.global"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    li_oatml: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    li_sugr: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    liap: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    lidc: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-LinkSession": {
                        category: "authentication",
                        domains: ["checkout-cookies.stripe.com", "checkout-cookies.link.com", "merchant-ui-api.stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    "__Secure-LinkSessionPresent": {
                        category: "essential",
                        domains: [".stripe.com", ".link.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    "__Secure-HasLoggedIntoLinkApp": {
                        category: "essential",
                        domains: [".link.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    lissc: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    locale: {
                        category: "essential",
                        domains: [".link.co", ".link.com", ".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    loid: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    m: {
                        category: "essential",
                        domains: [".m.stripe.com"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-tz": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-ans_frontend_early_version": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-s": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-b_strict": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-b_lax": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-uid": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 57888e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-b": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    machine_identifier: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    merchant: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    over18: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 47347200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    pay_sid: {
                        category: "authentication",
                        domains: [".link.co", ".link.com", ".link.corp.stripe.com", ".link.qa.corp.stripe.com", ".link-support-site.corp.stripe.com", ".link-support-site.qa.corp.stripe.com", ".link-support-site.preprod.corp.stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    private_machine_identifier: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    prt_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "recent-views": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    recent_srs: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "saml_sca_success_for_*": {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 30,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    samlit_email: {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    samlit_token: {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    sb: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sca_migration_not_started_alert_actioned: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    scfc: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sdsc: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-sessions_on_demand_qualified": {
                        category: "essential",
                        domains: ["stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    session_tracker: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sp_adid: {
                        category: "advertising",
                        domains: ["spotify.com", "stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sp_landing: {
                        category: "advertising",
                        domains: ["spotify.com", "stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sp_t: {
                        category: "advertising",
                        domains: ["spotify.com", "stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-sid": {
                        category: "functional",
                        domains: [".stripe.com", ".link.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    token_v2: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-session": {
                        category: "authentication",
                        domains: ["support.stripe.com", "support-conversations.stripe.com", "stripe.com", "dashboard.stripe.com", "connect.stripe.com", "express.stripe.com", "marketplace.stripe.com", "docs.stripe.com", "dashboard-admin.stripe.com", "site-admin.stripe.com", "support-admin.corp.stripe.com", "manage.stripe.com", "billing.stripe.com", "pay.stripe.com", "verify-shopify.stripe.com"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    "__Host-auth_token": {
                        category: "authentication",
                        domains: ["dashboard.stripe.com", "dashboard-admin.stripe.com", "docs.stripe.com", "marketplace.stripe.com"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-stripe.link_app.csrf": {
                        category: "essential",
                        domains: ["app.link.co", "app.link.com", "link.corp.stripe.com", "link.qa.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-shopify_app_session": {
                        category: "authentication",
                        domains: ["sbyog-ppp-external.stripe.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    site_sid: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 7200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "site-auth": {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    skip_mismatched_country_check: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    skip_tfa_interrupt: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    spin: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    spl: {
                        category: "advertising",
                        domains: [".stripe.events"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "stripe.csrf": {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    "stripe.appmarketplace.csrf": {
                        category: "essential",
                        domains: ["marketplace.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "stripe.climate.csrf": {
                        category: "essential",
                        domains: ["climate.stripe.com", "edge-climate.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "stripe.customerportal.csrf": {
                        category: "essential",
                        domains: ["billing.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "stripe.docs.csrf": {
                        category: "essential",
                        domains: ["docs.stripe.com", "docs.corp.stripe.com", "docs.qa.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    svt_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com", "connect.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    tuuid: {
                        category: "advertising",
                        domains: [".demandbase.com", ".stripe.com"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    tuuid_lu: {
                        category: "advertising",
                        domains: [".demandbase.com", ".stripe.com"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    U: {
                        category: "advertising",
                        domains: [".adsymptotic.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    UserMatchHistory: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    user: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    VISITOR_INFO1_LIVE: {
                        category: "advertising",
                        domains: [".youtube.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    wd: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    xs: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    XA: {
                        category: "advertising",
                        domains: [".yahoo.co.jp", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    XB: {
                        category: "advertising",
                        domains: [".yahoo.co.jp", ".go.stripe.global"],
                        lifetime: 52617600,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    ndcd: {
                        category: "essential",
                        domains: [".acs.touch.tech", ".idcheck.acs.touchtechpayments.com", ".verifiedbyvisa.acs.touchtechpayments.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    YSC: {
                        category: "advertising",
                        domains: [".youtube.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "stripe.delegated-authentication.csrf": {
                        category: "essential",
                        domains: ["delegated-authentication.stripe.com", "oneclickauthn.qa.corp.stripe.com", "oneclickauthn.corp.stripe.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    payment_methods_settings_platform: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    VisitorId: {
                        category: "advertising",
                        domains: [".stripecdn.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-stripe.link_support_site.csrf": {
                        category: "essential",
                        domains: ["support.link.co", "support.link.com", "link-support-site.corp.stripe.com", "link-support-site.qa.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-stripe.sources_redirect_site.csrf": {
                        category: "essential",
                        domains: ["hooks.stripe.com", "hooks.qa.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    saml_login_result: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-saml_auth_result": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-stripe.support_site.csrf": {
                        category: "essential",
                        domains: ["support.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-unauthenticated_support_identity": {
                        category: "authentication",
                        domains: ["support.stripe.com", "support.link.co", "support.link.com", "support-conversations.stripe.com", "edge-support-conversations.stripe.com", "support-conversations.link.co", "support-conversations.link.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-stripe.site.csrf": {
                        category: "essential",
                        domains: ["stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-upsess": {
                        category: "authentication",
                        domains: ["privacy.stripe.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-privacy-csat": {
                        category: "functional",
                        domains: ["privacy.stripe.com"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Host-stripe.mkt.csrf": {
                        category: "essential",
                        domains: ["stripe.com", "press.stripe.com", "link.com", "site-admin.stripe.com", "edge.stripe.com", "edge-press.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Secure-webchat_qualification": {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Secure-stripe-routing-context": {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-webchat_widget": {
                        category: "essential",
                        domains: ["sales-live-chat.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Host-webchat_state": {
                        category: "essential",
                        domains: ["sales-live-chat.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Host-webchat_survey": {
                        category: "essential",
                        domains: ["sales-live-chat.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Secure-has_logged_in": {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    muc_ads: {
                        category: "advertising",
                        domains: [".t.co", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    personalization_id: {
                        category: "advertising",
                        domains: [".twitter.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    guest_id: {
                        category: "advertising",
                        domains: [".twitter.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    guest_id_ads: {
                        category: "advertising",
                        domains: [".twitter.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    guest_id_marketing: {
                        category: "advertising",
                        domains: [".twitter.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-last_login_method": {
                        category: "functional",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Host-oauth_registration_token": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 600,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-oauth_it_token": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    datadome: {
                        category: "essential",
                        domains: [".stripecdn.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _pxvid: {
                        category: "essential",
                        domains: [".stripecdn.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _px2: {
                        category: "essential",
                        domains: [".stripecdn.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-oauth_security_token": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    _zitok: {
                        category: "functional",
                        domains: ["b.stripecdn.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _cfuvid: {
                        category: "functional",
                        domains: [".zoominfo.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _px3: {
                        category: "functional",
                        domains: [".zoominfo.com"],
                        lifetime: 300,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __cf_bm: {
                        category: "functional",
                        domains: [".zoominfo.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-stripe.paywall.token": {
                        category: "authentication",
                        domains: ["paywall.stripe.com"],
                        lifetime: 3600,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "none"
                    }
                },
                z = {},
                B = null,
                J = function(e) {
                    if (W[e]) return new V(e, W[e]);
                    if (z[e]) return new V(e, z[e]);
                    B || (B = [].concat(m(Object.entries(W)), m(Object.entries(z))).map((function(e) {
                        var t = d(e, 2),
                            i = t[0],
                            r = t[1];
                        return new V(i, r)
                    })).filter((function(e) {
                        return e.inexact
                    })));
                    var t, i = c(B);
                    try {
                        for (i.s(); !(t = i.n()).done;) {
                            var r = t.value;
                            if (r.isMatch(e)) return r
                        }
                    } catch (e) {
                        i.e(e)
                    } finally {
                        i.f()
                    }
                    return null
                },
                K = {
                    decodeValues: !0,
                    map: !1,
                    silent: !1
                },
                Y = S,
                X = S,
                Q = b;
            Y.parse = X, Y.parseString = Q, Y.splitCookiesString = function(e) {
                function t() {
                    for (; c < e.length && /\s/.test(e.charAt(c));) c += 1;
                    return c < e.length
                }
                if (Array.isArray(e)) return e;
                if ("string" != typeof e) return [];
                for (var i, r, n, o, a, s = [], c = 0; c < e.length;) {
                    for (i = c, a = !1; t();)
                        if ("," === (r = e.charAt(c))) {
                            for (n = c, c += 1, t(), o = c; c < e.length && "=" !== (r = e.charAt(c)) && ";" !== r && "," !== r;) c += 1;
                            c < e.length && "=" === e.charAt(c) ? (a = !0, c = o, s.push(e.substring(i, n)), i = c) : c = n + 1
                        } else c += 1;
                    (!a || c >= e.length) && s.push(e.substring(i, e.length))
                }
                return s
            };
            var Z = null,
                ee = function() {
                    function e() {
                        var i, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        if (u(this, e), (i = t.call(this, r))._domainOverrides = r.domainOverrides || {}, i._documentCookiePatched = !1, "undefined" != typeof navigator) {
                            var n = navigator;
                            if (null == n ? void 0 : n.globalPrivacyControl)
                                for (var o = E.get(), a = 0, s = Object.keys(o); a < s.length; a++) {
                                    var c = s[a],
                                        l = J(c);
                                    "advertising" !== (null == l ? void 0 : l.category) || (null == l ? void 0 : l.httpOnly) || i.remove(c)
                                }
                        }
                        return i
                    }
                    r(e, F);
                    var t = o(e);
                    return f(e, [{
                        key: "get",
                        value: function(e) {
                            J(e) || M("No cookie matching the name ".concat(e, " was found in the cookies.yaml or cookies-next.yaml manifests. ") + "Reading the value of the cookie will work, but attempting to set the cookie will result in an error. If you're adding a new cookie, please visit go/cookies for more information!");
                            var t = E.get(e);
                            return void 0 === t ? null : t
                        }
                    }, {
                        key: "set",
                        value: function(e, t) {
                            var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                            return v(this, void 0, void 0, l().mark((function r() {
                                var n, o, a, s, c;
                                return l().wrap((function(r) {
                                    for (;;) switch (r.prev = r.next) {
                                        case 0:
                                            if (n = J(e)) {
                                                r.next = 4;
                                                break
                                            }
                                            return R("No cookie matching the name ".concat(e, " was found in the cookies.yaml or cookies-next.yaml manifests. ") + "If you're adding a new cookie, please visit go/cookies for more information!"), r.abrupt("return", !1);
                                        case 4:
                                            if (!n.httpOnly) {
                                                r.next = 7;
                                                break
                                            }
                                            return R("Cannot set the cookie ".concat(e, " via JavaScript, since it is marked HttpOnly. ") + "Please visit go/cookies for more information!"), r.abrupt("return", !1);
                                        case 7:
                                            r.prev = 7, o = n.resolveDomain(i.domain, this._domainOverrides), a = n.resolveExpiry(i.lifetime), r.next = 16;
                                            break;
                                        case 12:
                                            return r.prev = 12, r.t0 = r.catch(7), r.t0 instanceof Error ? R(r.t0.message) : R("Unexpected error", r.t0), r.abrupt("return", !1);
                                        case 16:
                                            return r.next = 18, this.isCategoryAllowed(n.category);
                                        case 18:
                                            if (r.sent) {
                                                r.next = 22;
                                                break
                                            }
                                            return M("Attempting to set cookie ".concat(e, " without the correct permissions: ").concat(n.category, " ") + "Please accept cookies and try again."), r.abrupt("return", !1);
                                        case 22:
                                            return !A || n.name.startsWith("__Host-") || C(window.location.hostname, o) || M("The cookie ".concat(e, " will be set on the domain ").concat(o, ", which doesn't match ") + "the current domain (".concat(window.location.hostname, "). This will result in the ") + "cookie being silently ignored by the browser. Please check to ensure the domain(s) for the cookie are correct in cookies[-next].yaml, or visit go/cookies for more information."), s = void 0 === i.secure ? n.secure : i.secure, c = this._getCookieAttributes({
                                                domain: o,
                                                expires: a,
                                                secure: s,
                                                sameSite: n.sameSite
                                            }), n.name.startsWith("__Host-") && (c.path = "/"), E.set(e, t, c), r.abrupt("return", !0);
                                        case 28:
                                        case "end":
                                            return r.stop()
                                    }
                                }), r, this, [
                                    [7, 12]
                                ])
                            })))
                        }
                    }, {
                        key: "remove",
                        value: function(e) {
                            var t, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                r = J(e);
                            if (!r) return R("No cookie matching the name ".concat(e, " was found in the cookies.yaml or cookies-next.yaml manifests. ") + "If you're adding a new cookie, please visit go/cookies for more information!"), !1;
                            try {
                                t = r.resolveDomain(i.domain, this._domainOverrides)
                            } catch (e) {
                                return e instanceof Error ? R(e.message) : R("Unexpected error", e), !1
                            }
                            A && !C(window.location.hostname, t) && M("The cookie ".concat(e, " will be set on the domain ").concat(t, ", which doesn't match ") + "the current domain (".concat(window.location.hostname, "). This will result in the ") + "cookie being silently ignored by the browser. Please check to ensure the domain(s) for the cookie are correct in cookies[-next].yaml, or visit go/cookies for more information.");
                            var n = this._getCookieAttributes({
                                domain: t,
                                secure: r.secure,
                                sameSite: r.sameSite
                            });
                            return E.remove(e, n), !0
                        }
                    }, {
                        key: "refresh",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                var t = this;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            Object.keys(E.get()).forEach((function(e) {
                                                var i = J(e);
                                                if (i && E.get(e)) {
                                                    var r = t.isCategoryAllowedMaybeSync(i.category);
                                                    !1 === r && t.remove(e), r instanceof O && r.then((function(i) {
                                                        i || t.remove(e)
                                                    }))
                                                }
                                            }));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }, {
                        key: "trapDocumentCookie",
                        value: function() {
                            this._documentCookiePatched || (this._documentCookiePatched = function(e) {
                                if (!A) return R("You cannot patch document.cookie if you aren't in a browser."), !1;
                                if (Z || (Z = Object.getOwnPropertyDescriptor(Document.prototype, "cookie")), !Z || !Z.get || !Z.set) return !1;
                                var t = Z.get,
                                    i = Z.set;
                                return Object.defineProperty(document, "cookie", {
                                    configurable: !0,
                                    get: function() {
                                        for (var e = arguments.length, i = new Array(e), r = 0; r < e; r++) i[r] = arguments[r];
                                        return t.apply(this, i)
                                    },
                                    set: function(t) {
                                        if (!t || 0 === t.length) return i.apply(this, [t]);
                                        var r = Q(t),
                                            n = r.name,
                                            o = r.value,
                                            a = r.domain;
                                        "true" === r.allowed ? i.apply(this, [t]) : e.set(n, o, {
                                            domain: a
                                        })
                                    }
                                }), !0
                            }(this))
                        }
                    }, {
                        key: "untrapDocumentCookie",
                        value: function() {
                            this._documentCookiePatched && (Z ? Object.defineProperty(document, "cookie", Z) : R("The document.cookie property has not been patched"), this._documentCookiePatched = !1)
                        }
                    }, {
                        key: "_getCookieAttributes",
                        value: function(e) {
                            var t = (0, w.A)({}, e);
                            return this._documentCookiePatched && (t.allowed = "true"), t
                        }
                    }]), e
                }(),
                te = function() {
                    function e(t, i) {
                        u(this, e), this.name = t, this.category = i.category, this.name.indexOf("*") >= 0 ? (this.inexact = !0, this._regexp = new RegExp(t.replace("*", ".+"))) : this.inexact = !1
                    }
                    return f(e, [{
                        key: "isMatch",
                        value: function(e) {
                            return this.name === e || this._regexp && this._regexp.test(e)
                        }
                    }]), e
                }(),
                ie = {
                    "*_dismissed": {
                        category: "functional"
                    },
                    "compliance-center.*": {
                        category: "essential"
                    },
                    docs: {
                        category: "essential"
                    },
                    lsid: {
                        category: "functional"
                    },
                    imt: {
                        category: "advertising"
                    },
                    personalizations: {
                        category: "functional"
                    },
                    "twilio_chat_*": {
                        category: "essential"
                    },
                    "yt-remote-connected-devices": {
                        category: "advertising"
                    },
                    "yt-remote-device-id": {
                        category: "advertising"
                    },
                    "yt.innertube::nextId": {
                        category: "advertising"
                    },
                    "yt.innertube::requests": {
                        category: "advertising"
                    },
                    "link.auth_session_client_secret": {
                        category: "authentication"
                    },
                    apps_oauth_state: {
                        category: "authentication"
                    },
                    request_sign_key: {
                        category: "authentication"
                    },
                    easel_position: {
                        category: "functional"
                    },
                    elements_session: {
                        category: "functional"
                    },
                    elements_assignment: {
                        category: "functional"
                    },
                    "elements.prb_warning.dismiss_timestamp": {
                        category: "essential"
                    },
                    last_used_payment_method: {
                        category: "functional"
                    },
                    user_session_token: {
                        category: "authentication"
                    },
                    "userleap.ids": {
                        category: "essential"
                    },
                    "userleap.pageviews": {
                        category: "essential"
                    },
                    workbenchState: {
                        category: "functional"
                    },
                    "dashboard.banner-dismissals": {
                        category: "essential"
                    },
                    "dashboard.nav-collapsed": {
                        category: "functional"
                    },
                    link_app_devtools: {
                        category: "essential"
                    },
                    "payment_method_settings.direct": {
                        category: "functional"
                    },
                    "verification-session-create--verification-flow-toggle--value": {
                        category: "functional"
                    },
                    "payment_method_settings.connect": {
                        category: "functional"
                    },
                    register_login_redesign: {
                        category: "functional"
                    },
                    "dashboard.setup-guide-closed": {
                        category: "functional"
                    },
                    "dashboard.setup-guide-collapsed": {
                        category: "functional"
                    },
                    logged_user: {
                        category: "essential"
                    },
                    "x-px-cookies": {
                        category: "essential"
                    },
                    "developers.apps.detail.permissionMigrationCallout.dismissed": {
                        category: "functional"
                    }
                },
                re = Object.keys(ie).reduce((function(e, t) {
                    var i = ie[t];
                    return e[t] = new te(t, i), e
                }), {}),
                ne = Object.keys(re).filter((function(e) {
                    return re[e].inexact
                })).map((function(e) {
                    return re[e]
                })),
                oe = function(e) {
                    if (re[e]) return re[e];
                    var t, i = c(ne);
                    try {
                        for (i.s(); !(t = i.n()).done;) {
                            var r = t.value;
                            if (r.isMatch(e)) return r
                        }
                    } catch (e) {
                        i.e(e)
                    } finally {
                        i.f()
                    }
                    return null
                },
                ae = function() {
                    function e() {
                        var i, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        return u(this, e), i = t.call(this, r), k("localStorage") && setTimeout((function() {
                            i.refresh()
                        }), 0), i
                    }
                    r(e, F);
                    var t = o(e);
                    return f(e, [{
                        key: "isStorageAvailable",
                        value: function() {
                            return k("localStorage")
                        }
                    }, {
                        key: "get",
                        value: function(e) {
                            return oe(e) || M("No item matching the name ".concat(e, " was found in the localStorage.yaml manifest. ") + "Reading the value of the item will work, but attempting to set the item will result in an error. If you're adding a new localStorage item, please visit go/cookies for more information!"), k("localStorage") ? (this.refresh(), localStorage.getItem(e)) : null
                        }
                    }, {
                        key: "getKeyMatches",
                        value: function(e) {
                            if (!(e.indexOf("*") >= 0)) return M("Invalid pattern provided, no wildcard after other characters"), [];
                            var t = new RegExp("^".concat(e.replace("*", ".+"), "$"));
                            return Object.keys(localStorage).filter((function(e) {
                                return t.test(e)
                            })).filter((function(e) {
                                return oe(e)
                            }))
                        }
                    }, {
                        key: "set",
                        value: function(e, t) {
                            return v(this, void 0, void 0, l().mark((function i() {
                                var r;
                                return l().wrap((function(i) {
                                    for (;;) switch (i.prev = i.next) {
                                        case 0:
                                            if (r = oe(e)) {
                                                i.next = 4;
                                                break
                                            }
                                            return R("No item matching the name ".concat(e, " was found in the localStorage.yaml manifest. ") + "If you're adding a new item, please visit go/cookies for more information!"), i.abrupt("return", !1);
                                        case 4:
                                            return i.next = 6, this.isCategoryAllowed(r.category);
                                        case 6:
                                            if (i.sent) {
                                                i.next = 10;
                                                break
                                            }
                                            return M("Attempting to set localStorage ".concat(e, " without the correct permissions. ") + "Please accept cookies and try again."), i.abrupt("return", !1);
                                        case 10:
                                            if (k("localStorage")) {
                                                i.next = 12;
                                                break
                                            }
                                            return i.abrupt("return", !1);
                                        case 12:
                                            return localStorage.setItem(e, t), i.abrupt("return", !0);
                                        case 14:
                                        case "end":
                                            return i.stop()
                                    }
                                }), i, this)
                            })))
                        }
                    }, {
                        key: "remove",
                        value: function(e) {
                            return oe(e) ? !!k("localStorage") && (localStorage.removeItem(e), !0) : (R("No item matching the name ".concat(e, " was found in the localStorage.yaml manifest. ") + "If you're adding a new item, please visit go/cookies for more information!"), !1)
                        }
                    }, {
                        key: "refresh",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                var t = this;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            Object.keys(localStorage).forEach((function(e) {
                                                var i = oe(e);
                                                if (i && localStorage.getItem(e)) {
                                                    var r = t.isCategoryAllowedMaybeSync(i.category);
                                                    !1 === r && localStorage.removeItem(e), r instanceof O && r.then((function(t) {
                                                        t || localStorage.removeItem(e)
                                                    }))
                                                }
                                            }));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }]), e
                }(),
                se = function() {
                    function e(t, i) {
                        u(this, e), this.name = t, this.category = i.category, this.name.indexOf("*") >= 0 ? (this.inexact = !0, this._regexp = new RegExp(t.replace("*", ".+"))) : this.inexact = !1
                    }
                    return f(e, [{
                        key: "isMatch",
                        value: function(e) {
                            return this.name === e || this._regexp && this._regexp.test(e)
                        }
                    }]), e
                }(),
                ce = {
                    1: {
                        category: "essential"
                    },
                    placeholder_session_storage_object: {
                        category: "essential"
                    },
                    workbenchState: {
                        category: "functional"
                    },
                    "dashboard.tab-context": {
                        category: "essential"
                    },
                    _ab: {
                        category: "essential"
                    },
                    _mf: {
                        category: "essential"
                    },
                    id: {
                        category: "essential"
                    },
                    "link_app.subscription_card_dismissed": {
                        category: "essential"
                    },
                    register_login_redesign: {
                        category: "functional"
                    }
                },
                le = Object.keys(ce).reduce((function(e, t) {
                    var i = ce[t];
                    return e[t] = new se(t, i), e
                }), {}),
                me = Object.keys(le).filter((function(e) {
                    return le[e].inexact
                })).map((function(e) {
                    return le[e]
                })),
                ue = function(e) {
                    if (le[e]) return le[e];
                    var t, i = c(me);
                    try {
                        for (i.s(); !(t = i.n()).done;) {
                            var r = t.value;
                            if (r.isMatch(e)) return r
                        }
                    } catch (e) {
                        i.e(e)
                    } finally {
                        i.f()
                    }
                    return null
                },
                pe = function() {
                    function e() {
                        var i, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        return u(this, e), i = t.call(this, r), k("sessionStorage") && setTimeout((function() {
                            i.refresh()
                        }), 0), i
                    }
                    r(e, F);
                    var t = o(e);
                    return f(e, [{
                        key: "isStorageAvailable",
                        value: function() {
                            return k("sessionStorage")
                        }
                    }, {
                        key: "get",
                        value: function(e) {
                            return ue(e) || M("No item matching the name ".concat(e, " was found in the sessionStorage.yaml manifest. ") + "Reading the value of the item will work, but attempting to set the item will result in an error. If you're adding a new sessionStorage item, please visit go/cookies for more information!"), k("sessionStorage") ? (this.refresh(), sessionStorage.getItem(e)) : null
                        }
                    }, {
                        key: "set",
                        value: function(e, t) {
                            return v(this, void 0, void 0, l().mark((function i() {
                                var r;
                                return l().wrap((function(i) {
                                    for (;;) switch (i.prev = i.next) {
                                        case 0:
                                            if (r = ue(e)) {
                                                i.next = 4;
                                                break
                                            }
                                            return R("No item matching the name ".concat(e, " was found in the sessionStorage.yaml manifest. ") + "If you're adding a new item, please visit go/cookies for more information!"), i.abrupt("return", !1);
                                        case 4:
                                            return i.next = 6, this.isCategoryAllowed(r.category);
                                        case 6:
                                            if (i.sent) {
                                                i.next = 10;
                                                break
                                            }
                                            return M("Attempting to set sessionStorage ".concat(e, " without the correct permissions. ") + "Please accept cookies and try again."), i.abrupt("return", !1);
                                        case 10:
                                            if (k("sessionStorage")) {
                                                i.next = 12;
                                                break
                                            }
                                            return i.abrupt("return", !1);
                                        case 12:
                                            return sessionStorage.setItem(e, t), i.abrupt("return", !0);
                                        case 14:
                                        case "end":
                                            return i.stop()
                                    }
                                }), i, this)
                            })))
                        }
                    }, {
                        key: "remove",
                        value: function(e) {
                            return ue(e) ? !!k("sessionStorage") && (sessionStorage.removeItem(e), !0) : (R("No item matching the name ".concat(e, " was found in the sessionStorage.yaml manifest. ") + "If you're adding a new item, please visit go/cookies for more information!"), !1)
                        }
                    }, {
                        key: "refresh",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                var t = this;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            Object.keys(sessionStorage).forEach((function(e) {
                                                var i = ue(e);
                                                if (i && sessionStorage.getItem(e)) {
                                                    var r = t.isCategoryAllowedMaybeSync(i.category);
                                                    !1 === r && sessionStorage.removeItem(e), r instanceof O && r.then((function(t) {
                                                        t || sessionStorage.removeItem(e)
                                                    }))
                                                }
                                            }));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }]), e
                }(),
                fe = q("/cookie-settings"),
                de = q("/cookies-policy/legal"),
                he = "https://stripe.com/cookie-settings/enforcement-mode"
        }
    }
]);