(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 843577, e => {
    "use strict";
    var r = e.i(705766);

    function o(e) {
        r.default.error(e ? .message || e || "Error occurred, please try again later!")
    }

    function t(e) {
        r.default.success(e)
    }
    e.s(["showError", () => o, "showSuccess", () => t])
}, 224881, e => {
    "use strict";
    var r = e.i(843476),
        o = e.i(271645),
        t = e.i(693936),
        s = e.i(618566),
        i = e.i(217255),
        a = e.i(944779),
        u = e.i(843577);

    function c() {
        let {
            data: e
        } = (0, i.useSession)(), r = (0, s.useSearchParams)().get("oauth_verifier"), c = (0, s.useSearchParams)().get("redirect"), n = (0, s.useRouter)();
        return (0, o.useEffect)(() => ((async () => {
            let e = a.authService.getTwitterToken();
            if (r && e.oauthToken && e.oauthTokenSecret) try {
                let o = await (0, i.signIn)("credentials", {
                    type: "twitter",
                    oauth_verifier: r,
                    oauthToken: e.oauthToken,
                    oauthTokenSecret: e.oauthTokenSecret,
                    role: "user",
                    redirect: !1
                });
                if (o ? .ok) {
                    let e = localStorage.getItem("redirect") || c || "/home";
                    n.push("/auth/login" !== e ? e : "/home"), localStorage.removeItem("redirect")
                }
                o ? .error && (0, u.showError)({
                    message: o.error
                })
            } catch (e) {
                (0, u.showError)(e)
            }
        })(), () => {
            (0, t.googleLogout)()
        }), []), (0, t.useGoogleOneTapLogin)({
            onError: () => {
                (0, u.showError)("Login failed!")
            },
            onSuccess: async r => {
                if (!(!r.credential || e ? .user ? ._id)) try {
                    let e = await (0, i.signIn)("credentials", {
                        type: "google-onetap",
                        tokenId: r.credential,
                        role: "user",
                        redirect: !1
                    });
                    e ? .ok && n.push("/home"), e ? .error && (0, u.showError)({
                        message: e.error
                    })
                } catch (e) {
                    (0, u.showError)(e)
                }
            },
            disabled: !!e ? .user ? ._id
        }), null
    }

    function n() {
        return (0, r.jsx)(o.Suspense, {
            children: (0, r.jsx)(c, {})
        })
    }
    e.s(["default", () => n])
}, 588027, e => {
    e.n(e.i(224881))
}]);