(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 742732, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "HeadManagerContext", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(555682)._(e.r(271645)).default.createContext({})
}, 922737, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "setAttributesFromProps", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = {
            acceptCharset: "accept-charset",
            className: "class",
            htmlFor: "for",
            httpEquiv: "http-equiv",
            noModule: "noModule"
        },
        o = ["onLoad", "onReady", "dangerouslySetInnerHTML", "children", "onError", "strategy", "stylesheets"];

    function l(e) {
        return ["async", "defer", "noModule"].includes(e)
    }

    function a(e, t) {
        for (let [r, a] of Object.entries(t)) {
            if (!t.hasOwnProperty(r) || o.includes(r) || void 0 === a) continue;
            let i = n[r] || r.toLowerCase();
            "SCRIPT" === e.tagName && l(i) ? e[i] = !!a : e.setAttribute(i, String(a)), (!1 === a || "SCRIPT" === e.tagName && l(i) && (!a || "false" === a)) && (e.setAttribute(i, ""), e.removeAttribute(i))
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 168027, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(843476),
        o = e.r(912354),
        l = {
            fontFamily: 'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
            height: "100vh",
            textAlign: "center",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center"
        },
        a = {
            fontSize: "14px",
            fontWeight: 400,
            lineHeight: "28px",
            margin: "0 8px"
        },
        i = function(e) {
            let {
                error: t
            } = e, r = t ? .digest;
            return (0, n.jsxs)("html", {
                id: "__next_error__",
                children: [(0, n.jsx)("head", {}), (0, n.jsxs)("body", {
                    children: [(0, n.jsx)(o.HandleISRError, {
                        error: t
                    }), (0, n.jsx)("div", {
                        style: l,
                        children: (0, n.jsxs)("div", {
                            children: [(0, n.jsxs)("h2", {
                                style: a,
                                children: ["Application error: a ", r ? "server" : "client", "-side exception has occurred while loading ", window.location.hostname, " (see the", " ", r ? "server logs" : "browser console", " for more information)."]
                            }), r ? (0, n.jsx)("p", {
                                style: a,
                                children: `Digest: ${r}`
                            }) : null]
                        })
                    })]
                })]
            })
        };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 974575, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "getAssetPrefix", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(312718);

    function o() {
        let e = document.currentScript;
        if (!(e instanceof HTMLScriptElement)) throw Object.defineProperty(new n.InvariantError(`Expected document.currentScript to be a <script> element. Received ${e} instead.`), "__NEXT_ERROR_CODE", {
            value: "E783",
            enumerable: !1,
            configurable: !0
        });
        let {
            pathname: t
        } = new URL(e.src), r = t.indexOf("/_next/");
        if (-1 === r) throw Object.defineProperty(new n.InvariantError(`Expected document.currentScript src to contain '/_next/'. Received ${e.src} instead.`), "__NEXT_ERROR_CODE", {
            value: "E784",
            enumerable: !1,
            configurable: !0
        });
        return t.slice(0, r)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 396517, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "appBootstrap", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(974575),
        o = e.r(922737);

    function l(e) {
        var t, r;
        let l = (0, n.getAssetPrefix)();
        t = self.__next_s, r = () => {
            e(l)
        }, t && t.length ? t.reduce((e, t) => {
            let [r, n] = t;
            return e.then(() => new Promise((e, t) => {
                let l = document.createElement("script");
                n && (0, o.setAttributesFromProps)(l, n), r ? (l.src = r, l.onload = () => e(), l.onerror = t) : n && (l.innerHTML = n.children, setTimeout(e)), document.head.appendChild(l)
            }))
        }, Promise.resolve()).catch(e => {
            console.error(e)
        }).then(() => {
            r()
        }) : r()
    }
    window.next = {
        version: "16.1.6",
        appDir: !0
    }, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 816565, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getObjectClassLabel: function() {
            return l
        },
        isPlainObject: function() {
            return a
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function l(e) {
        return Object.prototype.toString.call(e)
    }

    function a(e) {
        if ("[object Object]" !== l(e)) return !1;
        let t = Object.getPrototypeOf(e);
        return null === t || t.hasOwnProperty("isPrototypeOf")
    }
}, 302023, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return a
        },
        getProperError: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let l = e.r(816565);

    function a(e) {
        return "object" == typeof e && null !== e && "name" in e && "message" in e
    }

    function i(e) {
        let t;
        return a(e) ? e : Object.defineProperty(Error((0, l.isPlainObject)(e) ? (t = new WeakSet, JSON.stringify(e, (e, r) => {
            if ("object" == typeof r && null !== r) {
                if (t.has(r)) return "[Circular]";
                t.add(r)
            }
            return r
        })) : e + ""), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        })
    }
}, 528279, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "reportGlobalError", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = "function" == typeof reportError ? reportError : e => {
        globalThis.console.error(e)
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 597238, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        isRecoverableError: function() {
            return s
        },
        onRecoverableError: function() {
            return c
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let l = e.r(555682),
        a = e.r(132061),
        i = l._(e.r(302023)),
        u = e.r(528279),
        d = new WeakSet;

    function s(e) {
        return d.has(e)
    }
    let c = e => {
        let t = (0, i.default)(e) && "cause" in e ? e.cause : e;
        (0, a.isBailoutToCSRError)(t) || (0, u.reportGlobalError)(t)
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 5526, (e, t, r) => {
    "use strict";
    t.exports = {}
}, 966849, (e, t, r) => {
    "trimStart" in String.prototype || (String.prototype.trimStart = String.prototype.trimLeft), "trimEnd" in String.prototype || (String.prototype.trimEnd = String.prototype.trimRight), "description" in Symbol.prototype || Object.defineProperty(Symbol.prototype, "description", {
        configurable: !0,
        get: function() {
            var e = /\((.*)\)/.exec(this.toString());
            return e ? e[1] : void 0
        }
    }), Array.prototype.flat || (Array.prototype.flat = function(e, t) {
        return t = this.concat.apply([], this), e > 1 && t.some(Array.isArray) ? t.flat(e - 1) : t
    }, Array.prototype.flatMap = function(e, t) {
        return this.map(e, t).flat()
    }), Promise.prototype.finally || (Promise.prototype.finally = function(e) {
        if ("function" != typeof e) return this.then(e, e);
        var t = this.constructor || Promise;
        return this.then(function(r) {
            return t.resolve(e()).then(function() {
                return r
            })
        }, function(r) {
            return t.resolve(e()).then(function() {
                throw r
            })
        })
    }), Object.fromEntries || (Object.fromEntries = function(e) {
        return Array.from(e).reduce(function(e, t) {
            return e[t[0]] = t[1], e
        }, {})
    }), Array.prototype.at || (Array.prototype.at = function(e) {
        var t = Math.trunc(e) || 0;
        if (t < 0 && (t += this.length), !(t < 0 || t >= this.length)) return this[t]
    }), Object.hasOwn || (Object.hasOwn = function(e, t) {
        if (null == e) throw TypeError("Cannot convert undefined or null to object");
        return Object.prototype.hasOwnProperty.call(Object(e), t)
    }), "canParse" in URL || (URL.canParse = function(e, t) {
        try {
            return new URL(e, t), !0
        } catch (e) {
            return !1
        }
    })
}, 523911, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), e.r(966849), ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 851323, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        onCaughtError: function() {
            return f
        },
        onUncaughtError: function() {
            return p
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let l = e.r(555682),
        a = e.r(265713),
        i = e.r(132061),
        u = e.r(528279),
        d = e.r(972383),
        s = l._(e.r(168027)),
        c = {
            decorateDevError: e => e,
            handleClientError: () => {},
            originConsoleError: console.error.bind(console)
        };

    function f(e, t) {
        let r, n = t.errorBoundary ? .constructor;
        if (r = r || n === d.ErrorBoundaryHandler && t.errorBoundary.props.errorComponent === s.default) return p(e);
        (0, i.isBailoutToCSRError)(e) || (0, a.isNextRouterError)(e) || c.originConsoleError(e)
    }

    function p(e) {
        (0, i.isBailoutToCSRError)(e) || (0, a.isNextRouterError)(e) || (0, u.reportGlobalError)(e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 762634, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "AppRouterAnnouncer", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(271645),
        o = e.r(174080),
        l = "next-route-announcer";

    function a(e) {
        let {
            tree: t
        } = e, [r, a] = (0, n.useState)(null);
        (0, n.useEffect)(() => (a(function() {
            let e = document.getElementsByName(l)[0];
            if (e ? .shadowRoot ? .childNodes[0]) return e.shadowRoot.childNodes[0]; {
                let e = document.createElement(l);
                e.style.cssText = "position:absolute";
                let t = document.createElement("div");
                return t.ariaLive = "assertive", t.id = "__next-route-announcer__", t.role = "alert", t.style.cssText = "position:absolute;border:0;height:1px;margin:-1px;padding:0;width:1px;clip:rect(0 0 0 0);overflow:hidden;white-space:nowrap;word-wrap:normal", e.attachShadow({
                    mode: "open"
                }).appendChild(t), document.body.appendChild(e), t
            }
        }()), () => {
            let e = document.getElementsByTagName(l)[0];
            e ? .isConnected && document.body.removeChild(e)
        }), []);
        let [i, u] = (0, n.useState)(""), d = (0, n.useRef)(void 0);
        return (0, n.useEffect)(() => {
            let e = "";
            if (document.title) e = document.title;
            else {
                let t = document.querySelector("h1");
                t && (e = t.innerText || t.textContent || "")
            }
            void 0 !== d.current && d.current !== e && u(e), d.current = e
        }, [t]), r ? (0, o.createPortal)(i, r) : null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 425018, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "findHeadInCache", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(813258),
        o = e.r(270725);

    function l(e, t) {
        return function e(t, r, l, a) {
            if (0 === Object.keys(r).length) return [t, l, a];
            let i = Object.keys(r).filter(e => "children" !== e);
            for (let a of ("children" in r && i.unshift("children"), i)) {
                let [i, u] = r[a];
                if (i === n.DEFAULT_SEGMENT_KEY) continue;
                let d = t.parallelRoutes.get(a);
                if (!d) continue;
                let s = (0, o.createRouterCacheKey)(i),
                    c = (0, o.createRouterCacheKey)(i, !0),
                    f = d.get(s);
                if (!f) continue;
                let p = e(f, u, l + "/" + s, l + "/" + c);
                if (p) return p
            }
            return null
        }(e, t, "", "")
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 241624, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        GracefulDegradeBoundary: function() {
            return i
        },
        default: function() {
            return u
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let l = e.r(843476),
        a = e.r(271645);
    class i extends a.Component {
        constructor(e) {
            super(e), this.state = {
                hasError: !1
            }, this.rootHtml = "", this.htmlAttributes = {}, this.htmlRef = (0, a.createRef)()
        }
        static getDerivedStateFromError(e) {
            return {
                hasError: !0
            }
        }
        componentDidMount() {
            let e = this.htmlRef.current;
            this.state.hasError && e && Object.entries(this.htmlAttributes).forEach(t => {
                let [r, n] = t;
                e.setAttribute(r, n)
            })
        }
        render() {
            let {
                hasError: e
            } = this.state;
            return ("u" > typeof window && !this.rootHtml && (this.rootHtml = document.documentElement.innerHTML, this.htmlAttributes = function(e) {
                let t = {};
                for (let r = 0; r < e.attributes.length; r++) {
                    let n = e.attributes[r];
                    t[n.name] = n.value
                }
                return t
            }(document.documentElement)), e) ? (0, l.jsx)("html", {
                ref: this.htmlRef,
                suppressHydrationWarning: !0,
                dangerouslySetInnerHTML: {
                    __html: this.rootHtml
                }
            }) : this.props.children
        }
    }
    let u = i;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 794109, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return d
        }
    });
    let n = e.r(555682),
        o = e.r(843476);
    e.r(271645);
    let l = n._(e.r(241624)),
        a = e.r(972383),
        i = e.r(82604),
        u = "u" > typeof window && (0, i.isBot)(window.navigator.userAgent);

    function d(e) {
        let {
            children: t,
            errorComponent: r,
            errorStyles: n,
            errorScripts: i
        } = e;
        return u ? (0, o.jsx)(l.default, {
            children: t
        }) : (0, o.jsx)(a.ErrorBoundary, {
            errorComponent: r,
            errorStyles: n,
            errorScripts: i,
            children: t
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 875530, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return N
        }
    });
    let n = e.r(555682),
        o = e.r(190809),
        l = e.r(843476),
        a = o._(e.r(271645)),
        i = e.r(8372),
        u = e.r(388540),
        d = e.r(451191),
        s = e.r(261994),
        c = e.r(941538),
        f = e.r(762634),
        p = e.r(358442),
        h = e.r(425018),
        _ = e.r(201244),
        y = e.r(387250),
        b = e.r(652817),
        m = e.r(734727),
        v = e.r(178377),
        E = e.r(699781),
        j = e.r(124063),
        g = e.r(968391),
        w = e.r(91949),
        P = n._(e.r(794109)),
        O = n._(e.r(168027)),
        R = e.r(897367),
        S = e.r(543369),
        x = {};

    function M(e) {
        let {
            appRouterState: t
        } = e;
        return (0, a.useInsertionEffect)(() => {
            let {
                tree: e,
                pushRef: r,
                canonicalUrl: n,
                renderedSearch: o
            } = t, l = { ...r.preserveCustomHistoryState ? window.history.state : {},
                __NA: !0,
                __PRIVATE_NEXTJS_INTERNALS_TREE: {
                    tree: e,
                    renderedSearch: o
                }
            };
            r.pendingPush && (0, d.createHrefFromUrl)(new URL(window.location.href)) !== n ? (r.pendingPush = !1, window.history.pushState(l, "", n)) : window.history.replaceState(l, "", n)
        }, [t]), (0, a.useEffect)(() => {
            (0, w.pingVisibleLinks)(t.nextUrl, t.tree)
        }, [t.nextUrl, t.tree]), null
    }

    function T(e) {
        null == e && (e = {});
        let t = window.history.state,
            r = t ? .__NA;
        r && (e.__NA = r);
        let n = t ? .__PRIVATE_NEXTJS_INTERNALS_TREE;
        return n && (e.__PRIVATE_NEXTJS_INTERNALS_TREE = n), e
    }

    function A(e) {
        let {
            headCacheNode: t
        } = e, r = null !== t ? t.head : null, n = null !== t ? t.prefetchHead : null, o = null !== n ? n : r;
        return (0, a.useDeferredValue)(r, o)
    }

    function C(e) {
        let t, {
                actionQueue: r,
                globalError: n,
                webSocket: o,
                staticIndicatorState: d
            } = e,
            v = (0, c.useActionQueue)(r),
            {
                canonicalUrl: w
            } = v,
            {
                searchParams: O,
                pathname: S
            } = (0, a.useMemo)(() => {
                let e = new URL(w, "u" < typeof window ? "http://n" : window.location.href);
                return {
                    searchParams: e.searchParams,
                    pathname: (0, b.hasBasePath)(e.pathname) ? (0, y.removeBasePath)(e.pathname) : e.pathname
                }
            }, [w]);
        (0, a.useEffect)(() => {
            function e(e) {
                e.persisted && window.history.state ? .__PRIVATE_NEXTJS_INTERNALS_TREE && (x.pendingMpaPath = void 0, (0, c.dispatchAppRouterAction)({
                    type: u.ACTION_RESTORE,
                    url: new URL(window.location.href),
                    historyState: window.history.state.__PRIVATE_NEXTJS_INTERNALS_TREE
                }))
            }
            return window.addEventListener("pageshow", e), () => {
                window.removeEventListener("pageshow", e)
            }
        }, []), (0, a.useEffect)(() => {
            function e(e) {
                let t = "reason" in e ? e.reason : e.error;
                if ((0, g.isRedirectError)(t)) {
                    e.preventDefault();
                    let r = (0, j.getURLFromRedirectError)(t);
                    (0, j.getRedirectTypeFromError)(t) === g.RedirectType.push ? E.publicAppRouterInstance.push(r, {}) : E.publicAppRouterInstance.replace(r, {})
                }
            }
            return window.addEventListener("error", e), window.addEventListener("unhandledrejection", e), () => {
                window.removeEventListener("error", e), window.removeEventListener("unhandledrejection", e)
            }
        }, []);
        let {
            pushRef: C
        } = v;
        if (C.mpaNavigation) {
            if (x.pendingMpaPath !== w) {
                let e = window.location;
                C.pendingPush ? e.assign(w) : e.replace(w), x.pendingMpaPath = w
            }
            throw _.unresolvedThenable
        }(0, a.useEffect)(() => {
            let e = window.history.pushState.bind(window.history),
                t = window.history.replaceState.bind(window.history),
                r = e => {
                    let t = window.location.href,
                        r = window.history.state ? .__PRIVATE_NEXTJS_INTERNALS_TREE;
                    (0, a.startTransition)(() => {
                        (0, c.dispatchAppRouterAction)({
                            type: u.ACTION_RESTORE,
                            url: new URL(e ? ? t, t),
                            historyState: r
                        })
                    })
                };
            window.history.pushState = function(t, n, o) {
                return t ? .__NA || t ? ._N || (t = T(t), o && r(o)), e(t, n, o)
            }, window.history.replaceState = function(e, n, o) {
                return e ? .__NA || e ? ._N || (e = T(e), o && r(o)), t(e, n, o)
            };
            let n = e => {
                if (e.state) {
                    if (!e.state.__NA) return void window.location.reload();
                    (0, a.startTransition)(() => {
                        (0, E.dispatchTraverseAction)(window.location.href, e.state.__PRIVATE_NEXTJS_INTERNALS_TREE)
                    })
                }
            };
            return window.addEventListener("popstate", n), () => {
                window.history.pushState = e, window.history.replaceState = t, window.removeEventListener("popstate", n)
            }
        }, []);
        let {
            cache: N,
            tree: L,
            nextUrl: I,
            focusAndScrollRef: F,
            previousNextUrl: H
        } = v, D = (0, a.useMemo)(() => (0, h.findHeadInCache)(N, L[1]), [N, L]), B = (0, a.useMemo)(() => (0, m.getSelectedParams)(L), [L]), X = (0, a.useMemo)(() => ({
            parentTree: L,
            parentCacheNode: N,
            parentSegmentPath: null,
            parentParams: {},
            debugNameContext: "/",
            url: w,
            isActive: !0
        }), [L, N, w]), k = (0, a.useMemo)(() => ({
            tree: L,
            focusAndScrollRef: F,
            nextUrl: I,
            previousNextUrl: H
        }), [L, F, I, H]);
        if (null !== D) {
            let [e, r, n] = D;
            t = (0, l.jsx)(A, {
                headCacheNode: e
            }, "u" < typeof window ? n : r)
        } else t = null;
        let V = (0, l.jsxs)(p.RedirectBoundary, {
            children: [t, (0, l.jsx)(R.RootLayoutBoundary, {
                children: N.rsc
            }), (0, l.jsx)(f.AppRouterAnnouncer, {
                tree: L
            })]
        });
        return V = (0, l.jsx)(P.default, {
            errorComponent: n[0],
            errorStyles: n[1],
            children: V
        }), (0, l.jsxs)(l.Fragment, {
            children: [(0, l.jsx)(M, {
                appRouterState: v
            }), (0, l.jsx)(U, {}), (0, l.jsx)(s.NavigationPromisesContext.Provider, {
                value: null,
                children: (0, l.jsx)(s.PathParamsContext.Provider, {
                    value: B,
                    children: (0, l.jsx)(s.PathnameContext.Provider, {
                        value: S,
                        children: (0, l.jsx)(s.SearchParamsContext.Provider, {
                            value: O,
                            children: (0, l.jsx)(i.GlobalLayoutRouterContext.Provider, {
                                value: k,
                                children: (0, l.jsx)(i.AppRouterContext.Provider, {
                                    value: E.publicAppRouterInstance,
                                    children: (0, l.jsx)(i.LayoutRouterContext.Provider, {
                                        value: X,
                                        children: V
                                    })
                                })
                            })
                        })
                    })
                })
            })]
        })
    }

    function N(e) {
        let {
            actionQueue: t,
            globalErrorState: r,
            webSocket: n,
            staticIndicatorState: o
        } = e;
        (0, v.useNavFailureHandler)();
        let a = (0, l.jsx)(C, {
            actionQueue: t,
            globalError: r,
            webSocket: n,
            staticIndicatorState: o
        });
        return (0, l.jsx)(P.default, {
            errorComponent: O.default,
            children: a
        })
    }
    let L = new Set,
        I = new Set;

    function U() {
        let [, e] = a.default.useState(0), t = L.size;
        (0, a.useEffect)(() => {
            let r = () => e(e => e + 1);
            return I.add(r), t !== L.size && r(), () => {
                I.delete(r)
            }
        }, [t, e]);
        let r = (0, S.getDeploymentIdQueryOrEmptyString)();
        return [...L].map((e, t) => (0, l.jsx)("link", {
            rel: "stylesheet",
            href: `${e}${r}`,
            precedence: "next"
        }, t))
    }
    globalThis._N_E_STYLE_LOAD = function(e) {
        let t = L.size;
        return L.add(e), L.size !== t && I.forEach(e => e()), Promise.resolve()
    }, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 665716, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createInitialRouterState", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(451191),
        o = e.r(734727),
        l = e.r(450590),
        a = e.r(595871);

    function i(e) {
        let {
            navigatedAt: t,
            initialFlightData: r,
            initialCanonicalUrlParts: i,
            initialRenderedSearch: u,
            location: d
        } = e, s = i.join("/"), {
            tree: c,
            seedData: f,
            head: p
        } = (0, l.getFlightDataPartsFromPath)(r[0]), h = d ? (0, n.createHrefFromUrl)(d) : s;
        return {
            tree: c,
            cache: (0, a.createInitialCacheNodeForHydration)(t, c, f, p),
            pushRef: {
                pendingPush: !1,
                mpaNavigation: !1,
                preserveCustomHistoryState: !0
            },
            focusAndScrollRef: {
                apply: !1,
                onlyHashChange: !1,
                hashFragment: null,
                segmentPaths: []
            },
            canonicalUrl: h,
            renderedSearch: u,
            nextUrl: ((0, o.extractPathFromFlightRouterState)(c) || d ? .pathname) ? ? null,
            previousNextUrl: null,
            debugInfo: null
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 198569, (e, t, r) => {
    "use strict";
    let n, o, l, a;
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "hydrate", {
        enumerable: !0,
        get: function() {
            return H
        }
    });
    let i = e.r(555682),
        u = e.r(843476);
    e.r(523911);
    let d = i._(e.r(88014)),
        s = i._(e.r(271645)),
        c = e.r(235326),
        f = e.r(742732),
        p = e.r(597238),
        h = e.r(851323),
        _ = e.r(132120),
        y = e.r(92245),
        b = e.r(699781),
        m = i._(e.r(875530)),
        v = e.r(665716);
    e.r(8372);
    let E = e.r(814297),
        j = e.r(450590),
        g = c.createFromReadableStream,
        w = c.createFromFetch,
        P = document,
        O = new TextEncoder,
        R = !1,
        S = !1,
        x = null;

    function M(e) {
        if (0 === e[0]) l = [];
        else if (1 === e[0]) {
            if (!l) throw Object.defineProperty(Error("Unexpected server data: missing bootstrap script."), "__NEXT_ERROR_CODE", {
                value: "E18",
                enumerable: !1,
                configurable: !0
            });
            a ? a.enqueue(O.encode(e[1])) : l.push(e[1])
        } else if (2 === e[0]) x = e[1];
        else if (3 === e[0]) {
            if (!l) throw Object.defineProperty(Error("Unexpected server data: missing bootstrap script."), "__NEXT_ERROR_CODE", {
                value: "E18",
                enumerable: !1,
                configurable: !0
            });
            let r = atob(e[1]),
                n = new Uint8Array(r.length);
            for (var t = 0; t < r.length; t++) n[t] = r.charCodeAt(t);
            a ? a.enqueue(n) : l.push(n)
        }
    }
    let T = function() {
        a && !S && (a.close(), S = !0, l = void 0), R = !0
    };
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", T, !1) : setTimeout(T);
    let A = self.__next_f = self.__next_f || [];
    A.forEach(M), A.length = 0, A.push = M;
    let C = new ReadableStream({
            start(e) {
                l && (l.forEach(t => {
                    e.enqueue("string" == typeof t ? O.encode(t) : t)
                }), R && !S) && (null === e.desiredSize || e.desiredSize < 0 ? e.error(Object.defineProperty(Error("The connection to the page was unexpectedly closed, possibly due to the stop button being clicked, loss of Wi-Fi, or an unstable internet connection."), "__NEXT_ERROR_CODE", {
                    value: "E117",
                    enumerable: !1,
                    configurable: !0
                })) : e.close(), S = !0, l = void 0), a = e
            }
        }),
        N = window.__NEXT_CLIENT_RESUME;

    function L(e) {
        let {
            initialRSCPayload: t,
            actionQueue: r,
            webSocket: n,
            staticIndicatorState: o
        } = e;
        return (0, u.jsx)(m.default, {
            actionQueue: r,
            globalErrorState: t.G,
            webSocket: n,
            staticIndicatorState: o
        })
    }
    o = N ? Promise.resolve(w(N, {
        callServer: _.callServer,
        findSourceMapURL: y.findSourceMapURL,
        debugChannel: n
    })).then(async e => (0, j.createInitialRSCPayloadFromFallbackPrerender)(await N, e)) : g(C, {
        callServer: _.callServer,
        findSourceMapURL: y.findSourceMapURL,
        debugChannel: n,
        startTime: 0
    });
    let I = s.default.Fragment;

    function U(e) {
        let {
            children: t
        } = e;
        return t
    }
    let F = {
        onDefaultTransitionIndicator: function() {
            return () => {}
        },
        onRecoverableError: p.onRecoverableError,
        onCaughtError: h.onCaughtError,
        onUncaughtError: h.onUncaughtError
    };
    async function H(e, t) {
        let r, n, l = await o;
        (0, E.setAppBuildId)(l.b);
        let a = Date.now(),
            i = (0, b.createMutableActionQueue)((0, v.createInitialRouterState)({
                navigatedAt: a,
                initialFlightData: l.f,
                initialCanonicalUrlParts: l.c,
                initialRenderedSearch: l.q,
                location: window.location
            }), e),
            c = (0, u.jsx)(I, {
                children: (0, u.jsx)(f.HeadManagerContext.Provider, {
                    value: {
                        appDir: !0
                    },
                    children: (0, u.jsx)(U, {
                        children: (0, u.jsx)(L, {
                            initialRSCPayload: l,
                            actionQueue: i,
                            webSocket: n,
                            staticIndicatorState: r
                        })
                    })
                })
            });
        "__next_error__" === document.documentElement.id ? d.default.createRoot(P, F).render(c) : s.default.startTransition(() => {
            d.default.hydrateRoot(P, c, { ...F,
                formState: x
            })
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 494553, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    let n = e.r(396517);
    e.r(597238), window.next.turbopack = !0, self.__webpack_hash__ = "";
    let o = e.r(5526);
    (0, n.appBootstrap)(t => {
        let {
            hydrate: r
        } = e.r(198569);
        r(o, t)
    }), ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);