(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 190809, (e, t, r) => {
    "use strict";

    function n(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap,
            r = new WeakMap;
        return (n = function(e) {
            return e ? r : t
        })(e)
    }
    r._ = function(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || "object" != typeof e && "function" != typeof e) return {
            default: e
        };
        var r = n(t);
        if (r && r.has(e)) return r.get(e);
        var o = {
                __proto__: null
            },
            u = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var i in e)
            if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
                var c = u ? Object.getOwnPropertyDescriptor(e, i) : null;
                c && (c.get || c.set) ? Object.defineProperty(o, i, c) : o[i] = e[i]
            }
        return o.default = e, r && r.set(e, o), o
    }
}, 476963, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "RedirectStatusCode", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    var n, o = ((n = {})[n.SeeOther = 303] = "SeeOther", n[n.TemporaryRedirect = 307] = "TemporaryRedirect", n[n.PermanentRedirect = 308] = "PermanentRedirect", n);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 968391, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n, o = {
        REDIRECT_ERROR_CODE: function() {
            return c
        },
        RedirectType: function() {
            return a
        },
        isRedirectError: function() {
            return l
        }
    };
    for (var u in o) Object.defineProperty(r, u, {
        enumerable: !0,
        get: o[u]
    });
    let i = e.r(476963),
        c = "NEXT_REDIRECT";
    var a = ((n = {}).push = "push", n.replace = "replace", n);

    function l(e) {
        if ("object" != typeof e || null === e || !("digest" in e) || "string" != typeof e.digest) return !1;
        let t = e.digest.split(";"),
            [r, n] = t,
            o = t.slice(2, -2).join(";"),
            u = Number(t.at(-2));
        return r === c && ("replace" === n || "push" === n) && "string" == typeof o && !isNaN(u) && u in i.RedirectStatusCode
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 621768, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ACTION_HEADER: function() {
            return i
        },
        FLIGHT_HEADERS: function() {
            return y
        },
        NEXT_ACTION_NOT_FOUND_HEADER: function() {
            return m
        },
        NEXT_ACTION_REVALIDATED_HEADER: function() {
            return T
        },
        NEXT_DID_POSTPONE_HEADER: function() {
            return g
        },
        NEXT_HMR_REFRESH_HASH_COOKIE: function() {
            return f
        },
        NEXT_HMR_REFRESH_HEADER: function() {
            return s
        },
        NEXT_HTML_REQUEST_ID_HEADER: function() {
            return R
        },
        NEXT_IS_PRERENDER_HEADER: function() {
            return b
        },
        NEXT_REQUEST_ID_HEADER: function() {
            return O
        },
        NEXT_REWRITTEN_PATH_HEADER: function() {
            return v
        },
        NEXT_REWRITTEN_QUERY_HEADER: function() {
            return h
        },
        NEXT_ROUTER_PREFETCH_HEADER: function() {
            return a
        },
        NEXT_ROUTER_SEGMENT_PREFETCH_HEADER: function() {
            return l
        },
        NEXT_ROUTER_STALE_TIME_HEADER: function() {
            return E
        },
        NEXT_ROUTER_STATE_TREE_HEADER: function() {
            return c
        },
        NEXT_RSC_UNION_QUERY: function() {
            return _
        },
        NEXT_URL: function() {
            return d
        },
        RSC_CONTENT_TYPE_HEADER: function() {
            return p
        },
        RSC_HEADER: function() {
            return u
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = "rsc",
        i = "next-action",
        c = "next-router-state-tree",
        a = "next-router-prefetch",
        l = "next-router-segment-prefetch",
        s = "next-hmr-refresh",
        f = "__next_hmr_refresh_hash__",
        d = "next-url",
        p = "text/x-component",
        y = [u, c, a, s, l],
        _ = "_rsc",
        E = "x-nextjs-stale-time",
        g = "x-nextjs-postponed",
        v = "x-nextjs-rewritten-path",
        h = "x-nextjs-rewritten-query",
        b = "x-nextjs-prerender",
        m = "x-nextjs-action-not-found",
        O = "x-nextjs-request-id",
        R = "x-nextjs-html-request-id",
        T = "x-action-revalidated";
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 813258, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DEFAULT_SEGMENT_KEY: function() {
            return f
        },
        NOT_FOUND_SEGMENT_KEY: function() {
            return d
        },
        PAGE_SEGMENT_KEY: function() {
            return s
        },
        addSearchParamsIfPageSegment: function() {
            return a
        },
        computeSelectedLayoutSegment: function() {
            return l
        },
        getSegmentValue: function() {
            return u
        },
        getSelectedLayoutSegmentPath: function() {
            return function e(t, r) {
                let n, o = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2],
                    i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [];
                if (o) n = t[1][r];
                else {
                    let e = t[1];
                    n = e.children ? ? Object.values(e)[0]
                }
                if (!n) return i;
                let c = u(n[0]);
                return !c || c.startsWith(s) ? i : (i.push(c), e(n, r, !1, i))
            }
        },
        isGroupSegment: function() {
            return i
        },
        isParallelRouteSegment: function() {
            return c
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function u(e) {
        return Array.isArray(e) ? e[1] : e
    }

    function i(e) {
        return "(" === e[0] && e.endsWith(")")
    }

    function c(e) {
        return e.startsWith("@") && "@children" !== e
    }

    function a(e, t) {
        if (e.includes(s)) {
            let e = JSON.stringify(t);
            return "{}" !== e ? s + "?" + e : s
        }
        return e
    }

    function l(e, t) {
        if (!e || 0 === e.length) return null;
        let r = "children" === t ? e[0] : e[e.length - 1];
        return r === f ? null : r
    }
    let s = "__PAGE__",
        f = "__DEFAULT__",
        d = "/_not-found"
}, 292838, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        UnrecognizedActionError: function() {
            return u
        },
        unstable_isUnrecognizedActionError: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    class u extends Error {
        constructor(...e) {
            super(...e), this.name = "UnrecognizedActionError"
        }
    }

    function i(e) {
        return !!(e && "object" == typeof e && e instanceof u)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 134457, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "actionAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(90317).createAsyncLocalStorage)()
}, 362266, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "actionAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.actionAsyncStorageInstance
        }
    });
    let n = e.r(134457)
}, 124063, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getRedirectError: function() {
            return a
        },
        getRedirectStatusCodeFromError: function() {
            return p
        },
        getRedirectTypeFromError: function() {
            return d
        },
        getURLFromRedirectError: function() {
            return f
        },
        permanentRedirect: function() {
            return s
        },
        redirect: function() {
            return l
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(476963),
        i = e.r(968391),
        c = "u" < typeof window ? e.r(362266).actionAsyncStorage : void 0;

    function a(e, t) {
        let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : u.RedirectStatusCode.TemporaryRedirect,
            n = Object.defineProperty(Error(i.REDIRECT_ERROR_CODE), "__NEXT_ERROR_CODE", {
                value: "E394",
                enumerable: !1,
                configurable: !0
            });
        return n.digest = `${i.REDIRECT_ERROR_CODE};${t};${e};${r};`, n
    }

    function l(e, t) {
        throw a(e, t ? ? = c ? .getStore() ? .isAction ? i.RedirectType.push : i.RedirectType.replace, u.RedirectStatusCode.TemporaryRedirect)
    }

    function s(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i.RedirectType.replace;
        throw a(e, t, u.RedirectStatusCode.PermanentRedirect)
    }

    function f(e) {
        return (0, i.isRedirectError)(e) ? e.digest.split(";").slice(2, -2).join(";") : null
    }

    function d(e) {
        if (!(0, i.isRedirectError)(e)) throw Object.defineProperty(Error("Not a redirect error"), "__NEXT_ERROR_CODE", {
            value: "E260",
            enumerable: !1,
            configurable: !0
        });
        return e.digest.split(";", 2)[1]
    }

    function p(e) {
        if (!(0, i.isRedirectError)(e)) throw Object.defineProperty(Error("Not a redirect error"), "__NEXT_ERROR_CODE", {
            value: "E260",
            enumerable: !1,
            configurable: !0
        });
        return Number(e.digest.split(";").at(-2))
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 8372, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        AppRouterContext: function() {
            return i
        },
        GlobalLayoutRouterContext: function() {
            return a
        },
        LayoutRouterContext: function() {
            return c
        },
        MissingSlotContext: function() {
            return s
        },
        TemplateContext: function() {
            return l
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(555682)._(e.r(271645)),
        i = u.default.createContext(null),
        c = u.default.createContext(null),
        a = u.default.createContext(null),
        l = u.default.createContext(null),
        s = u.default.createContext(new Set)
}, 543369, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getDeploymentId: function() {
            return u
        },
        getDeploymentIdQueryOrEmptyString: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function u() {
        return !1
    }

    function i() {
        return ""
    }
}, 132061, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        BailoutToCSRError: function() {
            return i
        },
        isBailoutToCSRError: function() {
            return c
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = "BAILOUT_TO_CLIENT_SIDE_RENDERING";
    class i extends Error {
        constructor(e) {
            super(`Bail out to client-side rendering: ${e}`), this.reason = e, this.digest = u
        }
    }

    function c(e) {
        return "object" == typeof e && null !== e && "digest" in e && e.digest === u
    }
}, 242344, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(90317).createAsyncLocalStorage)()
}, 563599, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.workAsyncStorageInstance
        }
    });
    let n = e.r(242344)
}, 818800, (e, t, r) => {
    "use strict";
    var n = e.r(271645);

    function o(e) {
        var t = "https://react.dev/errors/" + e;
        if (1 < arguments.length) {
            t += "?args[]=" + encodeURIComponent(arguments[1]);
            for (var r = 2; r < arguments.length; r++) t += "&args[]=" + encodeURIComponent(arguments[r])
        }
        return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }

    function u() {}
    var i = {
            d: {
                f: u,
                r: function() {
                    throw Error(o(522))
                },
                D: u,
                C: u,
                L: u,
                m: u,
                X: u,
                S: u,
                M: u
            },
            p: 0,
            findDOMNode: null
        },
        c = Symbol.for("react.portal"),
        a = Symbol.for("react.optimistic_key"),
        l = n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

    function s(e, t) {
        return "font" === e ? "" : "string" == typeof t ? "use-credentials" === t ? t : "" : void 0
    }
    r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = i, r.createPortal = function(e, t) {
        var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
        if (!t || 1 !== t.nodeType && 9 !== t.nodeType && 11 !== t.nodeType) throw Error(o(299));
        return function(e, t, r) {
            var n = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
            return {
                $$typeof: c,
                key: null == n ? null : n === a ? a : "" + n,
                children: e,
                containerInfo: t,
                implementation: r
            }
        }(e, t, null, r)
    }, r.flushSync = function(e) {
        var t = l.T,
            r = i.p;
        try {
            if (l.T = null, i.p = 2, e) return e()
        } finally {
            l.T = t, i.p = r, i.d.f()
        }
    }, r.preconnect = function(e, t) {
        "string" == typeof e && (t = t ? "string" == typeof(t = t.crossOrigin) ? "use-credentials" === t ? t : "" : void 0 : null, i.d.C(e, t))
    }, r.prefetchDNS = function(e) {
        "string" == typeof e && i.d.D(e)
    }, r.preinit = function(e, t) {
        if ("string" == typeof e && t && "string" == typeof t.as) {
            var r = t.as,
                n = s(r, t.crossOrigin),
                o = "string" == typeof t.integrity ? t.integrity : void 0,
                u = "string" == typeof t.fetchPriority ? t.fetchPriority : void 0;
            "style" === r ? i.d.S(e, "string" == typeof t.precedence ? t.precedence : void 0, {
                crossOrigin: n,
                integrity: o,
                fetchPriority: u
            }) : "script" === r && i.d.X(e, {
                crossOrigin: n,
                integrity: o,
                fetchPriority: u,
                nonce: "string" == typeof t.nonce ? t.nonce : void 0
            })
        }
    }, r.preinitModule = function(e, t) {
        if ("string" == typeof e)
            if ("object" == typeof t && null !== t) {
                if (null == t.as || "script" === t.as) {
                    var r = s(t.as, t.crossOrigin);
                    i.d.M(e, {
                        crossOrigin: r,
                        integrity: "string" == typeof t.integrity ? t.integrity : void 0,
                        nonce: "string" == typeof t.nonce ? t.nonce : void 0
                    })
                }
            } else null == t && i.d.M(e)
    }, r.preload = function(e, t) {
        if ("string" == typeof e && "object" == typeof t && null !== t && "string" == typeof t.as) {
            var r = t.as,
                n = s(r, t.crossOrigin);
            i.d.L(e, r, {
                crossOrigin: n,
                integrity: "string" == typeof t.integrity ? t.integrity : void 0,
                nonce: "string" == typeof t.nonce ? t.nonce : void 0,
                type: "string" == typeof t.type ? t.type : void 0,
                fetchPriority: "string" == typeof t.fetchPriority ? t.fetchPriority : void 0,
                referrerPolicy: "string" == typeof t.referrerPolicy ? t.referrerPolicy : void 0,
                imageSrcSet: "string" == typeof t.imageSrcSet ? t.imageSrcSet : void 0,
                imageSizes: "string" == typeof t.imageSizes ? t.imageSizes : void 0,
                media: "string" == typeof t.media ? t.media : void 0
            })
        }
    }, r.preloadModule = function(e, t) {
        if ("string" == typeof e)
            if (t) {
                var r = s(t.as, t.crossOrigin);
                i.d.m(e, {
                    as: "string" == typeof t.as && "script" !== t.as ? t.as : void 0,
                    crossOrigin: r,
                    integrity: "string" == typeof t.integrity ? t.integrity : void 0
                })
            } else i.d.m(e)
    }, r.requestFormReset = function(e) {
        i.d.r(e)
    }, r.unstable_batchedUpdates = function(e, t) {
        return e(t)
    }, r.useFormState = function(e, t, r) {
        return l.H.useFormState(e, t, r)
    }, r.useFormStatus = function() {
        return l.H.useHostTransitionStatus()
    }, r.version = "19.3.0-canary-f93b9fd4-20251217"
}, 174080, (e, t, r) => {
    "use strict";
    ! function e() {
        if ("u" > typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" == typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE) try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)
        } catch (e) {
            console.error(e)
        }
    }(), t.exports = e.r(818800)
}, 935451, (e, t, r) => {
    var n = {
            229: function(e) {
                var t, r, n, o = e.exports = {};

                function u() {
                    throw Error("setTimeout has not been defined")
                }

                function i() {
                    throw Error("clearTimeout has not been defined")
                }
                try {
                    t = "function" == typeof setTimeout ? setTimeout : u
                } catch (e) {
                    t = u
                }
                try {
                    r = "function" == typeof clearTimeout ? clearTimeout : i
                } catch (e) {
                    r = i
                }

                function c(e) {
                    if (t === setTimeout) return setTimeout(e, 0);
                    if ((t === u || !t) && setTimeout) return t = setTimeout, setTimeout(e, 0);
                    try {
                        return t(e, 0)
                    } catch (r) {
                        try {
                            return t.call(null, e, 0)
                        } catch (r) {
                            return t.call(this, e, 0)
                        }
                    }
                }
                var a = [],
                    l = !1,
                    s = -1;

                function f() {
                    l && n && (l = !1, n.length ? a = n.concat(a) : s = -1, a.length && d())
                }

                function d() {
                    if (!l) {
                        var e = c(f);
                        l = !0;
                        for (var t = a.length; t;) {
                            for (n = a, a = []; ++s < t;) n && n[s].run();
                            s = -1, t = a.length
                        }
                        n = null, l = !1,
                            function(e) {
                                if (r === clearTimeout) return clearTimeout(e);
                                if ((r === i || !r) && clearTimeout) return r = clearTimeout, clearTimeout(e);
                                try {
                                    r(e)
                                } catch (t) {
                                    try {
                                        return r.call(null, e)
                                    } catch (t) {
                                        return r.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function p(e, t) {
                    this.fun = e, this.array = t
                }

                function y() {}
                o.nextTick = function(e) {
                    var t = Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                    a.push(new p(e, t)), 1 !== a.length || l || c(d)
                }, p.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, o.title = "browser", o.browser = !0, o.env = {}, o.argv = [], o.version = "", o.versions = {}, o.on = y, o.addListener = y, o.once = y, o.off = y, o.removeListener = y, o.removeAllListeners = y, o.emit = y, o.prependListener = y, o.prependOnceListener = y, o.listeners = function(e) {
                    return []
                }, o.binding = function(e) {
                    throw Error("process.binding is not supported")
                }, o.cwd = function() {
                    return "/"
                }, o.chdir = function(e) {
                    throw Error("process.chdir is not supported")
                }, o.umask = function() {
                    return 0
                }
            }
        },
        o = {};

    function u(e) {
        var t = o[e];
        if (void 0 !== t) return t.exports;
        var r = o[e] = {
                exports: {}
            },
            i = !0;
        try {
            n[e](r, r.exports, u), i = !1
        } finally {
            i && delete o[e]
        }
        return r.exports
    }
    u.ab = "/ROOT/node_modules/next/dist/compiled/process/", t.exports = u(229)
}, 247167, (e, t, r) => {
    "use strict";
    var n, o;
    t.exports = (null == (n = e.g.process) ? void 0 : n.env) && "object" == typeof(null == (o = e.g.process) ? void 0 : o.env) ? e.g.process : e.r(935451)
}, 745689, (e, t, r) => {
    "use strict";
    var n = Symbol.for("react.transitional.element");

    function o(e, t, r) {
        var o = null;
        if (void 0 !== r && (o = "" + r), void 0 !== t.key && (o = "" + t.key), "key" in t)
            for (var u in r = {}, t) "key" !== u && (r[u] = t[u]);
        else r = t;
        return {
            $$typeof: n,
            type: e,
            key: o,
            ref: void 0 !== (t = r.ref) ? t : null,
            props: r
        }
    }
    r.Fragment = Symbol.for("react.fragment"), r.jsx = o, r.jsxs = o
}, 843476, (e, t, r) => {
    "use strict";
    t.exports = e.r(745689)
}, 350740, (e, t, r) => {
    "use strict";
    var n = e.i(247167),
        o = Symbol.for("react.transitional.element"),
        u = Symbol.for("react.portal"),
        i = Symbol.for("react.fragment"),
        c = Symbol.for("react.strict_mode"),
        a = Symbol.for("react.profiler"),
        l = Symbol.for("react.consumer"),
        s = Symbol.for("react.context"),
        f = Symbol.for("react.forward_ref"),
        d = Symbol.for("react.suspense"),
        p = Symbol.for("react.memo"),
        y = Symbol.for("react.lazy"),
        _ = Symbol.for("react.activity"),
        E = Symbol.for("react.view_transition"),
        g = Symbol.iterator,
        v = {
            isMounted: function() {
                return !1
            },
            enqueueForceUpdate: function() {},
            enqueueReplaceState: function() {},
            enqueueSetState: function() {}
        },
        h = Object.assign,
        b = {};

    function m(e, t, r) {
        this.props = e, this.context = t, this.refs = b, this.updater = r || v
    }

    function O() {}

    function R(e, t, r) {
        this.props = e, this.context = t, this.refs = b, this.updater = r || v
    }
    m.prototype.isReactComponent = {}, m.prototype.setState = function(e, t) {
        if ("object" != typeof e && "function" != typeof e && null != e) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, e, t, "setState")
    }, m.prototype.forceUpdate = function(e) {
        this.updater.enqueueForceUpdate(this, e, "forceUpdate")
    }, O.prototype = m.prototype;
    var T = R.prototype = new O;
    T.constructor = R, h(T, m.prototype), T.isPureReactComponent = !0;
    var S = Array.isArray;

    function j() {}
    var P = {
            H: null,
            A: null,
            T: null,
            S: null
        },
        A = Object.prototype.hasOwnProperty;

    function x(e, t, r) {
        var n = r.ref;
        return {
            $$typeof: o,
            type: e,
            key: t,
            ref: void 0 !== n ? n : null,
            props: r
        }
    }

    function N(e) {
        return "object" == typeof e && null !== e && e.$$typeof === o
    }
    var w = /\/+/g;

    function M(e, t) {
        var r, n;
        return "object" == typeof e && null !== e && null != e.key ? (r = "" + e.key, n = {
            "=": "=0",
            ":": "=2"
        }, "$" + r.replace(/[=:]/g, function(e) {
            return n[e]
        })) : t.toString(36)
    }

    function C(e, t, r) {
        if (null == e) return e;
        var n = [],
            i = 0;
        return ! function e(t, r, n, i, c) {
            var a, l, s, f = typeof t;
            ("undefined" === f || "boolean" === f) && (t = null);
            var d = !1;
            if (null === t) d = !0;
            else switch (f) {
                case "bigint":
                case "string":
                case "number":
                    d = !0;
                    break;
                case "object":
                    switch (t.$$typeof) {
                        case o:
                        case u:
                            d = !0;
                            break;
                        case y:
                            return e((d = t._init)(t._payload), r, n, i, c)
                    }
            }
            if (d) return c = c(t), d = "" === i ? "." + M(t, 0) : i, S(c) ? (n = "", null != d && (n = d.replace(w, "$&/") + "/"), e(c, r, n, "", function(e) {
                return e
            })) : null != c && (N(c) && (a = c, l = n + (null == c.key || t && t.key === c.key ? "" : ("" + c.key).replace(w, "$&/") + "/") + d, c = x(a.type, l, a.props)), r.push(c)), 1;
            d = 0;
            var p = "" === i ? "." : i + ":";
            if (S(t))
                for (var _ = 0; _ < t.length; _++) f = p + M(i = t[_], _), d += e(i, r, n, f, c);
            else if ("function" == typeof(_ = null === (s = t) || "object" != typeof s ? null : "function" == typeof(s = g && s[g] || s["@@iterator"]) ? s : null))
                for (t = _.call(t), _ = 0; !(i = t.next()).done;) f = p + M(i = i.value, _++), d += e(i, r, n, f, c);
            else if ("object" === f) {
                if ("function" == typeof t.then) return e(function(e) {
                    switch (e.status) {
                        case "fulfilled":
                            return e.value;
                        case "rejected":
                            throw e.reason;
                        default:
                            switch ("string" == typeof e.status ? e.then(j, j) : (e.status = "pending", e.then(function(t) {
                                "pending" === e.status && (e.status = "fulfilled", e.value = t)
                            }, function(t) {
                                "pending" === e.status && (e.status = "rejected", e.reason = t)
                            })), e.status) {
                                case "fulfilled":
                                    return e.value;
                                case "rejected":
                                    throw e.reason
                            }
                    }
                    throw e
                }(t), r, n, i, c);
                throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === (r = String(t)) ? "object with keys {" + Object.keys(t).join(", ") + "}" : r) + "). If you meant to render a collection of children, use an array instead.")
            }
            return d
        }(e, n, "", "", function(e) {
            return t.call(r, e, i++)
        }), n
    }

    function D(e) {
        if (-1 === e._status) {
            var t = e._result;
            (t = t()).then(function(t) {
                (0 === e._status || -1 === e._status) && (e._status = 1, e._result = t)
            }, function(t) {
                (0 === e._status || -1 === e._status) && (e._status = 2, e._result = t)
            }), -1 === e._status && (e._status = 0, e._result = t)
        }
        if (1 === e._status) return e._result.default;
        throw e._result
    }
    var H = "function" == typeof reportError ? reportError : function(e) {
        if ("object" == typeof window && "function" == typeof window.ErrorEvent) {
            var t = new window.ErrorEvent("error", {
                bubbles: !0,
                cancelable: !0,
                message: "object" == typeof e && null !== e && "string" == typeof e.message ? String(e.message) : String(e),
                error: e
            });
            if (!window.dispatchEvent(t)) return
        } else if ("object" == typeof n.default && "function" == typeof n.default.emit) return void n.default.emit("uncaughtException", e);
        console.error(e)
    };

    function U(e) {
        var t = P.T,
            r = {};
        r.types = null !== t ? t.types : null, P.T = r;
        try {
            var n = e(),
                o = P.S;
            null !== o && o(r, n), "object" == typeof n && null !== n && "function" == typeof n.then && n.then(j, H)
        } catch (e) {
            H(e)
        } finally {
            null !== t && null !== r.types && (t.types = r.types), P.T = t
        }
    }

    function I(e) {
        var t = P.T;
        if (null !== t) {
            var r = t.types;
            null === r ? t.types = [e] : -1 === r.indexOf(e) && r.push(e)
        } else U(I.bind(null, e))
    }
    r.Activity = _, r.Children = {
        map: C,
        forEach: function(e, t, r) {
            C(e, function() {
                t.apply(this, arguments)
            }, r)
        },
        count: function(e) {
            var t = 0;
            return C(e, function() {
                t++
            }), t
        },
        toArray: function(e) {
            return C(e, function(e) {
                return e
            }) || []
        },
        only: function(e) {
            if (!N(e)) throw Error("React.Children.only expected to receive a single React element child.");
            return e
        }
    }, r.Component = m, r.Fragment = i, r.Profiler = a, r.PureComponent = R, r.StrictMode = c, r.Suspense = d, r.ViewTransition = E, r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = P, r.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function(e) {
            return P.H.useMemoCache(e)
        }
    }, r.addTransitionType = I, r.cache = function(e) {
        return function() {
            return e.apply(null, arguments)
        }
    }, r.cacheSignal = function() {
        return null
    }, r.cloneElement = function(e, t, r) {
        if (null == e) throw Error("The argument must be a React element, but you passed " + e + ".");
        var n = h({}, e.props),
            o = e.key;
        if (null != t)
            for (u in void 0 !== t.key && (o = "" + t.key), t) A.call(t, u) && "key" !== u && "__self" !== u && "__source" !== u && ("ref" !== u || void 0 !== t.ref) && (n[u] = t[u]);
        var u = arguments.length - 2;
        if (1 === u) n.children = r;
        else if (1 < u) {
            for (var i = Array(u), c = 0; c < u; c++) i[c] = arguments[c + 2];
            n.children = i
        }
        return x(e.type, o, n)
    }, r.createContext = function(e) {
        return (e = {
            $$typeof: s,
            _currentValue: e,
            _currentValue2: e,
            _threadCount: 0,
            Provider: null,
            Consumer: null
        }).Provider = e, e.Consumer = {
            $$typeof: l,
            _context: e
        }, e
    }, r.createElement = function(e, t, r) {
        var n, o = {},
            u = null;
        if (null != t)
            for (n in void 0 !== t.key && (u = "" + t.key), t) A.call(t, n) && "key" !== n && "__self" !== n && "__source" !== n && (o[n] = t[n]);
        var i = arguments.length - 2;
        if (1 === i) o.children = r;
        else if (1 < i) {
            for (var c = Array(i), a = 0; a < i; a++) c[a] = arguments[a + 2];
            o.children = c
        }
        if (e && e.defaultProps)
            for (n in i = e.defaultProps) void 0 === o[n] && (o[n] = i[n]);
        return x(e, u, o)
    }, r.createRef = function() {
        return {
            current: null
        }
    }, r.forwardRef = function(e) {
        return {
            $$typeof: f,
            render: e
        }
    }, r.isValidElement = N, r.lazy = function(e) {
        return {
            $$typeof: y,
            _payload: {
                _status: -1,
                _result: e
            },
            _init: D
        }
    }, r.memo = function(e, t) {
        return {
            $$typeof: p,
            type: e,
            compare: void 0 === t ? null : t
        }
    }, r.startTransition = U, r.unstable_useCacheRefresh = function() {
        return P.H.useCacheRefresh()
    }, r.use = function(e) {
        return P.H.use(e)
    }, r.useActionState = function(e, t, r) {
        return P.H.useActionState(e, t, r)
    }, r.useCallback = function(e, t) {
        return P.H.useCallback(e, t)
    }, r.useContext = function(e) {
        return P.H.useContext(e)
    }, r.useDebugValue = function() {}, r.useDeferredValue = function(e, t) {
        return P.H.useDeferredValue(e, t)
    }, r.useEffect = function(e, t) {
        return P.H.useEffect(e, t)
    }, r.useEffectEvent = function(e) {
        return P.H.useEffectEvent(e)
    }, r.useId = function() {
        return P.H.useId()
    }, r.useImperativeHandle = function(e, t, r) {
        return P.H.useImperativeHandle(e, t, r)
    }, r.useInsertionEffect = function(e, t) {
        return P.H.useInsertionEffect(e, t)
    }, r.useLayoutEffect = function(e, t) {
        return P.H.useLayoutEffect(e, t)
    }, r.useMemo = function(e, t) {
        return P.H.useMemo(e, t)
    }, r.useOptimistic = function(e, t) {
        return P.H.useOptimistic(e, t)
    }, r.useReducer = function(e, t, r) {
        return P.H.useReducer(e, t, r)
    }, r.useRef = function(e) {
        return P.H.useRef(e)
    }, r.useState = function(e) {
        return P.H.useState(e)
    }, r.useSyncExternalStore = function(e, t, r) {
        return P.H.useSyncExternalStore(e, t, r)
    }, r.useTransition = function() {
        return P.H.useTransition()
    }, r.version = "19.3.0-canary-f93b9fd4-20251217"
}, 271645, (e, t, r) => {
    "use strict";
    t.exports = e.r(350740)
}, 555682, (e, t, r) => {
    "use strict";
    r._ = function(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
}, 90317, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        bindSnapshot: function() {
            return l
        },
        createAsyncLocalStorage: function() {
            return a
        },
        createSnapshot: function() {
            return s
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = Object.defineProperty(Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available"), "__NEXT_ERROR_CODE", {
        value: "E504",
        enumerable: !1,
        configurable: !0
    });
    class i {
        disable() {
            throw u
        }
        getStore() {}
        run() {
            throw u
        }
        exit() {
            throw u
        }
        enterWith() {
            throw u
        }
        static bind(e) {
            return e
        }
    }
    let c = "u" > typeof globalThis && globalThis.AsyncLocalStorage;

    function a() {
        return c ? new c : new i
    }

    function l(e) {
        return c ? c.bind(e) : i.bind(e)
    }

    function s() {
        return c ? c.snapshot() : function(e) {
            for (var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
            return e(...r)
        }
    }
}, 590373, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useUntrackedPathname", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(271645),
        o = e.r(261994);

    function u() {
        return ! function() {
            if ("u" < typeof window) {
                let {
                    workUnitAsyncStorage: t
                } = e.r(662141), r = t.getStore();
                if (!r) return !1;
                switch (r.type) {
                    case "prerender":
                    case "prerender-client":
                    case "prerender-ppr":
                        let n = r.fallbackRouteParams;
                        return !!n && n.size > 0
                }
            }
            return !1
        }() ? (0, n.useContext)(o.PathnameContext) : null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 178377, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        handleHardNavError: function() {
            return i
        },
        useNavFailureHandler: function() {
            return c
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    e.r(271645);
    let u = e.r(451191);

    function i(e) {
        return !!(e && "u" > typeof window) && !!window.next.__pendingUrl && (0, u.createHrefFromUrl)(new URL(window.location.href)) !== (0, u.createHrefFromUrl)(window.next.__pendingUrl) && (console.error("Error occurred during navigation, falling back to hard navigation", e), window.location.href = window.next.__pendingUrl.toString(), !0)
    }

    function c() {}("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 912354, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "HandleISRError", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = "u" < typeof window ? e.r(563599).workAsyncStorage : void 0;

    function o(e) {
        let {
            error: t
        } = e;
        if (n) {
            let e = n.getStore();
            if (e ? .isStaticGeneration) throw t && console.error(t), t
        }
        return null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 972383, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ErrorBoundary: function() {
            return y
        },
        ErrorBoundaryHandler: function() {
            return p
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(555682),
        i = e.r(843476),
        c = u._(e.r(271645)),
        a = e.r(590373),
        l = e.r(265713);
    e.r(178377);
    let s = e.r(912354),
        f = e.r(82604),
        d = "u" > typeof window && (0, f.isBot)(window.navigator.userAgent);
    class p extends c.default.Component {
        constructor(e) {
            super(e), this.reset = () => {
                this.setState({
                    error: null
                })
            }, this.state = {
                error: null,
                previousPathname: this.props.pathname
            }
        }
        static getDerivedStateFromError(e) {
            if ((0, l.isNextRouterError)(e)) throw e;
            return {
                error: e
            }
        }
        static getDerivedStateFromProps(e, t) {
            let {
                error: r
            } = t;
            return e.pathname !== t.previousPathname && t.error ? {
                error: null,
                previousPathname: e.pathname
            } : {
                error: t.error,
                previousPathname: e.pathname
            }
        }
        render() {
            return this.state.error && !d ? (0, i.jsxs)(i.Fragment, {
                children: [(0, i.jsx)(s.HandleISRError, {
                    error: this.state.error
                }), this.props.errorStyles, this.props.errorScripts, (0, i.jsx)(this.props.errorComponent, {
                    error: this.state.error,
                    reset: this.reset
                })]
            }) : this.props.children
        }
    }

    function y(e) {
        let {
            errorComponent: t,
            errorStyles: r,
            errorScripts: n,
            children: o
        } = e, u = (0, a.useUntrackedPathname)();
        return t ? (0, i.jsx)(p, {
            pathname: u,
            errorComponent: t,
            errorStyles: r,
            errorScripts: n,
            children: o
        }) : (0, i.jsx)(i.Fragment, {
            children: o
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 358442, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        RedirectBoundary: function() {
            return p
        },
        RedirectErrorBoundary: function() {
            return d
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(190809),
        i = e.r(843476),
        c = u._(e.r(271645)),
        a = e.r(976562),
        l = e.r(124063),
        s = e.r(968391);

    function f(e) {
        let {
            redirect: t,
            reset: r,
            redirectType: n
        } = e, o = (0, a.useRouter)();
        return (0, c.useEffect)(() => {
            c.default.startTransition(() => {
                n === s.RedirectType.push ? o.push(t, {}) : o.replace(t, {}), r()
            })
        }, [t, n, r, o]), null
    }
    class d extends c.default.Component {
        constructor(e) {
            super(e), this.state = {
                redirect: null,
                redirectType: null
            }
        }
        static getDerivedStateFromError(e) {
            if ((0, s.isRedirectError)(e)) {
                let t = (0, l.getURLFromRedirectError)(e),
                    r = (0, l.getRedirectTypeFromError)(e);
                return "handled" in e ? {
                    redirect: null,
                    redirectType: null
                } : {
                    redirect: t,
                    redirectType: r
                }
            }
            throw e
        }
        render() {
            let {
                redirect: e,
                redirectType: t
            } = this.state;
            return null !== e && null !== t ? (0, i.jsx)(f, {
                redirect: e,
                redirectType: t,
                reset: () => this.setState({
                    redirect: null
                })
            }) : this.props.children
        }
    }

    function p(e) {
        let {
            children: t
        } = e, r = (0, a.useRouter)();
        return (0, i.jsx)(d, {
            router: r,
            children: t
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 201244, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unresolvedThenable", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = {
        then: () => {}
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 897367, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        MetadataBoundary: function() {
            return c
        },
        OutletBoundary: function() {
            return l
        },
        RootLayoutBoundary: function() {
            return s
        },
        ViewportBoundary: function() {
            return a
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(954839),
        i = {
            [u.METADATA_BOUNDARY_NAME]: function(e) {
                let {
                    children: t
                } = e;
                return t
            },
            [u.VIEWPORT_BOUNDARY_NAME]: function(e) {
                let {
                    children: t
                } = e;
                return t
            },
            [u.OUTLET_BOUNDARY_NAME]: function(e) {
                let {
                    children: t
                } = e;
                return t
            },
            [u.ROOT_LAYOUT_BOUNDARY_NAME]: function(e) {
                let {
                    children: t
                } = e;
                return t
            }
        },
        c = i[u.METADATA_BOUNDARY_NAME.slice(0)],
        a = i[u.VIEWPORT_BOUNDARY_NAME.slice(0)],
        l = i[u.OUTLET_BOUNDARY_NAME.slice(0)],
        s = i[u.ROOT_LAYOUT_BOUNDARY_NAME.slice(0)]
}]);