(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 306590, e => {
    e.v({
        loader: "index-module-scss-module__tgciYa__loader",
        overlay: "index-module-scss-module__tgciYa__overlay",
        spin: "index-module-scss-module__tgciYa__spin",
        "vid-ctn": "index-module-scss-module__tgciYa__vid-ctn"
    })
}, 548618, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645),
        n = Object.defineProperty,
        i = new Map,
        s = new WeakMap,
        o = 0,
        l = void 0;
    r.Component;
    var u = e.i(770703),
        c = e.i(731270),
        a = e.i(501859),
        d = e.i(306590);
    let f = (0, u.default)(() => e.A(744636), {
        loadableGenerated: {
            modules: [913665]
        },
        ssr: !1
    });

    function h(e) {
        let {
            videoSrc: n,
            videoId: u,
            thumbUrl: h = "",
            classes: m = "",
            aspectRatio: v = "unset",
            playInview: p = !0
        } = e, y = (0, r.useRef)(null), g = (0, r.useRef)(null), [b, _] = (0, r.useState)(!1), [R, w] = (0, r.useState)(!1), E = (0, r.useRef)(!1), {
            ref: x,
            inView: S
        } = function() {
            var e;
            let {
                threshold: t,
                delay: n,
                trackVisibility: u,
                rootMargin: c,
                root: a,
                triggerOnce: d,
                skip: f,
                initialInView: h,
                fallbackInView: m,
                onChange: v
            } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, [p, y] = r.useState(null), g = r.useRef(v), [b, _] = r.useState({
                inView: !!h,
                entry: void 0
            });
            g.current = v, r.useEffect(() => {
                let e;
                if (!f && p) return e = function(e, t) {
                    let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : l;
                    if (void 0 === window.IntersectionObserver && void 0 !== n) {
                        let i = e.getBoundingClientRect();
                        return t(n, {
                            isIntersecting: n,
                            target: e,
                            intersectionRatio: "number" == typeof r.threshold ? r.threshold : 0,
                            time: 0,
                            boundingClientRect: i,
                            intersectionRect: i,
                            rootBounds: i
                        }), () => {}
                    }
                    let {
                        id: u,
                        observer: c,
                        elements: a
                    } = function(e) {
                        let t = Object.keys(e).sort().filter(t => void 0 !== e[t]).map(t => {
                                var r;
                                return `${t}_${"root"===t?!(r=e.root)?"0":(s.has(r)||(o+=1,s.set(r,o.toString())),s.get(r)):e[t]}`
                            }).toString(),
                            r = i.get(t);
                        if (!r) {
                            let n, s = new Map,
                                o = new IntersectionObserver(t => {
                                    t.forEach(t => {
                                        var r;
                                        let i = t.isIntersecting && n.some(e => t.intersectionRatio >= e);
                                        e.trackVisibility && void 0 === t.isVisible && (t.isVisible = i), null == (r = s.get(t.target)) || r.forEach(e => {
                                            e(i, t)
                                        })
                                    })
                                }, e);
                            n = o.thresholds || (Array.isArray(e.threshold) ? e.threshold : [e.threshold || 0]), r = {
                                id: t,
                                observer: o,
                                elements: s
                            }, i.set(t, r)
                        }
                        return r
                    }(r), d = a.get(e) || [];
                    return a.has(e) || a.set(e, d), d.push(t), c.observe(e),
                        function() {
                            d.splice(d.indexOf(t), 1), 0 === d.length && (a.delete(e), c.unobserve(e)), 0 === a.size && (c.disconnect(), i.delete(u))
                        }
                }(p, (t, r) => {
                    _({
                        inView: t,
                        entry: r
                    }), g.current && g.current(t, r), r.isIntersecting && d && e && (e(), e = void 0)
                }, {
                    root: a,
                    rootMargin: c,
                    threshold: t,
                    trackVisibility: u,
                    delay: n
                }, m), () => {
                    e && e()
                }
            }, [Array.isArray(t) ? t.toString() : t, p, a, c, d, f, u, m, n]);
            let R = null == (e = b.entry) ? void 0 : e.target,
                w = r.useRef(void 0);
            p || !R || d || f || w.current === R || (w.current = R, _({
                inView: !!h,
                entry: void 0
            }));
            let E = [y, b.inView, b.entry];
            return E.ref = E[0], E.inView = E[1], E.entry = E[2], E
        }({
            threshold: .8
        }), {
            setVolume: j,
            volume: A
        } = (0, c.useMainThemeLayout)();
        return (0, r.useEffect)(() => {
            if (!y.current) return;
            let e = e => {
                    "pause" === e.type && _(!1), "play" === e.type && (_(!0), E.current = !0, document.querySelectorAll("audio").forEach(e => {
                        e.id !== u && e.pause()
                    }), document.querySelectorAll("video").forEach(e => {
                        e.id !== u && e.pause()
                    }))
                },
                t = y.current;
            return t.onplay = e, t.onpause = e, () => {
                t && (t.onplay = null, t.onpause = null)
            }
        }, [u]), (0, r.useEffect)(() => {
            if (!y.current) return;
            let e = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement;
            if (!p || e) return;
            let t = y.current;
            S && t.paused ? t.play().catch(e => console.error("Auto-play error:", e)) : !S && E.current && setTimeout(() => {
                t && !t.paused && t.pause()
            }, 100)
        }, [S, p]), (0, r.useEffect)(() => {
            if (!y.current) return;
            let e = A || 0;
            y.current.volume = e, y.current.muted = 0 === e
        }, [A]), (0, t.jsxs)("div", {
            id: `container_${u}`,
            ref: e => {
                x(e), g.current = e
            },
            className: `${d.default["vid-ctn"]} ${m}`,
            children: [!b && !R && (0, t.jsx)(a.RiLoader2Line, {
                className: d.default.loader
            }), (0, t.jsx)("video", {
                "aria-hidden": !0,
                onClick: () => {
                    y.current && (y.current.paused ? y.current.play().catch(e => console.error("Play error:", e)) : y.current.pause())
                },
                onCanPlayThrough: () => {
                    w(!0)
                },
                id: u || "video_player",
                width: "100%",
                height: "auto",
                playsInline: !0,
                loop: !1,
                muted: 0 === (A || 0),
                controls: !1,
                preload: "metadata",
                ref: y,
                style: {
                    aspectRatio: v,
                    maxHeight: "unset" !== v ? `calc(100vw * ${v})` : void 0,
                    height: h ? 580 : "auto"
                },
                src: n
            }), (0, t.jsx)("div", {
                className: d.default.overlay,
                style: h ? {
                    backgroundImage: `url(${h})`
                } : {}
            }), y.current && g.current && (0, t.jsx)(f, {
                playerRef: y.current,
                containerRef: g.current,
                isPlaying: b,
                setVolume: j,
                volume: A
            })]
        })
    }
    e.s(["default", () => h], 548618)
}, 658130, e => {
    e.n(e.i(548618))
}, 744636, e => {
    e.v(t => Promise.all(["static/chunks/1fc3488b4f1477fe.js", "static/chunks/a0a3d19144982ec2.js", "static/chunks/b3d046baf9220cfe.css"].map(t => e.l(t))).then(() => t(913665)))
}]);