(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 23067, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        uploadPhoto(e, r, t) {
            return this.upload("/performer/products/photo/upload", [{
                fieldname: "file",
                file: e
            }], {
                onProgress: t,
                customData: r
            })
        }
        createProduct(e, r, t) {
            return this.upload("/performer/products", e, {
                onProgress: t,
                customData: r
            })
        }
        update(e, r, t, s) {
            return this.upload(`/performer/products/${e}`, r, {
                onProgress: s,
                customData: t,
                method: "PUT"
            })
        }
        search(e) {
            return this.get((0, r.buildUrl)("/performer/products/search", e))
        }
        performerSearchUrl() {
            return "/performer/products/search"
        }
        userSearch(e) {
            return this.get((0, r.buildUrl)("/products/search", e))
        }
        userView(e, r) {
            return this.get(`/products/${e}`, r)
        }
        findById(e) {
            let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return this.get(`/performer/products/${e}/view`, r)
        }
        delete(e) {
            return this.del(`/performer/products/${e}`)
        }
        getBookmarked(e) {
            return this.get((0, r.buildUrl)("/reactions/products/bookmark", e))
        }
        increaseView(e) {
            return this.post(`/products/${e}/view`)
        }
    }
    let i = new s;
    e.s(["productService", 0, i])
}, 579844, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        uploadAudio(e, r, t) {
            return this.upload("/performer/feeds/audio/upload", [{
                fieldname: "file",
                file: e
            }], {
                onProgress: t,
                customData: r
            })
        }
        uploadPhoto(e, r, t) {
            return this.upload("/performer/feeds/photo/upload", [{
                fieldname: "file",
                file: e
            }], {
                onProgress: t,
                customData: r
            })
        }
        uploadThumbnail(e, r, t) {
            return this.upload("/performer/feeds/thumbnail/upload", [{
                fieldname: "file",
                file: e
            }], {
                onProgress: t,
                customData: r
            })
        }
        uploadVideo(e, r, t) {
            return this.upload("/performer/feeds/video/upload", [{
                fieldname: "file",
                file: e
            }], {
                onProgress: t,
                customData: r
            })
        }
        uploadTeaser(e, r, t) {
            return this.upload("/performer/feeds/teaser/upload", [{
                fieldname: "file",
                file: e
            }], {
                onProgress: t,
                customData: r
            })
        }
        create(e) {
            return this.post("/performer/feeds", e)
        }
        search(e) {
            return this.get((0, r.buildUrl)("/performer/feeds", e))
        }
        performerSearchUrl() {
            return "/performer/feeds"
        }
        update(e, r) {
            return this.put(`/performer/feeds/${e}`, r)
        }
        delete(e) {
            return this.del(`/performer/feeds/${e}`)
        }
        findById(e, r) {
            return this.get(`/performer/feeds/${e}`, r)
        }
        addPoll(e) {
            return this.post("/performer/feeds/polls", e)
        }
        userSearch(e) {
            let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return this.get((0, r.buildUrl)("/feeds", e), t)
        }
        userSearchWithUsername(e, t) {
            let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            return this.get((0, r.buildUrl)(`/feeds/search/${e}`, t), s)
        }
        findOne(e, r) {
            return this.get(`/feeds/${e}`, r)
        }
        votePoll(e) {
            return this.post(`/feeds/vote/${e}`)
        }
        getBookmark(e) {
            return this.get((0, r.buildUrl)("/reactions/feeds/bookmark", e))
        }
        getVideoFileStatus(e, r) {
            return this.get(`/feeds/${e}/file/${r}/status`)
        }
    }
    let i = new s;
    e.s(["feedService", 0, i])
}, 670357, 494792, 331849, e => {
    "use strict";
    e.i(944779), e.i(382526), e.i(872649), e.i(97532), e.i(579844), e.i(194326), e.i(644075), e.i(23067), e.i(971268), e.i(169159);
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        search(e) {
            return this.get((0, r.buildUrl)("/posts/search", e))
        }
        findById(e) {
            return this.get(`/posts/${e}`)
        }
    }
    new s, e.i(674848), e.i(475252), e.i(45077);
    var i = t;
    class o extends i.APIRequest {
        blockCountries(e) {
            return this.post("/block/countries", e)
        }
        blockUser(e) {
            return this.post("/block/users", e)
        }
        unBlockUser(e) {
            this.del(`/block/users/${e}`)
        }
        getBlockListUsers(e) {
            return this.get((0, r.buildUrl)("/block/users", e))
        }
        performerBlockUrl() {
            return "/block/users"
        }
        checkCountryBlock() {
            let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return this.get("/block/countries/check?fromServerRequest=true", e)
        }
    }
    let u = new o;
    e.s(["blockService", 0, u], 494792), e.i(796365), e.i(505771), e.i(4833), e.i(234956), e.i(933594);
    var a = t;
    class l extends a.APIRequest {
        searchByKeyword(e) {
            return this.post("/search/keywords", e)
        }
        listByKeyword(e) {
            return this.get((0, r.buildUrl)("/search/list/keywords", e))
        }
    }
    new l;
    var n = t;
    class d extends n.APIRequest {
        search(e) {
            return this.get((0, r.buildUrl)("/header-images", e))
        }
    }
    new d, e.i(439881);
    var c = t;
    class h extends c.APIRequest {
        statesList(e) {
            return this.get(`/states/${e}`)
        }
        citiesList(e, t) {
            return this.get((0, r.buildUrl)("/cities", {
                countryCode: e,
                state: t
            }))
        }
        verifyRecaptcha(e) {
            return this.post("/re-captcha/verify", {
                token: e
            })
        }
    }
    let p = new h;
    e.s(["utilsService", 0, p], 331849), e.i(584279), e.i(34882);
    var g = t;
    class f extends g.APIRequest {
        search(e) {
            return this.get((0, r.buildUrl)("/performer-categories", e))
        }
    }
    new f, e.i(272021), e.s([], 670357)
}, 933594, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        performerStats(e) {
            return this.get((0, r.buildUrl)("/performer/earning/stats", e))
        }
        performerSearch(e) {
            return this.get((0, r.buildUrl)("/performer/earning/search", e))
        }
        performerSearchUrl() {
            return "/performer/earning/search"
        }
        performerStatsUrl() {
            return "/performer/earning/stats"
        }
    }
    let i = new s;
    e.s(["earningService", 0, i])
}, 796365, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        performerSearch(e) {
            return this.get((0, r.buildUrl)("/orders/search", e))
        }
        performerSearchUrl() {
            return "/orders/search"
        }
        userSearchUrl() {
            return "/orders/users/search"
        }
        userSearch(e) {
            return this.get((0, r.buildUrl)("/orders/users/search", e))
        }
        findById(e) {
            let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return this.get(`/orders/${e}`, r)
        }
        update(e, r) {
            return this.put(`/orders/${e}/update`, r)
        }
        updateDeliveryAddress(e, r) {
            return this.put(`/orders/${e}/update/delivery-address`, r)
        }
        getDownloadLinkDigital(e) {
            return this.get(`/products/${e}/download-link`)
        }
    }
    let i = new s;
    e.s(["orderService", 0, i])
}, 272021, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        create(e) {
            return this.post("/addresses/create", e)
        }
        update(e, r) {
            return this.upload(`/addresses/${e}`, r)
        }
        search() {
            let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return this.get((0, r.buildUrl)("/addresses/search", e))
        }
        delete(e) {
            return this.del(`/addresses/${e}`)
        }
    }
    let i = new s;
    e.s(["shippingAddressService", 0, i])
}, 234956, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        calculate() {
            return this.post("/payout-requests/calculate")
        }
        search(e) {
            return this.get((0, r.buildUrl)("/payout-requests/search", e))
        }
        performerSearchUrl() {
            return "/payout-requests/search"
        }
        create(e) {
            return this.post("/payout-requests", e)
        }
        update(e, r) {
            return this.put(`/payout-requests/${e}`, r)
        }
        detail(e, r) {
            return this.get(`/payout-requests/${e}/view`, r)
        }
    }
    let i = new s;
    e.s(["payoutRequestService", 0, i])
}, 971268, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        create(e) {
            return this.post("/performer/galleries", e)
        }
        search(e) {
            return this.get((0, r.buildUrl)("/performer/galleries/search", e))
        }
        performerSearchUrl() {
            return "/performer/galleries/search"
        }
        userSearch(e, t) {
            return this.get((0, r.buildUrl)("/galleries/search", e), t)
        }
        userSearchUrl() {
            return "/galleries/search"
        }
        update(e, r) {
            return this.put(`/performer/galleries/${e}`, r)
        }
        findById(e, r) {
            return this.get(`/performer/galleries/${e}/view`, r)
        }
        userViewDetails(e, r) {
            return this.get(`/galleries/${e}`, r)
        }
        delete(e) {
            return this.del(`/performer/galleries/${e}`)
        }
        getBookmarks(e) {
            return this.get((0, r.buildUrl)("/reactions/galleries/bookmark", e))
        }
        increaseView(e) {
            return this.post(`/galleries/${e}/view`)
        }
    }
    let i = new s;
    e.s(["galleryService", 0, i])
}, 169159, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        searchByUser(e) {
            let {
                performerId: t
            } = e;
            return this.get((0, r.buildUrl)(`/photos/${t}`, e))
        }
        searchByPerformer(e) {
            return this.get((0, r.buildUrl)("/performer/photos/search", e))
        }
        update(e, r) {
            return this.put(`/performer/photos/${e}`, r)
        }
        setCoverGallery(e) {
            return this.post(`/performer/photos/set-cover/${e}`)
        }
        delete(e) {
            return this.del(`/performer/photos/${e}`)
        }
        uploadImages(e, r, t) {
            return this.upload("/performer/photos/upload", [{
                fieldname: "photo",
                file: e
            }], {
                onProgress: t,
                customData: r
            })
        }
        userSearch(e, t) {
            return this.get((0, r.buildUrl)("/photos", e), t)
        }
    }
    let i = new s;
    e.s(["photoService", 0, i])
}, 45077, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        create(e) {
            return this.post(`/follows/${e}`)
        }
        delete(e) {
            return this.del(`/follows/${e}`)
        }
        getFollowers(e) {
            return this.get((0, r.buildUrl)("/follows/followers", e))
        }
        getFollowing(e) {
            return this.get((0, r.buildUrl)("/follows/following", e))
        }
    }
    let i = new s;
    e.s(["followService", 0, i])
}, 4833, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        search(e) {
            return this.get((0, r.buildUrl)("/subscriptions/performer/search", e))
        }
        performerSearchUrl() {
            return "/subscriptions/performer/search"
        }
        userSearchUrl() {
            return "/subscriptions/user/search"
        }
        userSearch(e) {
            return this.get((0, r.buildUrl)("/subscriptions/user/search", e))
        }
        cancelSubscription(e, r) {
            return this.post(`/payment/${r}/cancel-subscription/${e}`)
        }
    }
    let i = new s;
    e.s(["subscriptionService", 0, i])
}, 505771, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        subscribePerformer(e) {
            return this.post("/payment/subscribe/performers", e)
        }
        userSearch(e) {
            return this.get((0, r.buildUrl)("/payment/transactions/user/search", e))
        }
        addFunds(e) {
            return this.post("/payment/wallet/top-up", e)
        }
        applyCoupon(e) {
            return this.post(`/coupons/${e}/apply-coupon`)
        }
        connectStripeAccount() {
            return this.post("/stripe/accounts")
        }
        getCards(e) {
            return this.get((0, r.buildUrl)("/payment-cards", e))
        }
        addCard(e, r) {
            return this.post(`/${e}/cards`, r)
        }
        removeCard(e) {
            return this.del(`/payment-cards/${e}`)
        }
        userViewDetails(e) {
            let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return this.get(`/payment/transactions/${e}`, r)
        }
        retryPayment(e, r) {
            return this.post(`/payment/retry/${e}`, r)
        }
    }
    let i = new s;
    e.s(["paymentService", 0, i])
}, 439881, e => {
    "use strict";
    var r = e.i(324322);
    class t extends r.APIRequest {
        create(e) {
            return this.post("/reports", e)
        }
    }
    let s = new t;
    e.s(["reportService", 0, s])
}, 97532, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        all() {
            return this.get((0, r.buildUrl)("/settings/public")).then(e => e.data)
        }
        contact(e) {
            return this.post("/contact", e)
        }
        valueByKeys(e) {
            return this.post("/settings/keys", {
                keys: e
            }).then(e => e.data)
        }
    }
    let i = new s;
    e.s(["settingService", 0, i])
}, 475252, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        create(e) {
            return this.post("/comments", e)
        }
        update(e, r) {
            return this.upload(`/comments/${e}`, r)
        }
        search(e) {
            return this.get((0, r.buildUrl)("/comments", e))
        }
        delete(e) {
            return this.del(`/comments/${e}`)
        }
    }
    let i = new s;
    e.s(["commentService", 0, i])
}, 584279, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        sendTip(e, r) {
            return this.post(`/wallet/charges/tip/${e}`, r)
        }
        purchaseFeed(e, r) {
            return this.post(`/wallet/charges/feed/${e}`, r)
        }
        purchaseProduct(e, r) {
            return this.post(`/wallet/charges/product/${e}`, r)
        }
        purchaseVideo(e, r) {
            return this.post(`/wallet/charges/video/${e}`, r)
        }
        purchaseGallery(e) {
            let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return this.post(`/wallet/charges/gallery/${e}`, r)
        }
        purchaseMessage(e, r) {
            return this.post(`/wallet/charges/message/${e}`, r)
        }
        purchaseStream(e) {
            return this.post(`/wallet/charges/stream/${e}`)
        }
        userSearch(e) {
            return this.get((0, r.buildUrl)("/wallet/charges/search", e))
        }
        searchEndpoint() {
            return "/wallet/charges/search"
        }
        purchaseByToken(e, r, t) {
            return this.post(`/wallet/charges/${e}/${r}`, t)
        }
    }
    let i = new s;
    e.s(["tokenTransactionService", 0, i])
}, 644075, e => {
    "use strict";
    var r = e.i(140240),
        t = e.i(324322);
    class s extends t.APIRequest {
        search(e) {
            return this.get((0, r.buildUrl)("/performer/videos/search", e))
        }
        performerSearchUrl() {
            return "/performer/videos/search"
        }
        userSearch(e) {
            return this.get((0, r.buildUrl)("/videos/search", e))
        }
        delete(e) {
            return this.del(`/performer/videos/${e}`)
        }
        findById(e, r) {
            return this.get(`/performer/videos/${e}/view`, r)
        }
        findOne(e, r) {
            return this.get(`/videos/${e}`, r)
        }
        update(e, r, t, s) {
            return this.upload(`/performer/videos/edit/${e}`, r, {
                onProgress: s,
                customData: t,
                method: "PUT"
            })
        }
        deleteFile(e, r) {
            return this.del(`/performer/videos/remove-file/${e}`, {
                type: r
            })
        }
        uploadVideo(e, r, t) {
            let s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
            return this.upload("/performer/videos/upload", e, {
                onProgress: t,
                customData: r
            }, s)
        }
        getBookmarks(e) {
            return this.get((0, r.buildUrl)("/reactions/videos/bookmark", e))
        }
        getVideoFileStatus(e, r) {
            return this.get(`/videos/${e}/file/${r}/status`)
        }
        increaseView(e) {
            return this.post(`/videos/${e}/view`)
        }
    }
    let i = new s;
    e.s(["videoService", 0, i])
}, 646564, e => {
    "use strict";
    var r = e.i(843476),
        t = e.i(271645);
    e.i(670357);
    var s = e.i(45077),
        i = e.i(217255),
        o = e.i(843577),
        u = e.i(731270),
        a = e.i(313811);

    function l(e) {
        let {
            performer: l,
            showIcon: n = !1
        } = e, {
            setLoginModal: d,
            updateFollowIds: c,
            followedIds: h
        } = (0, u.useMainThemeLayout)(), {
            data: p
        } = (0, i.useSession)(), g = h.includes(l._id);
        return (0, t.useEffect)(() => {
            l.isFollowed && c({
                id: l._id,
                type: "add"
            })
        }, [l]), (0, r.jsx)("button", {
            type: "button",
            title: g ? "Unfollow this creator" : "Follow this creator",
            onClick: async () => {
                if (!p ? .user ? ._id) return void d({
                    openForm: "login"
                });
                if (!p.user.isPerformer) try {
                    g ? (await s.followService.delete(l._id), c({
                        id: l._id,
                        type: "remove"
                    }), (0, o.showSuccess)("You have unfollowed this creator")) : (await s.followService.create(l._id), c({
                        id: l._id,
                        type: "add"
                    }), (0, o.showSuccess)("You are now following this creator"))
                } catch (e) {
                    (0, o.showError)(e)
                }
            },
            className: g ? "follow-btn active" : "follow-btn",
            children: n ? g ? (0, r.jsx)(a.AiFillHeart, {}) : (0, r.jsx)(a.AiOutlineHeart, {}) : g ? "Following" : "Follow"
        })
    }
    l.displayName = "FollowButton", e.s(["default", 0, l])
}, 124057, e => {
    e.n(e.i(646564))
}]);