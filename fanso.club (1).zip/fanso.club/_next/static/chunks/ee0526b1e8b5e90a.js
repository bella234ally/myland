(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 868792, l => {
    l.v({
        "scroll-top-btn": "style-module-scss-module__P-bD3q__scroll-top-btn"
    })
}, 87238, l => {
    "use strict";
    var o = l.i(843476),
        t = l.i(271645),
        e = l.i(603594),
        n = l.i(618566),
        s = l.i(868792);

    function c() {
        let l = (0, n.usePathname)();
        return (0, t.useEffect)(() => {
            if (l.includes("stream")) return () => {};
            let o = document.getElementById("scroll-top-btn");
            return window.onscroll = function() {
                document.body.scrollTop > 1200 || document.documentElement.scrollTop > 1200 ? o.style.display = "block" : o.style.display = "none"
            }, () => {
                window.onscroll = null
            }
        }, [l]), (0, o.jsx)("button", {
            id: "scroll-top-btn",
            "aria-label": "scroll-top",
            className: s.default["scroll-top-btn"],
            type: "button",
            onClick: () => window.scrollTo(0, 0),
            children: (0, o.jsx)(e.ArrowAngleUpSvg, {})
        })
    }
    l.s(["default", () => c])
}, 828006, l => {
    l.n(l.i(87238))
}]);