(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 756105, e => {
    "use strict";
    var s = e.i(843476),
        t = e.i(217255),
        i = e.i(618566),
        n = e.i(271645),
        u = e.i(731270);
    e.i(954274);
    var a = e.i(604448);

    function o(e) {
        let {
            performer: o,
            showOnlineStatus: r = !0
        } = e, {
            data: l
        } = (0, t.useSession)(), {
            setLoginModal: c
        } = (0, u.useMainThemeLayout)(), d = (0, i.useRouter)(), [m, p] = (0, n.useState)(!!o ? .live);
        return (0, a.useSocketListener)("live-status-updated", e => {
            let {
                live: s,
                performerId: t
            } = e;
            t === o ? ._id && p(s)
        }), (0, s.jsxs)(s.Fragment, {
            children: [r && (0, s.jsx)("span", {
                className: o ? .isOnline ? "online-status" : "online-status off"
            }), m && (0, s.jsxs)("button", {
                type: "button",
                onClick: () => {
                    l ? .user ? ._id ? l ? .user ? .isPerformer || d.push(`/streaming/${o?.username}`) : c({
                        openForm: "login"
                    })
                },
                className: "live-status",
                children: [(0, s.jsx)("i", {}), " ", "Live"]
            })]
        })
    }
    o.displayName = "LiveButton", e.s(["default", 0, o])
}, 598182, e => {
    e.n(e.i(756105))
}]);