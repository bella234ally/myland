(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 109369, e => {
    "use strict";
    var s = e.i(843476),
        t = e.i(217255),
        o = e.i(770703),
        i = e.i(271645),
        r = e.i(731270);
    let n = (0, o.default)(() => e.A(121357), {
        loadableGenerated: {
            modules: [333273]
        },
        ssr: !1
    });

    function u(e) {
        let {
            onMouseEnter: o,
            onMouseLeave: u,
            feed: a
        } = e, {
            data: l
        } = (0, t.useSession)(), [c, d] = (0, i.useState)(!1), {
            setLoginModal: b
        } = (0, r.useMainThemeLayout)();
        return (0, s.jsxs)(s.Fragment, {
            children: [(0, s.jsx)("button", {
                onMouseEnter: o.bind(this),
                onMouseLeave: u.bind(this),
                type: "button",
                disabled: l ? .user ? .isPerformer,
                onClick: () => {
                    l ? .user ? ._id ? l ? .user ? .isPerformer || d(!0) : b({
                        openForm: "login"
                    })
                },
                children: "Subscribe to unlock"
            }), c && (0, s.jsx)(n, {
                performer: a.performer,
                open: c,
                onClose: () => d(!1),
                subscriptionType: "monthly"
            })]
        })
    }
    e.s(["default", () => u])
}, 652221, e => {
    e.n(e.i(109369))
}, 121357, e => {
    e.v(s => Promise.all(["static/chunks/aad5c4de49b1125d.js", "static/chunks/954949baab1a5f4c.css"].map(s => e.l(s))).then(() => s(333273)))
}]);