(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 587104, e => {
    e.v({
        controls: "controls-module-scss-module__pVExRq__controls",
        playback_line: "controls-module-scss-module__pVExRq__playback_line",
        separator: "controls-module-scss-module__pVExRq__separator",
        video_timer: "controls-module-scss-module__pVExRq__video_timer",
        volume_selector: "controls-module-scss-module__pVExRq__volume_selector"
    })
}, 143927, e => {
    "use strict";
    var t = e.i(843476),
        l = e.i(271645),
        n = e.i(511152),
        r = e.i(501859),
        u = e.i(940141);

    function o(e) {
        return (0, u.GenIcon)({
            tag: "svg",
            attr: {
                viewBox: "0 0 24 24"
            },
            child: [{
                tag: "path",
                attr: {
                    fill: "none",
                    strokeWidth: "2",
                    d: "M3.11111111,7.55555556 C4.66955145,4.26701301 8.0700311,2 12,2 C17.5228475,2 22,6.4771525 22,12 C22,17.5228475 17.5228475,22 12,22 L12,22 C6.4771525,22 2,17.5228475 2,12 M2,4 L2,8 L6,8 M9,16 L9,9 L7,9.53333333 M17,12 C17,10 15.9999999,8.5 14.5,8.5 C13.0000001,8.5 12,10 12,12 C12,14 13,15.5000001 14.5,15.5 C16,15.4999999 17,14 17,12 Z M14.5,8.5 C16.9253741,8.5 17,11 17,12 C17,13 17,15.5 14.5,15.5 C12,15.5 12,13 12,12 C12,11 12.059,8.5 14.5,8.5 Z"
                },
                child: []
            }]
        })(e)
    }

    function a(e) {
        return (0, u.GenIcon)({
            tag: "svg",
            attr: {
                viewBox: "0 0 24 24"
            },
            child: [{
                tag: "path",
                attr: {
                    fill: "none",
                    strokeWidth: "2",
                    d: "M20.8888889,7.55555556 C19.3304485,4.26701301 15.9299689,2 12,2 C6.4771525,2 2,6.4771525 2,12 C2,17.5228475 6.4771525,22 12,22 L12,22 C17.5228475,22 22,17.5228475 22,12 M22,4 L22,8 L18,8 M9,16 L9,9 L7,9.53333333 M17,12 C17,10 15.9999999,8.5 14.5,8.5 C13.0000001,8.5 12,10 12,12 C12,14 13,15.5000001 14.5,15.5 C16,15.4999999 17,14 17,12 Z M14.5,8.5 C16.9253741,8.5 17,11 17,12 C17,13 17,15.5 14.5,15.5 C12,15.5 12,13 12,12 C12,11 12.059,8.5 14.5,8.5 Z"
                },
                child: []
            }]
        })(e)
    }
    var s = e.i(64777),
        i = e.i(587104);

    function c(e) {
        let u, {
                isPlaying: c,
                playerRef: m,
                containerRef: d,
                setVolume: v,
                volume: p
            } = e,
            [C, x] = (0, l.useState)(0),
            [F, f] = (0, l.useState)(0),
            b = (0, l.useRef)(null);
        (0, l.useEffect)(() => {
            if (!m || !b.current) return;
            let e = () => {
                    b.current && (m.volume = parseFloat(b.current.value), m.muted = 0 === m.volume, v({
                        volume: m.volume
                    }))
                },
                t = b.current;
            return t.addEventListener("input", e), () => {
                t.removeEventListener("input", e)
            }
        }, [m, v]), (0, l.useEffect)(() => {
            b.current && (b.current.value = p.toString())
        }, [p]), (0, l.useEffect)(() => {
            let e;
            if (!m) return;
            let t = () => {
                    let {
                        currentTime: l,
                        duration: n
                    } = m;
                    n && !isNaN(n) && (x(l), f(l / n * 100)), m.paused || m.ended || (e = requestAnimationFrame(t))
                },
                l = () => {
                    cancelAnimationFrame(e), e = requestAnimationFrame(t)
                },
                n = () => {
                    cancelAnimationFrame(e);
                    let {
                        currentTime: t,
                        duration: l
                    } = m;
                    l && !isNaN(l) && (x(t), f(t / l * 100))
                };
            return m.addEventListener("play", l), m.addEventListener("pause", n), m.addEventListener("ended", n), () => {
                cancelAnimationFrame(e), m.removeEventListener("play", l), m.removeEventListener("pause", n), m.removeEventListener("ended", n)
            }
        }, [m]);
        let _ = e => {
                m && (m.currentTime += e, x(m.currentTime), m.duration && f(m.currentTime / m.duration * 100))
            },
            h = async () => {
                if (d) try {
                    document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement ? document.exitFullscreen ? await document.exitFullscreen() : document.webkitExitFullscreen ? document.webkitExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.msExitFullscreen && document.msExitFullscreen() : (d.requestFullscreen ? await d.requestFullscreen() : d.webkitRequestFullscreen ? d.webkitRequestFullscreen() : d.mozRequestFullScreen ? d.mozRequestFullScreen() : d.msRequestFullscreen ? d.msRequestFullscreen() : m.webkitSupportsFullscreen && m.webkitEnterFullscreen(), m && !c && m.play().catch(e => console.error("Play error:", e)))
                } catch (e) {
                    console.error("Fullscreen error:", e)
                }
            },
            E = () => {
                let e = p > 0 ? 0 : 1;
                v({
                    volume: e
                }), m && (m.volume = e, m.muted = 0 === e)
            };
        return (0, t.jsxs)("div", {
            className: `${i.default.controls} controls`,
            children: [(0, t.jsx)("button", {
                type: "button",
                onClick: () => {
                    m && (c ? m.pause() : m.play().catch(e => console.error("Play error:", e)))
                },
                "aria-label": c ? "Pause" : "Play",
                children: c ? (0, t.jsx)(n.FaPause, {}) : (0, t.jsx)(n.FaPlay, {})
            }), (0, t.jsx)("div", {
                className: i.default.video_timer,
                children: `${(0,s.videoDuration)(C)} / ${(0,s.videoDuration)(m?.duration||0)}`
            }), (0, t.jsx)("button", {
                type: "button",
                "aria-label": "Move backward",
                onClick: () => _(-10),
                children: (0, t.jsx)(o, {})
            }), (0, t.jsx)("button", {
                type: "button",
                "aria-label": "Move forward",
                onClick: () => _(10),
                children: (0, t.jsx)(a, {})
            }), (0, t.jsx)("div", {
                "aria-hidden": !0,
                className: i.default.playback_line,
                children: (0, t.jsx)("input", {
                    type: "range",
                    min: "0",
                    max: "100",
                    step: "0.01",
                    value: F,
                    onChange: e => {
                        if (!m) return;
                        let t = parseFloat(e.target.value),
                            l = m.duration;
                        if (l && !isNaN(l)) {
                            let e = t / 100 * l;
                            m.currentTime = e, x(e), f(t)
                        }
                    }
                })
            }), (0, t.jsxs)("div", {
                className: i.default.volume_selector,
                children: [p > 0 ? (0, t.jsx)(r.RiVolumeUpFill, {
                    onClick: E
                }) : (0, t.jsx)(r.RiVolumeMuteFill, {
                    onClick: E
                }), (0, t.jsx)("input", {
                    type: "range",
                    min: "0",
                    max: "1",
                    step: "0.01",
                    value: p,
                    onChange: e => {
                        let t = Math.min(Math.max(Number(e.target.value), 0), 1);
                        v({
                            volume: t
                        }), m && (m.volume = t, m.muted = 0 === t)
                    },
                    style: (u = (100 * p - 0) / 100 * 100, {
                        background: `linear-gradient(to right, #fff 0%, #fff ${u}%, rgba(255, 255, 255, 0.4) ${u}%, rgba(255, 255, 255, 0.4) 100%)`
                    }),
                    "aria-label": "Volume"
                })]
            }), (0, t.jsx)("button", {
                "aria-label": "Toggle fullscreen",
                type: "button",
                onClick: h,
                children: (0, t.jsx)(n.FaExpand, {})
            })]
        })
    }
    e.s(["default", () => c], 143927)
}, 913665, e => {
    e.n(e.i(143927))
}]);