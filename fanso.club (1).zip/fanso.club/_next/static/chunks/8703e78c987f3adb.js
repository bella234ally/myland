(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 808613, e => {
    "use strict";
    var a = e.i(648601);
    e.s(["Form", () => a.default])
}, 843577, e => {
    "use strict";
    var a = e.i(705766);

    function n(e) {
        a.default.error(e ? .message || e || "Error occurred, please try again later!")
    }

    function r(e) {
        a.default.success(e)
    }
    e.s(["showError", () => n, "showSuccess", () => r])
}, 465807, e => {
    "use strict";
    let a = [{
        required: !1,
        message: "Please enter confirm password!"
    }, e => {
        let {
            getFieldValue: a
        } = e;
        return {
            validator: (e, n) => n && a("password") !== n ? Promise.reject(Error("Passwords do not match!")) : Promise.resolve()
        }
    }];
    e.s(["addressName", 0, [{
        required: !0,
        message: "Please enter address name!"
    }], "bankAccount", 0, [{
        required: !0,
        message: "Please input your bank account!"
    }], "bankName", 0, [{
        required: !0,
        message: "Please input your bank name!"
    }], "bio", 0, [{
        required: !1,
        message: "Please enter your bio!"
    }], "city", 0, [{
        required: !0,
        message: "Please select your city!"
    }], "confirmPassword", 0, a, "confirmQuantity", 0, [{
        required: !0,
        message: "Please input quantity of product!"
    }], "contactEmail", 0, [{
        type: "email",
        message: "Invalid email format."
    }, {
        required: !0,
        message: "Tell us your email address."
    }], "contactMessage", 0, [{
        required: !0,
        message: "What can we help you with?"
    }, {
        min: 20,
        message: "Please input at least 20 characters."
    }], "contactName", 0, [{
        required: !0,
        message: "Tell us your full name."
    }], "country", 0, [{
        required: !0,
        message: "Please select your country!"
    }], "dateOfBirth", 0, [{
        required: !0,
        message: "Please select your date of birth."
    }], "deliveryAddress", 0, [{
        required: !0,
        message: "Please select a delivery address!"
    }], "description", 0, [{
        required: !0,
        message: "Please add a description!"
    }], "district", 0, [{
        required: !0,
        message: "Please enter your district!"
    }], "emailValidate", 0, [{
        type: "email",
        message: "Invalid email address!"
    }, {
        required: !0,
        message: "Please input your email address!"
    }], "firstNameBankForm", 0, [{
        required: !0,
        message: "Please input your first name!"
    }], "firstNameValidate", 0, [{
        required: !0,
        message: "Please input your first name!"
    }, {
        pattern: /^[a-zA-ZÀ-ž ,.'-]+$/u,
        message: "First name cannot contain numbers or invalid characters."
    }], "formLayout", 0, {
        labelCol: {
            span: 24
        },
        wrapperCol: {
            span: 24
        }
    }, "gender", 0, [{
        required: !0,
        message: "Please select your gender."
    }], "lastNameBankForm", 0, [{
        required: !0,
        message: "Please input your last name!"
    }], "lastNameValidate", 0, [{
        required: !0,
        message: "Please input your last name!"
    }, {
        pattern: /^[a-zA-ZÀ-ž ,.'-]+$/u,
        message: "Last name cannot contain numbers or invalid characters."
    }], "nameValidate", 0, [{
        pattern: /^(?=.*\S).+$/g,
        message: "Display name cannot contain only whitespace"
    }, {
        min: 3,
        message: "Display name must contain at least 3 characters"
    }], "passwordLogin", 0, [{
        required: !0,
        message: "Please enter your password!"
    }], "passwordValidate", 0, [{
        pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\d]).{8,}$/g,
        message: "Password must have at least 8 characters, including 1 uppercase, 1 lowercase, 1 number, and 1 special character."
    }, {
        required: !1,
        message: "Please enter your password!"
    }], "phoneNumber", 0, [{
        required: !0,
        message: "Please enter your phone number!"
    }, {
        pattern: /^([+]\d{2,4})?\d{9,12}$/g,
        message: "Please provide valid digit numbers"
    }], "price", 0, [{
        required: !0,
        message: "Please input the price!"
    }], "productName", 0, [{
        required: !0,
        message: "Please input product name!"
    }], "productPrice", 0, [{
        required: !0,
        message: "Price is required!"
    }], "state", 0, [{
        required: !0,
        message: "Please select your state!"
    }], "status", 0, [{
        required: !0,
        message: "Please select status!"
    }], "stock", 0, [{
        required: !0,
        message: "Stock is required!"
    }], "streamDescription", 0, [{
        required: !0,
        message: "Please enter stream description!"
    }], "streamOptionRules", 0, [{
        required: !0,
        message: "Please select an option!"
    }], "streamTitle", 0, [{
        required: !0,
        message: "Please enter stream title!"
    }], "stressAddress", 0, [{
        required: !0,
        message: "Please enter your street address!"
    }], "stressNumber", 0, [{
        required: !0,
        message: "Please enter your street number!"
    }], "title", 0, [{
        required: !0,
        message: "Please select title!"
    }], "titleGallery", 0, [{
        required: !0,
        message: "Please input gallery title!"
    }], "titleVideo", 0, [{
        required: !0,
        message: "Please input video title!"
    }], "type", 0, [{
        required: !0,
        message: "Please select a type!"
    }], "usernameLogin", 0, [{
        required: !0,
        message: "Email/Username is missing"
    }], "usernameValidate", 0, [{
        required: !0,
        message: "Please input your username!"
    }, {
        pattern: /^[a-z0-9]+$/g,
        message: "Username must contain lowercase alphanumerics only!"
    }, {
        min: 3,
        message: "Username must contain at least 3 characters"
    }], "ward", 0, [{
        required: !0,
        message: "Please enter your ward!"
    }], "zipCode", 0, [{
        required: !0,
        message: "Please provide your zip code."
    }, {
        pattern: /^\d{2,10}$/g,
        message: "Please provide valid zip code numbers."
    }]])
}, 872238, e => {
    "use strict";
    var a = e.i(644099);
    e.s(["Input", () => a.default])
}, 840803, e => {
    "use strict";
    var a = e.i(843476),
        n = e.i(271645),
        r = e.i(174080);

    function s() {
        return (0, a.jsx)("svg", {
            stroke: "currentColor",
            fill: "none",
            "stroke-width": "0",
            viewBox: "0 0 15 15",
            height: "20",
            width: "20",
            xmlns: "http://www.w3.org/2000/svg",
            children: (0, a.jsx)("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M11.7816 4.03157C12.0062 3.80702 12.0062 3.44295 11.7816 3.2184C11.5571 2.99385 11.193 2.99385 10.9685 3.2184L7.50005 6.68682L4.03164 3.2184C3.80708 2.99385 3.44301 2.99385 3.21846 3.2184C2.99391 3.44295 2.99391 3.80702 3.21846 4.03157L6.68688 7.49999L3.21846 10.9684C2.99391 11.193 2.99391 11.557 3.21846 11.7816C3.44301 12.0061 3.80708 12.0061 4.03164 11.7816L7.50005 8.31316L10.9685 11.7816C11.193 12.0061 11.5571 12.0061 11.7816 11.7816C12.0062 11.557 12.0062 11.193 11.7816 10.9684L8.31322 7.49999L11.7816 4.03157Z",
                fill: "currentColor"
            })
        })
    }

    function t(e) {
        let {
            open: t,
            toggle: o,
            onClose: i,
            onOpenChange: l,
            title: d,
            footer: u,
            header: c,
            children: m,
            hideIcon: p,
            className: g,
            wrapperClassName: h,
            width: f = 550,
            position: y = "center",
            animation: x = "zoom",
            animationDuration: w = 400,
            showEscape: b = !1,
            blur: _ = !1,
            style: v = {},
            ...j
        } = e, [P, k] = (0, n.useState)(!t);

        function q() {
            o && o(), i && i(), l && l(!1)
        }
        if ((0, n.useEffect)(() => (document.body.style.overflow = t ? "hidden" : "auto", () => {
                document.body.style.overflow = "auto"
            }), [t]), (0, n.useEffect)(() => {
                if (t) return document.addEventListener("keydown", e), () => {
                    document.removeEventListener("keydown", e)
                };

                function e(e) {
                    "Escape" === e.key && q()
                }
            }, [t]), (0, n.useEffect)(() => {
                if (t) return k(!1);
                let e = setTimeout(() => {
                    k(!0)
                }, w + 50);
                return () => clearTimeout(e)
            }, [t]), "u" < typeof window || !t && P) return null;
        let N = ["modal", `modal__position-${y}`];
        t && N.push("modal__open"), h && N.push(h);
        let C = ["modal__popup", `modal__popup--animation-${x}`, g],
            S = ["modal__close-button"];
        b && S.push("modal__close-button-escape");
        let E = ["modal__backdrop"];
        _ && E.push("modal__backdrop--blur");
        let I = !p || d ? (0, a.jsxs)("header", {
                className: "modal__header",
                children: [c || (0, a.jsx)("h3", {
                    className: "modal__title",
                    children: d
                }), !p && (0, a.jsx)("button", {
                    onClick: q,
                    className: S.join(" "),
                    children: b ? (0, a.jsx)("kbd", {
                        children: "ESC"
                    }) : (0, a.jsx)(s, {})
                })]
            }) : null,
            L = (0, a.jsxs)("div", {
                className: N.join(" "),
                children: [(0, a.jsx)("div", {
                    onClick: q,
                    className: E.join(" ")
                }), (0, a.jsxs)("div", {
                    className: C.join(" "),
                    style: {
                        animationDuration: `${w}ms`,
                        maxWidth: `${f}px`,
                        ...v
                    },
                    ...j,
                    children: [I, (0, a.jsx)("div", {
                        className: "modal__body",
                        children: m
                    }), !!u && (0, a.jsx)("footer", {
                        children: u
                    })]
                })]
            });
        return (0, r.createPortal)(L, document.body)
    }! function(e, a) {
        void 0 === a && (a = {});
        var n = a.insertAt;
        if (e && "u" > typeof document) {
            var r = document.head || document.getElementsByTagName("head")[0],
                s = document.createElement("style");
            s.type = "text/css", "top" === n && r.firstChild ? r.insertBefore(s, r.firstChild) : r.appendChild(s), s.styleSheet ? s.styleSheet.cssText = e : s.appendChild(document.createTextNode(e))
        }
    }("@keyframes fade-in {\n    0% {\n        opacity: 0;\n    }\n    100% {\n        opacity: 1;\n    }\n}\n\n@keyframes fade-out {\n    0% {\n        opacity: 1;\n    }\n    100% {\n        opacity: 0;\n    }\n}\n\n@keyframes slide-down {\n    0% {\n        opacity: 0;\n        transform: translateY(-15px);\n    }\n    100% {\n        opacity: 1;\n        transform: translateY(0);\n    }\n}\n\n@keyframes slide-up {\n    0% {\n        opacity: 1;\n        transform: translateY(0);\n    }\n    100% {\n        opacity: 0;\n        transform: translateY(15px);\n    }\n}\n\n@keyframes zoom-in {\n    0% {\n        opacity: 0;\n        transform: scale(0.9);\n    }\n    100% {\n        opacity: 1;\n        transform: scale(1);\n    }\n}\n\n@keyframes zoom-out {\n    0% {\n        opacity: 1;\n        transform: scale(1);\n    }\n    100% {\n        opacity: 0;\n        transform: scale(1.1);\n    }\n}\n\n.modal {\n    position: fixed;\n    width: 100vw;\n    height: 100dvh;\n    top: 0;\n    left: 0;\n    display: flex;\n    flex-wrap: wrap;\n    flex-direction: column;\n    align-content: center;\n    z-index: 9999;\n}\n.modal__position-center {\n    justify-content: center;\n}\n.modal__position-top {\n    justify-content: flex-start;\n}\n.modal__position-bottom {\n    justify-content: flex-end;\n}\n\n.modal__backdrop {\n    background-color: rgba(0, 0, 0, 0.2);\n    position: fixed;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    z-index: 9999;\n    opacity: 0;\n    animation: fade-out 300ms forwards;\n}\n.modal__backdrop--blur {\n    -webkit-backdrop-filter: blur(4px);\n            backdrop-filter: blur(4px);\n}\n\n.modal__open .modal__backdrop {\n    animation: fade-in 300ms forwards;\n}\n\n.modal__popup {\n    padding: 20px;\n    border-radius: 18px;\n    width: 95%;\n    max-height: 90vh;\n    border: 1px solid #ddd;\n    background: #fff;\n    z-index: 99999;\n    opacity: 0;\n    display: flex;\n    flex-direction: column;\n    transform: translateY(-15px);\n    overflow: hidden;\n}\n\n.modal__popup--animation-zoom {\n    animation: zoom-out 400ms ease-out forwards;\n}\n\n.modal__open .modal__popup--animation-zoom {\n    animation: zoom-in 400ms ease-out forwards;\n}\n\n.modal__popup--animation-slide {\n    animation: slide-up 400ms ease-out forwards;\n}\n\n.modal__open .modal__popup--animation-slide {\n    animation: slide-down 400ms ease-in forwards;\n}\n\n.modal__header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n}\n\n.modal__title {\n    color: #000000c9;\n    margin: 0 0 12px;\n    font-weight: 600;\n    font-size: 22px;\n}\n\n.modal__body {\n    height: 100%;\n    overflow-y: auto;\n    flex-grow: 1;\n}\n\n.modal__close-button {\n    cursor: pointer;\n    border-radius: 50%;\n    border: none;\n    color: rgb(233 30 99);\n    height: 32px;\n    width: 32px;\n    overflow: hidden;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    margin: -4px 0 0;\n    background-color: #fff !important;\n    transition-property: all;\n    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\n    transition-duration: 0.2s;\n}\n.modal__close-button:hover {\n    background-color: rgba(0, 121, 211, 0.1) !important;\n}\n\n.modal__close-button-escape {\n    width: 2rem;\n    height: 1.6rem;\n    background-image: url(\"data:image/svg+xml,%3Csvg width='16' height='7' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M.506 6h3.931V4.986H1.736v-1.39h2.488V2.583H1.736V1.196h2.69V.182H.506V6ZM8.56 1.855h1.18C9.721.818 8.87.102 7.574.102c-1.276 0-2.21.705-2.205 1.762-.003.858.602 1.35 1.585 1.585l.634.159c.633.153.986.335.988.727-.002.426-.406.716-1.03.716-.64 0-1.1-.295-1.14-.878h-1.19c.03 1.259.931 1.91 2.343 1.91 1.42 0 4.256-.68 2.259-1.745-.003-.969-.733-1.483-1.744-1.71l-.523-.125c-.506-.117-.93-.304-.92-.722 0-.375.332-.65.934-.65.588 0 .949.267.994.724ZM15.78 2.219C15.618.875 14.6.102 13.254.102c-1.537 0-2.71 1.086-2.71 2.989 0 1.898 1.153 2.989 2.71 2.989 1.492 0 2.392-.992 2.526-2.063l-1.244-.006c-.117.623-.606.98-1.262.98-.883 0-1.483-.656-1.483-1.9 0-1.21.591-1.9 1.492-1.9.673 0 1.159.389 1.253 1.028h1.244Z' fill='%23334155'/%3E%3C/svg%3E\");\n    background-position: 50%;\n    background-repeat: no-repeat;\n    background-size: 57.1428571429% auto;\n    border-radius: 6px;\n    padding: 0.25rem 0.375rem;\n    border: 1px solid #0f172a0d;\n    -webkit-appearance: none;\n       -moz-appearance: none;\n            appearance: none;\n    flex: none;\n    font-size: 0;\n    border-radius: 0.375rem;\n    padding: 0.25rem 0.375rem;\n}\n.modal__close-button-escap kbd {\n    display: none;\n}\n", {
        insertAt: "top"
    }), e.s(["default", () => t])
}, 312361, e => {
    "use strict";
    var a = e.i(72787);
    e.s(["Divider", () => a.default])
}, 859718, e => {
    "use strict";
    var a = e.i(843476),
        n = e.i(843577),
        r = e.i(808613),
        s = e.i(872238),
        t = e.i(522016),
        o = e.i(618566),
        i = e.i(271645),
        l = e.i(944779),
        d = e.i(731270),
        u = e.i(465807);

    function c(e) {
        let {
            noredirect: c = !1
        } = e, [m, p] = (0, i.useState)(!1), g = (0, o.useRouter)(), {
            setLoginModal: h
        } = (0, d.useMainThemeLayout)();
        return (0, a.jsxs)("div", {
            className: "auth-form",
            children: [(0, a.jsxs)(r.Form, {
                labelCol: {
                    span: 24
                },
                initialValues: {
                    gender: "male"
                },
                onFinish: async e => {
                    try {
                        p(!0);
                        let a = (await l.authService.register(e)).data;
                        (0, n.showSuccess)(a ? .message || "Sign up success!"), c ? h({
                            openForm: "login"
                        }) : g.push("/"), p(!1)
                    } catch (e) {
                        (0, n.showError)(e), p(!1)
                    }
                },
                scrollToFirstError: !0,
                children: [(0, a.jsx)(r.Form.Item, {
                    name: "firstName",
                    validateTrigger: ["onChange", "onBlur"],
                    rules: u.firstNameValidate,
                    children: (0, a.jsx)(s.Input, {
                        placeholder: "First name"
                    })
                }), (0, a.jsx)(r.Form.Item, {
                    name: "lastName",
                    validateTrigger: ["onChange", "onBlur"],
                    rules: u.lastNameValidate,
                    children: (0, a.jsx)(s.Input, {
                        placeholder: "Last name"
                    })
                }), (0, a.jsx)(r.Form.Item, {
                    name: "name",
                    validateTrigger: ["onChange", "onBlur"],
                    rules: u.nameValidate,
                    children: (0, a.jsx)(s.Input, {
                        placeholder: "Display name"
                    })
                }), (0, a.jsx)(r.Form.Item, {
                    name: "username",
                    validateTrigger: ["onChange", "onBlur"],
                    rules: u.usernameValidate,
                    children: (0, a.jsx)(s.Input, {
                        placeholder: "User name: jonh123, smith,...",
                        autoCapitalize: "off"
                    })
                }), (0, a.jsx)(r.Form.Item, {
                    name: "email",
                    validateTrigger: ["onChange", "onBlur"],
                    rules: u.emailValidate,
                    children: (0, a.jsx)(s.Input, {
                        placeholder: "Email address"
                    })
                }), (0, a.jsx)(r.Form.Item, {
                    name: "password",
                    validateTrigger: ["onChange", "onBlur"],
                    rules: u.passwordValidate,
                    children: (0, a.jsx)(s.Input.Password, {
                        placeholder: "Password"
                    })
                }), (0, a.jsx)("button", {
                    type: "submit",
                    className: "submit-btn",
                    disabled: m,
                    children: "SIGN UP"
                })]
            }), c ? (0, a.jsxs)("p", {
                children: ["Have an account already?  ", (0, a.jsx)("a", {
                    "aria-hidden": !0,
                    onClick: () => h({
                        openForm: "login"
                    }),
                    children: "Log in here."
                })]
            }) : (0, a.jsxs)("div", {
                className: "text-center",
                children: [(0, a.jsxs)("p", {
                    children: ["By signing up you agree to our", " ", (0, a.jsx)(t.default, {
                        href: "/page/terms-of-service",
                        target: "_blank",
                        children: "Terms of Service"
                    }), " ", "and", " ", (0, a.jsx)(t.default, {
                        href: "/page/privacy-policy",
                        target: "_blank",
                        children: "Privacy Policy"
                    }), ", and confirm that you are at least 18 years old."]
                }), (0, a.jsxs)("p", {
                    children: ["Have an account already?  ", (0, a.jsx)(t.default, {
                        href: "/",
                        children: "Log in here."
                    })]
                }), (0, a.jsxs)("p", {
                    children: ["Are you a creator?  ", (0, a.jsx)(t.default, {
                        href: "/auth/creator-register",
                        children: "Sign up here."
                    })]
                })]
            })]
        })
    }
    e.s(["default", () => c])
}, 374540, e => {
    e.v({
        "custom-divider": "style-module-scss-module__cgJvrq__custom-divider",
        google: "style-module-scss-module__cgJvrq__google",
        "login-btn": "style-module-scss-module__cgJvrq__login-btn",
        "social-login": "style-module-scss-module__cgJvrq__social-login",
        twitter: "style-module-scss-module__cgJvrq__twitter"
    })
}, 105299, e => {
    "use strict";
    var a = e.i(843476),
        n = e.i(731270),
        r = e.i(312361),
        s = e.i(374540),
        t = e.i(843577),
        o = e.i(693936),
        i = e.i(217255),
        l = e.i(618566),
        d = e.i(603594),
        u = e.i(271645);

    function c(e) {
        let {
            noredirect: r = !0
        } = e, {
            setLoginModal: u
        } = (0, n.useMainThemeLayout)(), {
            data: c
        } = (0, i.useSession)(), m = (0, l.useRouter)(), p = (0, l.useSearchParams)().get("redirect"), g = (0, o.useGoogleLogin)({
            flow: "auth-code",
            onSuccess: async e => {
                if (e.code) try {
                    let a = await (0, i.signIn)("credentials", {
                        type: "google",
                        code: e.code,
                        role: "user",
                        redirect: !1
                    });
                    a ? .ok && (r ? u({
                        openForm: ""
                    }) : m.push(p || "/home")), a ? .error && (0, t.showError)({
                        message: a.error
                    })
                } catch (e) {
                    (0, t.showError)(e)
                }
            }
        });
        return (0, o.useGoogleOneTapLogin)({
            onError: () => {
                alert("Login failed!")
            },
            onSuccess: async e => {
                if (e.credential) try {
                    let a = await (0, i.signIn)("credentials", {
                        type: "google-onetap",
                        tokenId: e.credential,
                        role: "user",
                        redirect: !1
                    });
                    a ? .ok && (r ? u({
                        openForm: ""
                    }) : m.push(p || "/home")), a ? .error && (0, t.showError)({
                        message: a.error
                    })
                } catch (e) {
                    (0, t.showError)(e)
                }
            },
            disabled: !!c ? .user ? ._id
        }), (0, a.jsxs)("button", {
            type: "button",
            onClick: () => g(),
            className: `${s.default["login-btn"]} ${s.default.google}`,
            children: [(0, a.jsx)(d.GoogleSvg, {}), "LOG IN / SIGN UP WITH GOOGLE"]
        })
    }

    function m(e) {
        let {
            noredirect: n = !0
        } = e;
        return (0, a.jsx)(u.Suspense, {
            children: (0, a.jsx)(c, {
                noredirect: n
            })
        })
    }
    var p = e.i(244718),
        g = e.i(944779);

    function h() {
        let e = (0, l.usePathname)();
        return (0, a.jsxs)("button", {
            type: "button",
            "aria-label": "twitter-btn",
            className: `${s.default["login-btn"]} ${s.default.twitter}`,
            onClick: async () => {
                try {
                    let a = await (await g.authService.loginTwitter({
                        role: "user"
                    })).data;
                    g.authService.setTwitterToken({
                        oauthToken: a.oauth_token,
                        oauthTokenSecret: a.oauth_token_secret
                    }, "user"), localStorage.setItem("redirect", e), window.location.href = a.url
                } catch (e) {
                    (0, t.showError)(e)
                }
            },
            children: [(0, a.jsx)(p.XIcon, {}), "LOG IN / SIGN UP WITH X"]
        })
    }

    function f(e) {
        let {
            noredirect: t = !1
        } = e, {
            settings: o
        } = (0, n.useMainThemeLayout)();
        return o.googleLoginEnabled || o.twitterLoginEnabled ? (0, a.jsxs)("div", {
            className: s.default["social-login"],
            children: [(0, a.jsx)(h, {}), o.googleLoginClientId && o.googleLoginEnabled && (0, a.jsx)(m, {
                noredirect: t
            }), (0, a.jsx)(r.Divider, {
                children: "Or"
            })]
        }) : null
    }
    e.s(["default", () => f], 105299)
}, 355998, e => {
    "use strict";
    var a = e.i(843476),
        n = e.i(808613),
        r = e.i(872238),
        s = e.i(312361),
        t = e.i(522016),
        o = e.i(271645),
        i = e.i(217255),
        l = e.i(843577),
        d = e.i(731270),
        u = e.i(618566),
        c = e.i(465807);

    function m(e) {
        let {
            noredirect: m = !1
        } = e, [p, g] = (0, o.useState)(!1), {
            settings: h,
            setLoginModal: f
        } = (0, d.useMainThemeLayout)(), y = h ? .siteName || "", x = (0, u.useRouter)(), w = h.requireEmailVerification, b = (0, u.useSearchParams)().get("redirect"), _ = (0, u.useSearchParams)().get("login");
        return (0, a.jsxs)("div", {
            className: "auth-form",
            children: [(0, a.jsxs)(n.Form, {
                initialValues: {
                    username: "creator" === _ ? "anacheri@mailinator.com" : "mathewklear@mailinator.com",
                    password: "creator" === _ ? "Manunited@21" : "Arsenal@21"
                },
                onFinish: async e => {
                    g(!0);
                    let a = await (0, i.signIn)("credentials", { ...e,
                        redirect: !1
                    });
                    a ? .ok && (m ? (f({
                        openForm: ""
                    }), x.refresh()) : x.push(b && "/auth/login" !== b ? b : "/home")), a ? .error && (0, l.showError)(a.error), g(!1)
                },
                children: [(0, a.jsx)(n.Form.Item, {
                    name: "username",
                    validateTrigger: ["onChange", "onBlur"],
                    rules: c.usernameLogin,
                    children: (0, a.jsx)(r.Input, {
                        disabled: p,
                        placeholder: "Email or Username",
                        autoCapitalize: "off"
                    })
                }), (0, a.jsx)(n.Form.Item, {
                    name: "password",
                    validateTrigger: ["onChange", "onBlur"],
                    rules: c.passwordLogin,
                    children: (0, a.jsx)(r.Input.Password, {
                        disabled: p,
                        placeholder: "Password"
                    })
                }), !m && (0, a.jsxs)("div", {
                    style: {
                        display: "flex",
                        justifyContent: "space-between",
                        padding: "10px 0px"
                    },
                    children: [(0, a.jsx)(t.default, {
                        href: {
                            pathname: "/auth/forgot-password"
                        },
                        className: "sub-text",
                        children: "Forgot password?"
                    }), w && (0, a.jsx)(t.default, {
                        href: "/auth/resend-email",
                        className: "sub-text",
                        children: "Resend email verification"
                    })]
                }), (0, a.jsx)("button", {
                    disabled: p,
                    type: "submit",
                    className: "submit-btn",
                    children: "LOG IN"
                })]
            }), m ? (0, a.jsxs)("div", {
                className: "text-center",
                children: [(0, a.jsx)("p", {
                    style: {
                        marginBottom: 5
                    },
                    children: "Don't have an account yet?"
                }), (0, a.jsx)("p", {
                    children: (0, a.jsx)("a", {
                        "aria-hidden": !0,
                        onClick: () => f({
                            openForm: "signup"
                        }),
                        children: `Sign up for ${y}`
                    })
                })]
            }) : (0, a.jsxs)("div", {
                className: "text-center",
                children: [(0, a.jsxs)("p", {
                    style: {
                        fontSize: 11
                    },
                    children: ["Visit", " ", (0, a.jsx)(t.default, {
                        href: "/page/help",
                        children: "Help Center"
                    }), " ", "for any help if you are not able to login with your existing", " ", y, " ", "account"]
                }), (0, a.jsx)(s.Divider, {
                    style: {
                        margin: "15px 0"
                    }
                }), (0, a.jsx)("p", {
                    style: {
                        marginBottom: 5
                    },
                    children: "Don't have an account yet?"
                }), (0, a.jsx)("p", {
                    children: (0, a.jsx)(t.default, {
                        href: "/auth/register",
                        children: `Sign up for ${y}`
                    })
                })]
            })]
        })
    }

    function p(e) {
        let {
            noredirect: n = !1
        } = e;
        return (0, a.jsx)(o.Suspense, {
            children: (0, a.jsx)(m, {
                noredirect: n
            })
        })
    }
    e.s(["default", () => p])
}, 714815, e => {
    e.v({
        "ant-col": "style-module-scss-module__EqllSG__ant-col",
        "login-modal": "style-module-scss-module__EqllSG__login-modal",
        "title-login-modal": "style-module-scss-module__EqllSG__title-login-modal"
    })
}, 583460, e => {
    "use strict";
    var a = e.i(843476),
        n = e.i(840803),
        r = e.i(731270),
        s = e.i(657688),
        t = e.i(714815),
        o = e.i(355998),
        i = e.i(859718),
        l = e.i(105299);

    function d() {
        let {
            openForm: e,
            setLoginModal: d,
            settings: u
        } = (0, r.useMainThemeLayout)();
        if (!e) return null;
        let c = "login" === e;
        return (0, a.jsxs)(n.default, {
            className: t.default["login-modal"],
            width: 450,
            title: null,
            open: !!e,
            footer: null,
            onClose: () => d({
                openForm: ""
            }),
            children: [(0, a.jsx)("div", {
                className: "logo",
                children: u.logoUrl ? (0, a.jsx)(s.default, {
                    alt: "header-logo",
                    width: 90,
                    height: 60,
                    src: u.logoUrl
                }) : u.siteName || "Lustlabs.io"
            }), (0, a.jsx)("h3", {
                className: t.default["title-login-modal"],
                children: c ? "LOG IN" : "SIGN UP"
            }), (0, a.jsx)(l.default, {
                noredirect: !0
            }), c ? (0, a.jsx)(o.default, {
                noredirect: !0
            }) : (0, a.jsx)(i.default, {
                noredirect: !0
            })]
        })
    }
    e.s(["default", () => d])
}, 97314, e => {
    e.n(e.i(583460))
}]);