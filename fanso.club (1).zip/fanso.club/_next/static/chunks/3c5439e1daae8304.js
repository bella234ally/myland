(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 561405, e => {
    e.v({
        btn_grp: "style-module-scss-module__ZBrBeW__btn_grp",
        count: "style-module-scss-module__ZBrBeW__count",
        feed_content: "style-module-scss-module__ZBrBeW__feed_content",
        slide_top: "style-module-scss-module__ZBrBeW__slide_top"
    })
}, 703304, e => {
    e.v({
        image_w_blured: "image-with-blur-module-scss-module__0zrMpW__image_w_blured",
        overlay_blur: "image-with-blur-module-scss-module__0zrMpW__overlay_blur"
    })
}, 376341, e => {
    "use strict";
    var l = e.i(843476),
        s = e.i(271645),
        t = e.i(770703),
        i = e.i(391990),
        a = e.i(982719),
        d = e.i(657688),
        o = e.i(703304);
    let u = function(e) {
        let {
            src: t,
            alt: i,
            fallbackSrc: u = "/no-image.jpg",
            options: r,
            onClick: c
        } = e, [n, h] = (0, s.useState)(t);
        (0, s.useEffect)(() => {
            h(t)
        }, [t]);
        let m = {
            className: r ? .classes,
            width: 100,
            height: 100,
            sizes: "(max-width: 767px) 90vw, (min-width: 768px) 50vw",
            loading: "lazy",
            ...r
        };
        return r.priority && (m.loading = "eager"), r.fill && (delete m.width, delete m.height), (0, l.jsxs)("div", {
            className: o.default.image_w_blured,
            children: [(0, l.jsx)(d.default, {
                onClick: () => c && c(),
                alt: i,
                src: n,
                placeholder: "blur",
                blurDataURL: `data:image/svg+xml;base64,${(0,a.toBase64)((0,a.shimmer)(r?.width,r?.height))}`,
                onError: () => {
                    h(u)
                },
                ...m
            }), (0, l.jsx)("div", {
                className: o.default.overlay_blur,
                style: {
                    backgroundImage: `url(${n})`
                }
            })]
        })
    };

    function r(e) {
        let {
            priority: s,
            file: t,
            files: a
        } = e, {
            showPopup: d
        } = (0, i.useViewPopup)();
        return (0, l.jsx)(u, {
            options: {
                unoptimized: !0,
                width: t.width || 360,
                height: t.height || 500,
                priority: s,
                sizes: "(max-width: 768px) 80vw, (max-width: 2100px) 40vw"
            },
            alt: "post-photo",
            fallbackSrc: "/no-image.jpg",
            src: t ? .url || "/no-image.jpg",
            onClick: () => {
                d({
                    content: a,
                    index: 0
                })
            }
        }, t._id)
    }
    var c = e.i(561405);
    let n = (0, t.default)(() => e.A(40302), {
            loadableGenerated: {
                modules: [483461]
            },
            ssr: !1
        }),
        h = (0, t.default)(() => e.A(488045), {
            loadableGenerated: {
                modules: [658130]
            }
        }),
        m = (0, t.default)(() => e.A(559994), {
            loadableGenerated: {
                modules: [656857]
            }
        });

    function _(e) {
        let {
            feed: t,
            priority: i = !1
        } = e, [a, d] = (0, s.useState)(0), o = t.files[a];
        return (0, l.jsxs)("div", {
            className: c.default.feed_content,
            children: [t ? .files ? .length > 1 && (0, l.jsx)(n, {
                files: t.files,
                index: a,
                handleSlide: e => {
                    switch (e) {
                        case "next":
                            d(e => (e + 1) % t.files.length);
                            break;
                        case "prev":
                            d(e => (e - 1 + t.files.length) % t.files.length)
                    }
                }
            }), o.type.includes("photo") ? (0, l.jsx)(r, {
                priority: i,
                files: t.files,
                file: t.files[a]
            }) : o.type.includes("audio") ? (0, l.jsx)(m, {
                src: t.files[0].url,
                duration: t.files[0] ? .duration || 0,
                playerId: o._id
            }) : (0, l.jsx)(h, {
                classes: "f-vid-player",
                videoSrc: o.url,
                videoId: o._id,
                thumbUrl: o.thumbnails && o.thumbnails[0],
                aspectRatio: o.width && o.height ? o.width / o.height : ""
            }, o._id)]
        })
    }
    e.s(["default", () => _], 376341)
}, 750620, e => {
    e.n(e.i(376341))
}, 40302, e => {
    e.v(l => Promise.all(["static/chunks/90f8b31c11e7c929.js"].map(l => e.l(l))).then(() => l(483461)))
}, 488045, e => {
    e.v(l => Promise.all(["static/chunks/95fb8c2ef365731e.css", "static/chunks/6a03084f866fa452.js"].map(l => e.l(l))).then(() => l(658130)))
}, 559994, e => {
    e.v(l => Promise.all(["static/chunks/1398d135a43b6065.js", "static/chunks/a0a3d19144982ec2.js", "static/chunks/a8bc2d82ce4104be.css"].map(l => e.l(l))).then(() => l(656857)))
}]);