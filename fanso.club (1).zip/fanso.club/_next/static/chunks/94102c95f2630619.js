(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 306584, (e, t, n) => {
    "use strict";
    t.exports = r, t.exports.isMobile = r, t.exports.default = r;
    let a = /(android|bb\d+|meego).+mobile|armv7l|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|redmi|series[46]0|samsungbrowser.*mobile|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i,
        i = /CrOS/,
        o = /android|ipad|playbook|silk/i;

    function r(e) {
        e || (e = {});
        let t = e.ua;
        if (!t && "u" > typeof navigator && (t = navigator.userAgent), t && t.headers && "string" == typeof t.headers["user-agent"] && (t = t.headers["user-agent"]), "string" != typeof t) return !1;
        let n = a.test(t) && !i.test(t) || !!e.tablet && o.test(t);
        return !n && e.tablet && e.featureDetect && navigator && navigator.maxTouchPoints > 1 && -1 !== t.indexOf("Macintosh") && -1 !== t.indexOf("Safari") && (n = !0), n
    }
}, 721369, 425994, e => {
    "use strict";
    let t;
    e.i(247167);
    var n = e.i(271645),
        a = e.i(864517),
        i = e.i(867384),
        o = e.i(959013),
        r = e.i(207670),
        l = e.i(440383),
        d = e.i(306584);
    let s = (0, n.createContext)(null);
    var c = e.i(978052),
        u = e.i(940487),
        p = e.i(232839),
        f = e.i(737434);
    let b = {
        width: 0,
        height: 0,
        left: 0,
        top: 0
    };

    function m(e, t) {
        let a = n.useRef(e),
            [, i] = n.useState({});
        return [a.current, function(e) {
            let n = "function" == typeof e ? e(a.current) : e;
            n !== a.current && t(n, a.current), a.current = n, i({})
        }]
    }
    var h = e.i(401676);

    function $(e) {
        let [t, a] = (0, n.useState)(0), i = (0, n.useRef)(0), o = (0, n.useRef)();
        return o.current = e, (0, h.useLayoutUpdateEffect)(() => {
            o.current ? .()
        }, [t]), () => {
            i.current === t && (i.current += 1, a(i.current))
        }
    }
    let v = {
        width: 0,
        height: 0,
        left: 0,
        top: 0,
        right: 0
    };

    function g(e) {
        let t;
        return e instanceof Map ? (t = {}, e.forEach((e, n) => {
            t[n] = e
        })) : t = e, JSON.stringify(t)
    }

    function k(e) {
        return String(e).replace(/"/g, "TABS_DQ")
    }

    function y(e, t, n, a) {
        return !!n && !a && !1 !== e && (void 0 !== e || !1 !== t && null !== t)
    }
    let x = n.forwardRef((e, t) => {
            let {
                prefixCls: a,
                editable: i,
                locale: o,
                style: r
            } = e;
            return i && !1 !== i.showAdd ? n.createElement("button", {
                ref: t,
                type: "button",
                className: `${a}-nav-add`,
                style: r,
                "aria-label": o ? .addAriaLabel || "Add tab",
                onClick: e => {
                    i.onEdit("add", {
                        event: e
                    })
                }
            }, i.addIcon || "+") : null
        }),
        _ = n.forwardRef((e, t) => {
            let a, {
                position: i,
                prefixCls: o,
                extra: r
            } = e;
            if (!r) return null;
            let l = {};
            return "object" != typeof r || n.isValidElement(r) ? l.right = r : l = r, "right" === i && (a = l.right), "left" === i && (a = l.left), a ? n.createElement("div", {
                className: `${o}-extra-content`,
                ref: t
            }, a) : null
        });
    var w = e.i(328235),
        S = e.i(213381),
        E = e.i(965044);
    e.s(["MenuItem", () => E.default], 425994);
    var E = E,
        R = e.i(830731);

    function C() {
        return (C = Object.assign.bind()).apply(this, arguments)
    }
    let M = n.forwardRef((e, t) => {
            let {
                prefixCls: a,
                id: i,
                tabs: o,
                locale: l,
                mobile: d,
                more: s = {},
                style: c,
                className: u,
                editable: p,
                tabBarGutter: f,
                rtl: b,
                removeAriaLabel: m,
                onTabClick: h,
                getPopupContainer: $,
                popupClassName: v,
                popupStyle: g
            } = e, [k, _] = (0, n.useState)(!1), [M, L] = (0, n.useState)(null), {
                icon: I = "More"
            } = s, P = `${i}-more-popup`, T = `${a}-dropdown`, D = null !== M ? `${P}-${M}` : null, z = l ? .dropdownAriaLabel, N = n.createElement(S.default, {
                onClick: e => {
                    let {
                        key: t,
                        domEvent: n
                    } = e;
                    h(t, n), _(!1)
                },
                prefixCls: `${T}-menu`,
                id: P,
                tabIndex: -1,
                role: "listbox",
                "aria-activedescendant": D,
                selectedKeys: [M],
                "aria-label": void 0 !== z ? z : "expanded dropdown"
            }, o.map(e => {
                let {
                    closable: t,
                    disabled: a,
                    closeIcon: o,
                    key: r,
                    label: l
                } = e, d = y(t, o, p, a);
                return n.createElement(E.default, {
                    key: r,
                    id: `${P}-${r}`,
                    role: "option",
                    "aria-controls": i && `${i}-panel-${r}`,
                    disabled: a
                }, n.createElement("span", null, l), d && n.createElement("button", {
                    type: "button",
                    "aria-label": m || "remove",
                    tabIndex: 0,
                    className: `${T}-menu-item-remove`,
                    onClick: e => {
                        e.stopPropagation(), e.preventDefault(), e.stopPropagation(), p.onEdit("remove", {
                            key: r,
                            event: e
                        })
                    }
                }, o || p.removeIcon || "×"))
            }));

            function B(e) {
                let t = o.filter(e => !e.disabled),
                    n = t.findIndex(e => e.key === M) || 0,
                    a = t.length;
                for (let i = 0; i < a; i += 1) {
                    let i = t[n = (n + e + a) % a];
                    if (!i.disabled) return void L(i.key)
                }
            }(0, n.useEffect)(() => {
                let e = document.getElementById(D);
                e ? .scrollIntoView && e.scrollIntoView(!1)
            }, [D, M]), (0, n.useEffect)(() => {
                k || L(null)
            }, [k]);
            let H = {
                marginInlineStart: f
            };
            o.length || (H.visibility = "hidden", H.order = 1);
            let O = (0, r.clsx)(v, {
                    [`${T}-rtl`]: b
                }),
                A = d ? null : n.createElement(w.default, C({
                    prefixCls: T,
                    overlay: N,
                    visible: !!o.length && k,
                    onVisibleChange: _,
                    overlayClassName: O,
                    overlayStyle: g,
                    mouseEnterDelay: .1,
                    mouseLeaveDelay: .1,
                    getPopupContainer: $
                }, s), n.createElement("button", {
                    type: "button",
                    className: `${a}-nav-more`,
                    style: H,
                    "aria-haspopup": "listbox",
                    "aria-controls": P,
                    id: `${i}-more`,
                    "aria-expanded": k,
                    onKeyDown: function(e) {
                        let {
                            which: t
                        } = e;
                        if (!k) {
                            [R.default.DOWN, R.default.SPACE, R.default.ENTER].includes(t) && (_(!0), e.preventDefault());
                            return
                        }
                        switch (t) {
                            case R.default.UP:
                                B(-1), e.preventDefault();
                                break;
                            case R.default.DOWN:
                                B(1), e.preventDefault();
                                break;
                            case R.default.ESC:
                                _(!1);
                                break;
                            case R.default.SPACE:
                            case R.default.ENTER:
                                null !== M && h(M, e)
                        }
                    }
                }, I));
            return n.createElement("div", {
                className: (0, r.clsx)(`${a}-nav-operations`, u),
                style: c,
                ref: t
            }, A, n.createElement(x, {
                prefixCls: a,
                locale: l,
                editable: p
            }))
        }),
        L = n.memo(M, (e, t) => t.tabMoving),
        I = e => {
            let {
                prefixCls: t,
                id: a,
                active: i,
                focus: o,
                tab: {
                    key: l,
                    label: d,
                    disabled: s,
                    closeIcon: c,
                    icon: u
                },
                closable: p,
                renderWrapper: f,
                removeAriaLabel: b,
                editable: m,
                onClick: h,
                onFocus: $,
                onBlur: v,
                onKeyDown: g,
                onMouseDown: x,
                onMouseUp: _,
                style: w,
                className: S,
                tabCount: E,
                currentPosition: R
            } = e, C = `${t}-tab`, M = y(p, c, m, s);

            function L(e) {
                s || h(e)
            }
            let I = n.useMemo(() => u && "string" == typeof d ? n.createElement("span", null, d) : d, [d, u]),
                P = n.useRef(null);
            n.useEffect(() => {
                o && P.current && P.current.focus()
            }, [o]);
            let T = n.createElement("div", {
                key: l,
                "data-node-key": k(l),
                className: (0, r.clsx)(C, S, {
                    [`${C}-with-remove`]: M,
                    [`${C}-active`]: i,
                    [`${C}-disabled`]: s,
                    [`${C}-focus`]: o
                }),
                style: w,
                onClick: L
            }, n.createElement("div", {
                ref: P,
                role: "tab",
                "aria-selected": i,
                id: a && `${a}-tab-${l}`,
                className: `${C}-btn`,
                "aria-controls": a && `${a}-panel-${l}`,
                "aria-disabled": s,
                tabIndex: s ? null : i ? 0 : -1,
                onClick: e => {
                    e.stopPropagation(), L(e)
                },
                onKeyDown: g,
                onMouseDown: x,
                onMouseUp: _,
                onFocus: $,
                onBlur: v
            }, o && n.createElement("div", {
                "aria-live": "polite",
                style: {
                    width: 0,
                    height: 0,
                    position: "absolute",
                    overflow: "hidden",
                    opacity: 0
                }
            }, `Tab ${R} of ${E}`), u && n.createElement("span", {
                className: `${C}-icon`
            }, u), d && I), M && n.createElement("button", {
                type: "button",
                "aria-label": b || "remove",
                tabIndex: i ? 0 : -1,
                className: `${C}-remove`,
                onClick: e => {
                    e.stopPropagation(), e.preventDefault(), e.stopPropagation(), m.onEdit("remove", {
                        key: l,
                        event: e
                    })
                }
            }, c || m.removeIcon || "×"));
            return f ? f(T) : T
        };

    function P() {
        return (P = Object.assign.bind()).apply(this, arguments)
    }
    let T = e => {
            let {
                offsetWidth: t = 0,
                offsetHeight: n = 0
            } = e.current || {};
            if (e.current) {
                let {
                    width: n,
                    height: a
                } = e.current.getBoundingClientRect();
                if (1 > Math.abs(n - t)) return [n, a]
            }
            return [t, n]
        },
        D = (e, t) => e[+!t],
        z = n.forwardRef((e, t) => {
            var a;
            let i, o, l, d, {
                    className: h,
                    style: w,
                    id: S,
                    animated: E,
                    activeKey: R,
                    rtl: C,
                    extra: M,
                    editable: z,
                    locale: N,
                    tabPosition: B,
                    tabBarGutter: H,
                    children: O,
                    onTabClick: A,
                    onTabScroll: W,
                    indicator: G,
                    classNames: X,
                    styles: j
                } = e,
                {
                    prefixCls: F,
                    tabs: K
                } = n.useContext(s),
                q = (0, n.useRef)(null),
                U = (0, n.useRef)(null),
                V = (0, n.useRef)(null),
                Y = (0, n.useRef)(null),
                J = (0, n.useRef)(null),
                Q = (0, n.useRef)(null),
                Z = (0, n.useRef)(null),
                ee = "top" === B || "bottom" === B,
                [et, en] = m(0, (e, t) => {
                    ee && W && W({
                        direction: e > t ? "left" : "right"
                    })
                }),
                [ea, ei] = m(0, (e, t) => {
                    !ee && W && W({
                        direction: e > t ? "top" : "bottom"
                    })
                }),
                [eo, er] = (0, n.useState)([0, 0]),
                [el, ed] = (0, n.useState)([0, 0]),
                [es, ec] = (0, n.useState)([0, 0]),
                [eu, ep] = (0, n.useState)([0, 0]),
                [ef, eb] = function(e) {
                    let t = (0, n.useRef)([]),
                        [, a] = (0, n.useState)({}),
                        i = (0, n.useRef)("function" == typeof e ? e() : e),
                        o = $(() => {
                            let e = i.current;
                            t.current.forEach(t => {
                                e = t(e)
                            }), t.current = [], i.current = e, a({})
                        });
                    return [i.current, function(e) {
                        t.current.push(e), o()
                    }]
                }(new Map),
                em = (a = el[0], (0, n.useMemo)(() => {
                    let e = new Map,
                        t = ef.get(K[0] ? .key) || b,
                        n = t.left + t.width;
                    for (let t = 0; t < K.length; t += 1) {
                        let {
                            key: a
                        } = K[t], i = ef.get(a);
                        i || (i = ef.get(K[t - 1] ? .key) || b);
                        let o = e.get(a) || { ...i
                        };
                        o.right = n - o.left - o.width, e.set(a, o)
                    }
                    return e
                }, [K.map(e => e.key).join("_"), ef, a])),
                eh = D(eo, ee),
                e$ = D(el, ee),
                ev = D(es, ee),
                eg = D(eu, ee),
                ek = Math.floor(eh) < Math.floor(e$ + ev),
                ey = ek ? eh - eg : eh - ev,
                ex = `${F}-nav-operations-hidden`,
                e_ = 0,
                ew = 0;

            function eS(e) {
                return e < e_ ? e_ : e > ew ? ew : e
            }
            ee && C ? (e_ = 0, ew = Math.max(0, e$ - ey)) : (e_ = Math.min(0, ey - e$), ew = 0);
            let eE = (0, n.useRef)(null),
                [eR, eC] = (0, n.useState)();

            function eM() {
                eC(Date.now())
            }

            function eL() {
                eE.current && clearTimeout(eE.current)
            }! function(e, t) {
                let [a, i] = (0, n.useState)(), [o, r] = (0, n.useState)(0), [l, d] = (0, n.useState)(0), [s, c] = (0, n.useState)(), u = (0, n.useRef)(), p = (0, n.useRef)(), f = (0, n.useRef)(null);
                f.current = {
                    onTouchStart: function(e) {
                        let {
                            screenX: t,
                            screenY: n
                        } = e.touches[0];
                        i({
                            x: t,
                            y: n
                        }), window.clearInterval(u.current)
                    },
                    onTouchMove: function(e) {
                        if (!a) return;
                        let {
                            screenX: n,
                            screenY: l
                        } = e.touches[0];
                        i({
                            x: n,
                            y: l
                        });
                        let s = n - a.x,
                            u = l - a.y;
                        t(s, u);
                        let p = Date.now();
                        r(p), d(p - o), c({
                            x: s,
                            y: u
                        })
                    },
                    onTouchEnd: function() {
                        if (a && (i(null), c(null), s)) {
                            let e = s.x / l,
                                n = s.y / l;
                            if (.1 > Math.max(Math.abs(e), Math.abs(n))) return;
                            let a = e,
                                i = n;
                            u.current = window.setInterval(() => {
                                .01 > Math.abs(a) && .01 > Math.abs(i) ? window.clearInterval(u.current) : (a *= .9046104802746175, i *= .9046104802746175, t(20 * a, 20 * i))
                            }, 20)
                        }
                    },
                    onWheel: function(e) {
                        let {
                            deltaX: n,
                            deltaY: a
                        } = e, i = 0, o = Math.abs(n), r = Math.abs(a);
                        o === r ? i = "x" === p.current ? n : a : o > r ? (i = n, p.current = "x") : (i = a, p.current = "y"), t(-i, -i) && e.preventDefault()
                    }
                }, n.useEffect(() => {
                    function t(e) {
                        f.current.onTouchMove(e)
                    }

                    function n(e) {
                        f.current.onTouchEnd(e)
                    }
                    return document.addEventListener("touchmove", t, {
                        passive: !1
                    }), document.addEventListener("touchend", n, {
                        passive: !0
                    }), e.current.addEventListener("touchstart", function(e) {
                        f.current.onTouchStart(e)
                    }, {
                        passive: !0
                    }), e.current.addEventListener("wheel", function(e) {
                        f.current.onWheel(e)
                    }, {
                        passive: !1
                    }), () => {
                        document.removeEventListener("touchmove", t), document.removeEventListener("touchend", n)
                    }
                }, [])
            }(Y, (e, t) => {
                var n, a, i, o;
                return !!ek && (ee ? (n = en, a = e, n(e => eS(e + a))) : (i = ei, o = t, i(e => eS(e + o))), eL(), eM(), !0)
            }), (0, n.useEffect)(() => (eL(), eR && (eE.current = setTimeout(() => {
                eC(0)
            }, 100)), eL), [eR]);
            let [eI, eP] = function(e, t, a, i, o, r, l) {
                let d, s, c, {
                    tabs: u,
                    tabPosition: p,
                    rtl: f
                } = l;
                return ["top", "bottom"].includes(p) ? (d = "width", s = f ? "right" : "left", c = Math.abs(a)) : (d = "height", s = "top", c = -a), (0, n.useMemo)(() => {
                    if (!u.length) return [0, 0];
                    let n = u.length,
                        a = n;
                    for (let i = 0; i < n; i += 1) {
                        let n = e.get(u[i].key) || v;
                        if (Math.floor(n[s] + n[d]) > Math.floor(c + t)) {
                            a = i - 1;
                            break
                        }
                    }
                    let i = 0;
                    for (let t = n - 1; t >= 0; t -= 1)
                        if ((e.get(u[t].key) || v)[s] < c) {
                            i = t + 1;
                            break
                        }
                    return i > a ? [0, -1] : [i, a]
                }, [e, t, i, o, r, c, p, u.map(e => e.key).join("_"), f])
            }(em, ey, ee ? et : ea, e$, ev, eg, { ...e,
                tabs: K
            }), eT = (0, u.default)(function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : R,
                    t = em.get(e) || {
                        width: 0,
                        height: 0,
                        left: 0,
                        right: 0,
                        top: 0
                    };
                if (ee) {
                    let e = et;
                    C ? t.right < et ? e = t.right : t.right + t.width > et + ey && (e = t.right + t.width - ey) : t.left < -et ? e = -t.left : t.left + t.width > -et + ey && (e = -(t.left + t.width - ey)), ei(0), en(eS(e))
                } else {
                    let e = ea;
                    t.top < -ea ? e = -t.top : t.top + t.height > -ea + ey && (e = -(t.top + t.height - ey)), en(0), ei(eS(e))
                }
            }), [eD, ez] = (0, n.useState)(), [eN, eB] = (0, n.useState)(!1), eH = K.filter(e => !e.disabled).map(e => e.key), eO = e => {
                let t = eH.indexOf(eD || R),
                    n = eH.length;
                ez(eH[(t + e + n) % n])
            }, eA = (e, t) => {
                let n = eH.indexOf(e),
                    a = K.find(t => t.key === e);
                y(a ? .closable, a ? .closeIcon, z, a ? .disabled) && (t.preventDefault(), t.stopPropagation(), z.onEdit("remove", {
                    key: e,
                    event: t
                }), n === eH.length - 1 ? eO(-1) : eO(1))
            }, eW = e => {
                let {
                    code: t
                } = e, n = C && ee, a = eH[0], i = eH[eH.length - 1];
                switch (t) {
                    case "ArrowLeft":
                        ee && eO(n ? 1 : -1);
                        break;
                    case "ArrowRight":
                        ee && eO(n ? -1 : 1);
                        break;
                    case "ArrowUp":
                        e.preventDefault(), ee || eO(-1);
                        break;
                    case "ArrowDown":
                        e.preventDefault(), ee || eO(1);
                        break;
                    case "Home":
                        e.preventDefault(), ez(a);
                        break;
                    case "End":
                        e.preventDefault(), ez(i);
                        break;
                    case "Enter":
                    case "Space":
                        e.preventDefault(), A(eD ? ? R, e);
                        break;
                    case "Backspace":
                    case "Delete":
                        eA(eD, e)
                }
            }, eG = {};
            ee ? eG.marginInlineStart = H : eG.marginTop = H;
            let eX = K.map((e, t) => {
                    let {
                        key: a
                    } = e;
                    return n.createElement(I, {
                        id: S,
                        prefixCls: F,
                        key: a,
                        tab: e,
                        className: X ? .item,
                        style: 0 === t ? j ? .item : { ...eG,
                            ...j ? .item
                        },
                        closable: e.closable,
                        editable: z,
                        active: a === R,
                        focus: a === eD,
                        renderWrapper: O,
                        removeAriaLabel: N ? .removeAriaLabel,
                        tabCount: eH.length,
                        currentPosition: t + 1,
                        onClick: e => {
                            A(a, e)
                        },
                        onKeyDown: eW,
                        onFocus: () => {
                            eN || ez(a), eT(a), eM(), Y.current && (C || (Y.current.scrollLeft = 0), Y.current.scrollTop = 0)
                        },
                        onBlur: () => {
                            ez(void 0)
                        },
                        onMouseDown: e => {
                            eB(!0), 1 === e.button && eA(a, e)
                        },
                        onMouseUp: () => {
                            eB(!1)
                        }
                    })
                }),
                ej = () => eb(() => {
                    let e = new Map,
                        t = J.current ? .getBoundingClientRect();
                    return K.forEach(n => {
                        let {
                            key: a
                        } = n, i = J.current ? .querySelector(`[data-node-key="${k(a)}"]`);
                        if (i) {
                            let [n, o, r, l] = ((e, t) => {
                                let {
                                    offsetWidth: n,
                                    offsetHeight: a,
                                    offsetTop: i,
                                    offsetLeft: o
                                } = e, {
                                    width: r,
                                    height: l,
                                    left: d,
                                    top: s
                                } = e.getBoundingClientRect();
                                return 1 > Math.abs(r - n) ? [r, l, d - t.left, s - t.top] : [n, a, o, i]
                            })(i, t);
                            e.set(a, {
                                width: n,
                                height: o,
                                left: r,
                                top: l
                            })
                        }
                    }), e
                });
            (0, n.useEffect)(() => {
                ej()
            }, [K.map(e => e.key).join("_")]);
            let eF = $(() => {
                    let e = T(q),
                        t = T(U),
                        n = T(V);
                    er([e[0] - t[0] - n[0], e[1] - t[1] - n[1]]);
                    let a = T(Z);
                    ec(a), ep(T(Q));
                    let i = T(J);
                    ed([i[0] - a[0], i[1] - a[1]]), ej()
                }),
                eK = [...K.slice(0, eI), ...K.slice(eP + 1)],
                eq = em.get(R),
                {
                    style: eU
                } = (e => {
                    let {
                        activeTabOffset: t,
                        horizontal: a,
                        rtl: i,
                        indicator: o = {}
                    } = e, {
                        size: r,
                        align: l = "center"
                    } = o, [d, s] = (0, n.useState)(), c = (0, n.useRef)(), u = n.default.useCallback(e => "function" == typeof r ? r(e) : "number" == typeof r ? r : e, [r]);

                    function p() {
                        f.default.cancel(c.current)
                    }
                    return (0, n.useEffect)(() => {
                        let e = {};
                        if (t)
                            if (a) {
                                e.width = u(t.width);
                                let n = i ? "right" : "left";
                                "start" === l && (e[n] = t[n]), "center" === l && (e[n] = t[n] + t.width / 2, e.transform = i ? "translateX(50%)" : "translateX(-50%)"), "end" === l && (e[n] = t[n] + t.width, e.transform = "translateX(-100%)")
                            } else e.height = u(t.height), "start" === l && (e.top = t.top), "center" === l && (e.top = t.top + t.height / 2, e.transform = "translateY(-50%)"), "end" === l && (e.top = t.top + t.height, e.transform = "translateY(-100%)");
                        return p(), c.current = (0, f.default)(() => {
                            d && e && Object.keys(e).every(t => {
                                let n = e[t],
                                    a = d[t];
                                return "number" == typeof n && "number" == typeof a ? Math.round(n) === Math.round(a) : n === a
                            }) || s(e)
                        }), p
                    }, [JSON.stringify(t), a, i, l, u]), {
                        style: d
                    }
                })({
                    activeTabOffset: eq,
                    horizontal: ee,
                    indicator: G,
                    rtl: C
                });
            (0, n.useEffect)(() => {
                eT()
            }, [R, e_, ew, g(eq), g(em), ee]), (0, n.useEffect)(() => {
                eF()
            }, [C]);
            let eV = !!eK.length,
                eY = `${F}-nav-wrap`;
            return ee ? C ? (o = et > 0, i = et !== ew) : (i = et < 0, o = et !== e_) : (l = ea < 0, d = ea !== e_), n.createElement(c.default, {
                onResize: eF
            }, n.createElement("div", {
                ref: (0, p.useComposeRef)(t, q),
                role: "tablist",
                "aria-orientation": ee ? "horizontal" : "vertical",
                className: (0, r.clsx)(`${F}-nav`, h, X ? .header),
                style: { ...j ? .header,
                    ...w
                },
                onKeyDown: () => {
                    eM()
                }
            }, n.createElement(_, {
                ref: U,
                position: "left",
                extra: M,
                prefixCls: F
            }), n.createElement(c.default, {
                onResize: eF
            }, n.createElement("div", {
                className: (0, r.clsx)(eY, {
                    [`${eY}-ping-left`]: i,
                    [`${eY}-ping-right`]: o,
                    [`${eY}-ping-top`]: l,
                    [`${eY}-ping-bottom`]: d
                }),
                ref: Y
            }, n.createElement(c.default, {
                onResize: eF
            }, n.createElement("div", {
                ref: J,
                className: `${F}-nav-list`,
                style: {
                    transform: `translate(${et}px, ${ea}px)`,
                    transition: eR ? "none" : void 0
                }
            }, eX, n.createElement(x, {
                ref: Z,
                prefixCls: F,
                locale: N,
                editable: z,
                style: { ...0 === eX.length ? void 0 : eG,
                    visibility: eV ? "hidden" : null
                }
            }), n.createElement("div", {
                className: (0, r.clsx)(`${F}-ink-bar`, X ? .indicator, {
                    [`${F}-ink-bar-animated`]: E.inkBar
                }),
                style: { ...eU,
                    ...j ? .indicator
                }
            }))))), n.createElement(L, P({}, e, {
                removeAriaLabel: N ? .removeAriaLabel,
                ref: Q,
                prefixCls: F,
                tabs: eK,
                className: !eV && ex,
                popupStyle: j ? .popup,
                tabMoving: !!eR
            })), n.createElement(_, {
                ref: V,
                position: "right",
                extra: M,
                prefixCls: F
            })))
        }),
        N = e => {
            let {
                renderTabBar: t,
                ...a
            } = e;
            return t ? t(a, z) : n.createElement(z, a)
        };
    var B = e.i(128473);
    let H = n.forwardRef((e, t) => {
        let {
            prefixCls: a,
            className: i,
            style: o,
            id: l,
            active: d,
            tabKey: s,
            children: c
        } = e, u = n.Children.count(c) > 0;
        return n.createElement("div", {
            id: l && `${l}-panel-${s}`,
            role: "tabpanel",
            tabIndex: d && u ? 0 : -1,
            "aria-labelledby": l && `${l}-tab-${s}`,
            "aria-hidden": !d,
            style: o,
            className: (0, r.clsx)(a, d && `${a}-active`, i),
            ref: t
        }, c)
    });

    function O() {
        return (O = Object.assign.bind()).apply(this, arguments)
    }
    let A = e => {
        let {
            id: t,
            activeKey: a,
            animated: i,
            tabPosition: o,
            destroyOnHidden: l,
            contentStyle: d,
            contentClassName: c
        } = e, {
            prefixCls: u,
            tabs: p
        } = n.useContext(s), f = i.tabPane, b = `${u}-tabpane`;
        return n.createElement("div", {
            className: (0, r.clsx)(`${u}-content-holder`)
        }, n.createElement("div", {
            className: (0, r.clsx)(`${u}-content`, `${u}-content-${o}`, {
                [`${u}-content-animated`]: f
            })
        }, p.map(e => {
            let {
                key: o,
                forceRender: s,
                style: u,
                className: p,
                destroyOnHidden: m,
                ...h
            } = e, $ = o === a;
            return n.createElement(B.default, O({
                key: o,
                visible: $,
                forceRender: s,
                removeOnLeave: !!(l ? ? m),
                leavedClassName: `${b}-hidden`
            }, i.tabPaneMotion), (e, a) => {
                let {
                    style: i,
                    className: l
                } = e;
                return n.createElement(H, O({}, h, {
                    prefixCls: b,
                    id: t,
                    tabKey: o,
                    animated: f,
                    active: $,
                    style: { ...d,
                        ...u,
                        ...i
                    },
                    className: (0, r.clsx)(c, p, l),
                    ref: a
                }))
            })
        })))
    };

    function W() {
        return (W = Object.assign.bind()).apply(this, arguments)
    }
    e.i(24308);
    let G = 0,
        X = n.forwardRef((e, a) => {
            let {
                id: i,
                prefixCls: o = "rc-tabs",
                className: c,
                items: u,
                direction: p,
                activeKey: f,
                defaultActiveKey: b,
                editable: m,
                animated: h,
                tabPosition: $ = "top",
                tabBarGutter: v,
                tabBarStyle: g,
                tabBarExtraContent: k,
                locale: y,
                more: x,
                destroyOnHidden: _,
                renderTabBar: w,
                onChange: S,
                onTabClick: E,
                onTabScroll: R,
                getPopupContainer: C,
                popupClassName: M,
                indicator: L,
                classNames: I,
                styles: P,
                ...T
            } = e, D = n.useMemo(() => (u || []).filter(e => e && "object" == typeof e && "key" in e), [u]), z = "rtl" === p, B = function() {
                let e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                    inkBar: !0,
                    tabPane: !1
                };
                return (e = !1 === t ? {
                    inkBar: !1,
                    tabPane: !1
                } : !0 === t ? {
                    inkBar: !0,
                    tabPane: !1
                } : {
                    inkBar: !0,
                    ..."object" == typeof t ? t : {}
                }).tabPaneMotion && void 0 === e.tabPane && (e.tabPane = !0), !e.tabPaneMotion && e.tabPane && (e.tabPane = !1), e
            }(h), [H, O] = (0, n.useState)(!1);
            (0, n.useEffect)(() => {
                O((void 0 === t && (t = (0, d.default)()), t))
            }, []);
            let [X, j] = (0, l.default)(b ? ? D[0] ? .key, f), [F, K] = (0, n.useState)(() => D.findIndex(e => e.key === X));
            (0, n.useEffect)(() => {
                let e = D.findIndex(e => e.key === X); - 1 === e && (e = Math.max(0, Math.min(F, D.length - 1)), j(D[e] ? .key)), K(e)
            }, [D.map(e => e.key).join("_"), X, F]);
            let [q, U] = (0, l.default)(null, i);
            (0, n.useEffect)(() => {
                i || (U(`rc-tabs-${G}`), G += 1)
            }, []);
            let V = {
                    id: q,
                    activeKey: X,
                    animated: B,
                    tabPosition: $,
                    rtl: z,
                    mobile: H
                },
                Y = { ...V,
                    editable: m,
                    locale: y,
                    more: x,
                    tabBarGutter: v,
                    onTabClick: function(e, t) {
                        E ? .(e, t);
                        let n = e !== X;
                        j(e), n && S ? .(e)
                    },
                    onTabScroll: R,
                    extra: k,
                    style: g,
                    getPopupContainer: C,
                    popupClassName: (0, r.clsx)(M, I ? .popup),
                    indicator: L,
                    styles: P,
                    classNames: I
                },
                J = n.useMemo(() => ({
                    tabs: D,
                    prefixCls: o
                }), [D, o]);
            return n.createElement(s.Provider, {
                value: J
            }, n.createElement("div", W({
                ref: a,
                id: i,
                className: (0, r.clsx)(o, `${o}-${$}`, {
                    [`${o}-mobile`]: H,
                    [`${o}-editable`]: m,
                    [`${o}-rtl`]: z
                }, c)
            }, T), n.createElement(N, W({}, Y, {
                renderTabBar: w
            })), n.createElement(A, W({
                destroyOnHidden: _
            }, V, {
                contentStyle: P ? .content,
                contentClassName: I ? .content,
                animated: B
            }))))
        });
    var j = e.i(711517),
        F = e.i(242064),
        K = e.i(321883),
        q = e.i(517455),
        U = e.i(613541);
    let V = {
        motionAppear: !1,
        motionEnter: !0,
        motionLeave: !0
    };
    e.i(63335);
    var Y = e.i(943081);
    e.i(296059);
    var J = e.i(915654),
        Q = e.i(183293),
        Z = e.i(246422),
        ee = e.i(838378),
        et = e.i(664142);
    let en = (0, Z.genStyleHooks)("Tabs", e => {
            let t = (0, ee.mergeToken)(e, {
                tabsCardPadding: e.cardPadding,
                dropdownEdgeChildVerticalPadding: e.paddingXXS,
                tabsDropdownHeight: 200,
                tabsDropdownWidth: 120,
                tabsHorizontalItemMargin: `0 0 0 ${(0,J.unit)(e.horizontalItemGutter)}`,
                tabsHorizontalItemMarginRTL: `0 0 0 ${(0,J.unit)(e.horizontalItemGutter)}`
            });
            return [(e => {
                let {
                    componentCls: t,
                    cardPaddingSM: n,
                    cardPaddingLG: a,
                    cardHeightSM: i,
                    cardHeightLG: o,
                    horizontalItemPaddingSM: r,
                    horizontalItemPaddingLG: l
                } = e;
                return {
                    [t]: {
                        "&-small": {
                            [`> ${t}-nav`]: {
                                [`${t}-tab`]: {
                                    padding: r,
                                    fontSize: e.titleFontSizeSM
                                }
                            }
                        },
                        "&-large": {
                            [`> ${t}-nav`]: {
                                [`${t}-tab`]: {
                                    padding: l,
                                    fontSize: e.titleFontSizeLG,
                                    lineHeight: e.lineHeightLG
                                }
                            }
                        }
                    },
                    [`${t}-card`]: {
                        [`&${t}-small`]: {
                            [`> ${t}-nav`]: {
                                [`${t}-tab`]: {
                                    padding: n
                                },
                                [`${t}-nav-add`]: {
                                    minWidth: i,
                                    minHeight: i
                                }
                            },
                            [`&${t}-bottom`]: {
                                [`> ${t}-nav ${t}-tab`]: {
                                    borderRadius: `0 0 ${(0,J.unit)(e.borderRadius)} ${(0,J.unit)(e.borderRadius)}`
                                }
                            },
                            [`&${t}-top`]: {
                                [`> ${t}-nav ${t}-tab`]: {
                                    borderRadius: `${(0,J.unit)(e.borderRadius)} ${(0,J.unit)(e.borderRadius)} 0 0`
                                }
                            },
                            [`&${t}-right`]: {
                                [`> ${t}-nav ${t}-tab`]: {
                                    borderRadius: {
                                        _skip_check_: !0,
                                        value: `0 ${(0,J.unit)(e.borderRadius)} ${(0,J.unit)(e.borderRadius)} 0`
                                    }
                                }
                            },
                            [`&${t}-left`]: {
                                [`> ${t}-nav ${t}-tab`]: {
                                    borderRadius: {
                                        _skip_check_: !0,
                                        value: `${(0,J.unit)(e.borderRadius)} 0 0 ${(0,J.unit)(e.borderRadius)}`
                                    }
                                }
                            }
                        },
                        [`&${t}-large`]: {
                            [`> ${t}-nav`]: {
                                [`${t}-tab`]: {
                                    padding: a
                                },
                                [`${t}-nav-add`]: {
                                    minWidth: o,
                                    minHeight: o
                                }
                            }
                        }
                    }
                }
            })(t), (e => {
                let {
                    componentCls: t,
                    tabsHorizontalItemMarginRTL: n,
                    iconCls: a,
                    cardGutter: i,
                    calc: o
                } = e;
                return {
                    [`${t}-rtl`]: {
                        direction: "rtl",
                        [`${t}-nav`]: {
                            [`${t}-tab`]: {
                                margin: {
                                    _skip_check_: !0,
                                    value: n
                                },
                                [`${t}-tab:last-of-type`]: {
                                    marginLeft: {
                                        _skip_check_: !0,
                                        value: 0
                                    }
                                },
                                [a]: {
                                    marginRight: {
                                        _skip_check_: !0,
                                        value: 0
                                    },
                                    marginLeft: {
                                        _skip_check_: !0,
                                        value: (0, J.unit)(e.marginSM)
                                    }
                                },
                                [`${t}-tab-remove`]: {
                                    marginRight: {
                                        _skip_check_: !0,
                                        value: (0, J.unit)(e.marginXS)
                                    },
                                    marginLeft: {
                                        _skip_check_: !0,
                                        value: (0, J.unit)(o(e.marginXXS).mul(-1).equal())
                                    },
                                    [a]: {
                                        margin: 0
                                    }
                                }
                            }
                        },
                        [`&${t}-left`]: {
                            [`> ${t}-nav`]: {
                                order: 1
                            },
                            [`> ${t}-content-holder`]: {
                                order: 0
                            }
                        },
                        [`&${t}-right`]: {
                            [`> ${t}-nav`]: {
                                order: 0
                            },
                            [`> ${t}-content-holder`]: {
                                order: 1
                            }
                        },
                        [`&${t}-card${t}-top, &${t}-card${t}-bottom`]: {
                            [`> ${t}-nav, > div > ${t}-nav`]: {
                                [`${t}-tab + ${t}-tab`]: {
                                    marginRight: {
                                        _skip_check_: !0,
                                        value: i
                                    },
                                    marginLeft: {
                                        _skip_check_: !0,
                                        value: 0
                                    }
                                }
                            }
                        }
                    },
                    [`${t}-dropdown-rtl`]: {
                        direction: "rtl"
                    },
                    [`${t}-menu-item`]: {
                        [`${t}-dropdown-rtl`]: {
                            textAlign: {
                                _skip_check_: !0,
                                value: "right"
                            }
                        }
                    }
                }
            })(t), (e => {
                let {
                    componentCls: t,
                    margin: n,
                    colorBorderSecondary: a,
                    horizontalMargin: i,
                    verticalItemPadding: o,
                    verticalItemMargin: r,
                    calc: l
                } = e;
                return {
                    [`${t}-top, ${t}-bottom`]: {
                        flexDirection: "column",
                        [`> ${t}-nav, > div > ${t}-nav`]: {
                            margin: i,
                            "&::before": {
                                position: "absolute",
                                right: {
                                    _skip_check_: !0,
                                    value: 0
                                },
                                left: {
                                    _skip_check_: !0,
                                    value: 0
                                },
                                borderBottom: `${(0,J.unit)(e.lineWidth)} ${e.lineType} ${a}`,
                                content: "''"
                            },
                            [`${t}-ink-bar`]: {
                                height: e.lineWidthBold,
                                "&-animated": {
                                    transition: `width ${e.motionDurationSlow}, left ${e.motionDurationSlow},
            right ${e.motionDurationSlow}`
                                }
                            },
                            [`${t}-nav-wrap`]: {
                                "&::before, &::after": {
                                    top: 0,
                                    bottom: 0,
                                    width: e.controlHeight
                                },
                                "&::before": {
                                    left: {
                                        _skip_check_: !0,
                                        value: 0
                                    },
                                    boxShadow: e.boxShadowTabsOverflowLeft
                                },
                                "&::after": {
                                    right: {
                                        _skip_check_: !0,
                                        value: 0
                                    },
                                    boxShadow: e.boxShadowTabsOverflowRight
                                },
                                [`&${t}-nav-wrap-ping-left::before`]: {
                                    opacity: 1
                                },
                                [`&${t}-nav-wrap-ping-right::after`]: {
                                    opacity: 1
                                }
                            }
                        }
                    },
                    [`${t}-top`]: {
                        [`> ${t}-nav,
        > div > ${t}-nav`]: {
                            "&::before": {
                                bottom: 0
                            },
                            [`${t}-ink-bar`]: {
                                bottom: 0
                            }
                        }
                    },
                    [`${t}-bottom`]: {
                        [`> ${t}-nav, > div > ${t}-nav`]: {
                            order: 1,
                            marginTop: n,
                            marginBottom: 0,
                            "&::before": {
                                top: 0
                            },
                            [`${t}-ink-bar`]: {
                                top: 0
                            }
                        },
                        [`> ${t}-content-holder, > div > ${t}-content-holder`]: {
                            order: 0
                        }
                    },
                    [`${t}-left, ${t}-right`]: {
                        [`> ${t}-nav, > div > ${t}-nav`]: {
                            flexDirection: "column",
                            minWidth: l(e.controlHeight).mul(1.25).equal(),
                            [`${t}-tab`]: {
                                padding: o,
                                textAlign: "center"
                            },
                            [`${t}-tab + ${t}-tab`]: {
                                margin: r
                            },
                            [`${t}-nav-wrap`]: {
                                flexDirection: "column",
                                "&::before, &::after": {
                                    right: {
                                        _skip_check_: !0,
                                        value: 0
                                    },
                                    left: {
                                        _skip_check_: !0,
                                        value: 0
                                    },
                                    height: e.controlHeight
                                },
                                "&::before": {
                                    top: 0,
                                    boxShadow: e.boxShadowTabsOverflowTop
                                },
                                "&::after": {
                                    bottom: 0,
                                    boxShadow: e.boxShadowTabsOverflowBottom
                                },
                                [`&${t}-nav-wrap-ping-top::before`]: {
                                    opacity: 1
                                },
                                [`&${t}-nav-wrap-ping-bottom::after`]: {
                                    opacity: 1
                                }
                            },
                            [`${t}-ink-bar`]: {
                                width: e.lineWidthBold,
                                "&-animated": {
                                    transition: `height ${e.motionDurationSlow}, top ${e.motionDurationSlow}`
                                }
                            },
                            [`${t}-nav-list, ${t}-nav-operations`]: {
                                flex: "1 0 auto",
                                flexDirection: "column"
                            }
                        }
                    },
                    [`${t}-left`]: {
                        [`> ${t}-nav, > div > ${t}-nav`]: {
                            [`${t}-ink-bar`]: {
                                right: {
                                    _skip_check_: !0,
                                    value: 0
                                }
                            }
                        },
                        [`> ${t}-content-holder, > div > ${t}-content-holder`]: {
                            marginLeft: {
                                _skip_check_: !0,
                                value: (0, J.unit)(l(e.lineWidth).mul(-1).equal())
                            },
                            borderLeft: {
                                _skip_check_: !0,
                                value: `${(0,J.unit)(e.lineWidth)} ${e.lineType} ${e.colorBorder}`
                            },
                            [`> ${t}-content > ${t}-tabpane`]: {
                                paddingLeft: {
                                    _skip_check_: !0,
                                    value: e.paddingLG
                                }
                            }
                        }
                    },
                    [`${t}-right`]: {
                        [`> ${t}-nav, > div > ${t}-nav`]: {
                            order: 1,
                            [`${t}-ink-bar`]: {
                                left: {
                                    _skip_check_: !0,
                                    value: 0
                                }
                            }
                        },
                        [`> ${t}-content-holder, > div > ${t}-content-holder`]: {
                            order: 0,
                            marginRight: {
                                _skip_check_: !0,
                                value: l(e.lineWidth).mul(-1).equal()
                            },
                            borderRight: {
                                _skip_check_: !0,
                                value: `${(0,J.unit)(e.lineWidth)} ${e.lineType} ${e.colorBorder}`
                            },
                            [`> ${t}-content > ${t}-tabpane`]: {
                                paddingRight: {
                                    _skip_check_: !0,
                                    value: e.paddingLG
                                }
                            }
                        }
                    }
                }
            })(t), (e => {
                let {
                    componentCls: t,
                    itemHoverColor: n,
                    dropdownEdgeChildVerticalPadding: a
                } = e;
                return {
                    [`${t}-dropdown`]: { ...(0, Q.resetComponent)(e),
                        position: "absolute",
                        top: -9999,
                        left: {
                            _skip_check_: !0,
                            value: -9999
                        },
                        zIndex: e.zIndexPopup,
                        display: "block",
                        "&-hidden": {
                            display: "none"
                        },
                        [`${t}-dropdown-menu`]: {
                            maxHeight: e.tabsDropdownHeight,
                            margin: 0,
                            padding: `${(0,J.unit)(a)} 0`,
                            overflowX: "hidden",
                            overflowY: "auto",
                            textAlign: {
                                _skip_check_: !0,
                                value: "left"
                            },
                            listStyleType: "none",
                            backgroundColor: e.colorBgContainer,
                            backgroundClip: "padding-box",
                            borderRadius: e.borderRadiusLG,
                            outline: "none",
                            boxShadow: e.boxShadowSecondary,
                            "&-item": { ...Q.textEllipsis,
                                display: "flex",
                                alignItems: "center",
                                minWidth: e.tabsDropdownWidth,
                                margin: 0,
                                padding: `${(0,J.unit)(e.paddingXXS)} ${(0,J.unit)(e.paddingSM)}`,
                                color: e.colorText,
                                fontWeight: "normal",
                                fontSize: e.fontSize,
                                lineHeight: e.lineHeight,
                                cursor: "pointer",
                                transition: `all ${e.motionDurationSlow}`,
                                "> span": {
                                    flex: 1,
                                    whiteSpace: "nowrap"
                                },
                                "&-remove": {
                                    flex: "none",
                                    marginLeft: {
                                        _skip_check_: !0,
                                        value: e.marginSM
                                    },
                                    color: e.colorIcon,
                                    fontSize: e.fontSizeSM,
                                    background: "transparent",
                                    border: 0,
                                    cursor: "pointer",
                                    "&:hover": {
                                        color: n
                                    }
                                },
                                "&:hover": {
                                    background: e.controlItemBgHover
                                },
                                "&-disabled": {
                                    "&, &:hover": {
                                        color: e.colorTextDisabled,
                                        background: "transparent",
                                        cursor: "not-allowed"
                                    }
                                }
                            }
                        }
                    }
                }
            })(t), (e => {
                let {
                    componentCls: t,
                    tabsCardPadding: n,
                    cardBg: a,
                    cardGutter: i,
                    colorBorderSecondary: o,
                    itemSelectedColor: r
                } = e;
                return {
                    [`${t}-card`]: {
                        [`> ${t}-nav, > div > ${t}-nav`]: {
                            [`${t}-tab`]: {
                                margin: 0,
                                padding: n,
                                background: a,
                                border: `${(0,J.unit)(e.lineWidth)} ${e.lineType} ${o}`,
                                transition: `all ${e.motionDurationSlow} ${e.motionEaseInOut}`
                            },
                            [`${t}-tab-active`]: {
                                color: r,
                                background: e.colorBgContainer
                            },
                            [`${t}-tab-focus:has(${t}-tab-btn:focus-visible)`]: (0, Q.genFocusOutline)(e, -3),
                            [`& ${t}-tab${t}-tab-focus ${t}-tab-btn:focus-visible`]: {
                                outline: "none"
                            },
                            [`${t}-ink-bar`]: {
                                visibility: "hidden"
                            }
                        },
                        [`&${t}-top, &${t}-bottom`]: {
                            [`> ${t}-nav, > div > ${t}-nav`]: {
                                [`${t}-tab + ${t}-tab`]: {
                                    marginLeft: {
                                        _skip_check_: !0,
                                        value: (0, J.unit)(i)
                                    }
                                }
                            }
                        },
                        [`&${t}-top`]: {
                            [`> ${t}-nav, > div > ${t}-nav`]: {
                                [`${t}-tab`]: {
                                    borderRadius: `${(0,J.unit)(e.borderRadiusLG)} ${(0,J.unit)(e.borderRadiusLG)} 0 0`
                                },
                                [`${t}-tab-active`]: {
                                    borderBottomColor: e.colorBgContainer
                                }
                            }
                        },
                        [`&${t}-bottom`]: {
                            [`> ${t}-nav, > div > ${t}-nav`]: {
                                [`${t}-tab`]: {
                                    borderRadius: `0 0 ${(0,J.unit)(e.borderRadiusLG)} ${(0,J.unit)(e.borderRadiusLG)}`
                                },
                                [`${t}-tab-active`]: {
                                    borderTopColor: e.colorBgContainer
                                }
                            }
                        },
                        [`&${t}-left, &${t}-right`]: {
                            [`> ${t}-nav, > div > ${t}-nav`]: {
                                [`${t}-tab + ${t}-tab`]: {
                                    marginTop: (0, J.unit)(i)
                                }
                            }
                        },
                        [`&${t}-left`]: {
                            [`> ${t}-nav, > div > ${t}-nav`]: {
                                [`${t}-tab`]: {
                                    borderRadius: {
                                        _skip_check_: !0,
                                        value: `${(0,J.unit)(e.borderRadiusLG)} 0 0 ${(0,J.unit)(e.borderRadiusLG)}`
                                    }
                                },
                                [`${t}-tab-active`]: {
                                    borderRightColor: {
                                        _skip_check_: !0,
                                        value: e.colorBgContainer
                                    }
                                }
                            }
                        },
                        [`&${t}-right`]: {
                            [`> ${t}-nav, > div > ${t}-nav`]: {
                                [`${t}-tab`]: {
                                    borderRadius: {
                                        _skip_check_: !0,
                                        value: `0 ${(0,J.unit)(e.borderRadiusLG)} ${(0,J.unit)(e.borderRadiusLG)} 0`
                                    }
                                },
                                [`${t}-tab-active`]: {
                                    borderLeftColor: {
                                        _skip_check_: !0,
                                        value: e.colorBgContainer
                                    }
                                }
                            }
                        }
                    }
                }
            })(t), (e => {
                let {
                    componentCls: t,
                    tabsCardPadding: n,
                    cardHeight: a,
                    cardGutter: i,
                    itemHoverColor: o,
                    itemActiveColor: r,
                    colorBorderSecondary: l
                } = e;
                return {
                    [t]: { ...(0, Q.resetComponent)(e),
                        display: "flex",
                        [`> ${t}-nav, > div > ${t}-nav`]: {
                            position: "relative",
                            display: "flex",
                            flex: "none",
                            alignItems: "center",
                            [`${t}-nav-wrap`]: {
                                position: "relative",
                                display: "flex",
                                flex: "auto",
                                alignSelf: "stretch",
                                overflow: "hidden",
                                whiteSpace: "nowrap",
                                transform: "translate(0)",
                                "&::before, &::after": {
                                    position: "absolute",
                                    zIndex: 1,
                                    opacity: 0,
                                    transition: `opacity ${e.motionDurationSlow}`,
                                    content: "''",
                                    pointerEvents: "none"
                                }
                            },
                            [`${t}-nav-list`]: {
                                position: "relative",
                                display: "flex",
                                transition: `opacity ${e.motionDurationSlow}`
                            },
                            [`${t}-nav-operations`]: {
                                display: "flex",
                                alignSelf: "stretch"
                            },
                            [`${t}-nav-operations-hidden`]: {
                                position: "absolute",
                                visibility: "hidden",
                                pointerEvents: "none"
                            },
                            [`${t}-nav-more`]: {
                                position: "relative",
                                padding: n,
                                background: "transparent",
                                border: 0,
                                color: e.colorText,
                                "&::after": {
                                    position: "absolute",
                                    right: {
                                        _skip_check_: !0,
                                        value: 0
                                    },
                                    bottom: 0,
                                    left: {
                                        _skip_check_: !0,
                                        value: 0
                                    },
                                    height: e.calc(e.controlHeightLG).div(8).equal(),
                                    transform: "translateY(100%)",
                                    content: "''"
                                }
                            },
                            [`${t}-nav-add`]: {
                                minWidth: a,
                                minHeight: a,
                                marginLeft: {
                                    _skip_check_: !0,
                                    value: i
                                },
                                background: "transparent",
                                border: `${(0,J.unit)(e.lineWidth)} ${e.lineType} ${l}`,
                                borderRadius: `${(0,J.unit)(e.borderRadiusLG)} ${(0,J.unit)(e.borderRadiusLG)} 0 0`,
                                outline: "none",
                                cursor: "pointer",
                                color: e.colorText,
                                transition: `all ${e.motionDurationSlow} ${e.motionEaseInOut}`,
                                "&:hover": {
                                    color: o
                                },
                                "&:active, &:focus:not(:focus-visible)": {
                                    color: r
                                },
                                ...(0, Q.genFocusStyle)(e, -3)
                            }
                        },
                        [`${t}-extra-content`]: {
                            flex: "none"
                        },
                        [`${t}-ink-bar`]: {
                            position: "absolute",
                            background: e.inkBarColor,
                            pointerEvents: "none"
                        },
                        ...(e => {
                            let {
                                componentCls: t,
                                itemActiveColor: n,
                                itemHoverColor: a,
                                iconCls: i,
                                tabsHorizontalItemMargin: o,
                                horizontalItemPadding: r,
                                itemSelectedColor: l,
                                itemColor: d
                            } = e, s = `${t}-tab`;
                            return {
                                [s]: {
                                    position: "relative",
                                    WebkitTouchCallout: "none",
                                    WebkitTapHighlightColor: "transparent",
                                    display: "inline-flex",
                                    alignItems: "center",
                                    padding: r,
                                    fontSize: e.titleFontSize,
                                    background: "transparent",
                                    border: 0,
                                    outline: "none",
                                    cursor: "pointer",
                                    color: d,
                                    "&-btn, &-remove": {
                                        "&:focus:not(:focus-visible), &:active": {
                                            color: n
                                        }
                                    },
                                    "&-btn": {
                                        outline: "none",
                                        transition: `all ${e.motionDurationSlow}`,
                                        [`${s}-icon:not(:last-child)`]: {
                                            marginInlineEnd: e.marginSM
                                        }
                                    },
                                    "&-remove": {
                                        flex: "none",
                                        lineHeight: 1,
                                        marginRight: {
                                            _skip_check_: !0,
                                            value: e.calc(e.marginXXS).mul(-1).equal()
                                        },
                                        marginLeft: {
                                            _skip_check_: !0,
                                            value: e.marginXS
                                        },
                                        color: e.colorIcon,
                                        fontSize: e.fontSizeSM,
                                        background: "transparent",
                                        border: "none",
                                        outline: "none",
                                        cursor: "pointer",
                                        transition: `all ${e.motionDurationSlow}`,
                                        "&:hover": {
                                            color: e.colorTextHeading
                                        },
                                        ...(0, Q.genFocusStyle)(e)
                                    },
                                    "&:hover": {
                                        color: a
                                    },
                                    [`&${s}-active ${s}-btn`]: {
                                        color: l
                                    },
                                    [`&${s}-focus ${s}-btn:focus-visible`]: (0, Q.genFocusOutline)(e),
                                    [`&${s}-disabled`]: {
                                        color: e.colorTextDisabled,
                                        cursor: "not-allowed"
                                    },
                                    [`&${s}-disabled ${s}-btn, &${s}-disabled ${t}-remove`]: {
                                        "&:focus, &:active": {
                                            color: e.colorTextDisabled
                                        }
                                    },
                                    [`& ${s}-remove ${i}`]: {
                                        margin: 0,
                                        verticalAlign: "middle"
                                    },
                                    [`${i}:not(:last-child)`]: {
                                        marginRight: {
                                            _skip_check_: !0,
                                            value: e.marginSM
                                        }
                                    }
                                },
                                [`${s} + ${s}`]: {
                                    margin: {
                                        _skip_check_: !0,
                                        value: o
                                    }
                                }
                            }
                        })(e),
                        [`${t}-content`]: {
                            position: "relative",
                            width: "100%"
                        },
                        [`${t}-content-holder`]: {
                            flex: "auto",
                            minWidth: 0,
                            minHeight: 0
                        },
                        [`${t}-tabpane`]: { ...(0, Q.genFocusStyle)(e),
                            "&-hidden": {
                                display: "none"
                            }
                        }
                    },
                    [`${t}-centered`]: {
                        [`> ${t}-nav, > div > ${t}-nav`]: {
                            [`${t}-nav-wrap`]: {
                                [`&:not([class*='${t}-nav-wrap-ping']) > ${t}-nav-list`]: {
                                    margin: "auto"
                                }
                            }
                        }
                    }
                }
            })(t), (e => {
                let {
                    componentCls: t,
                    motionDurationSlow: n
                } = e;
                return [{
                        [t]: {
                            [`${t}-switch`]: {
                                "&-appear, &-enter": {
                                    transition: "none",
                                    "&-start": {
                                        opacity: 0
                                    },
                                    "&-active": {
                                        opacity: 1,
                                        transition: `opacity ${n}`
                                    }
                                },
                                "&-leave": {
                                    position: "absolute",
                                    transition: "none",
                                    inset: 0,
                                    "&-start": {
                                        opacity: 1
                                    },
                                    "&-active": {
                                        opacity: 0,
                                        transition: `opacity ${n}`
                                    }
                                }
                            }
                        }
                    },
                    [(0, et.initSlideMotion)(e, "slide-up"), (0, et.initSlideMotion)(e, "slide-down")]
                ]
            })(t)]
        }, e => {
            let {
                cardHeight: t,
                cardHeightSM: n,
                cardHeightLG: a,
                controlHeight: i,
                controlHeightLG: o
            } = e, r = t || o, l = n || i, d = a || o + 8;
            return {
                zIndexPopup: e.zIndexPopupBase + 50,
                cardBg: e.colorFillAlter,
                cardHeight: r,
                cardHeightSM: l,
                cardHeightLG: d,
                cardPadding: `${(r-e.fontHeight)/2-e.lineWidth}px ${e.padding}px`,
                cardPaddingSM: `${(l-e.fontHeight)/2-e.lineWidth}px ${e.paddingXS}px`,
                cardPaddingLG: `${(d-e.fontHeightLG)/2-e.lineWidth}px ${e.padding}px`,
                titleFontSize: e.fontSize,
                titleFontSizeLG: e.fontSizeLG,
                titleFontSizeSM: e.fontSize,
                inkBarColor: e.colorPrimary,
                horizontalMargin: `0 0 ${e.margin}px 0`,
                horizontalItemGutter: 32,
                horizontalItemMargin: "",
                horizontalItemMarginRTL: "",
                horizontalItemPadding: `${e.paddingSM}px 0`,
                horizontalItemPaddingSM: `${e.paddingXS}px 0`,
                horizontalItemPaddingLG: `${e.padding}px 0`,
                verticalItemPadding: `${e.paddingXS}px ${e.paddingLG}px`,
                verticalItemMargin: `${e.margin}px 0 0 0`,
                itemColor: e.colorText,
                itemSelectedColor: e.colorPrimary,
                itemHoverColor: e.colorPrimaryHover,
                itemActiveColor: e.colorPrimaryActive,
                cardGutter: e.marginXXS / 2
            }
        }),
        ea = n.forwardRef((e, t) => {
            var l, d;
            let s, {
                    type: c,
                    className: u,
                    rootClassName: p,
                    size: f,
                    onEdit: b,
                    hideAdd: m,
                    centered: h,
                    addIcon: $,
                    removeIcon: v,
                    moreIcon: g,
                    more: k,
                    popupClassName: y,
                    children: x,
                    items: _,
                    animated: w,
                    style: S,
                    indicatorSize: E,
                    indicator: R,
                    classNames: C,
                    styles: M,
                    destroyInactiveTabPane: L,
                    destroyOnHidden: I,
                    tabPlacement: P,
                    tabPosition: T,
                    ...D
                } = e,
                {
                    prefixCls: z
                } = D,
                {
                    getPrefixCls: N,
                    direction: B,
                    getPopupContainer: H,
                    className: O,
                    style: A,
                    classNames: W,
                    styles: G
                } = (0, F.useComponentConfig)("tabs"),
                {
                    tabs: J
                } = n.useContext(F.ConfigContext),
                Q = N("tabs", z),
                Z = (0, K.default)(Q),
                [ee, et] = en(Q, Z),
                ea = n.useRef(null);
            n.useImperativeHandle(t, () => ({
                nativeElement: ea.current
            })), "editable-card" === c && (s = {
                onEdit: (e, t) => {
                    let {
                        key: n,
                        event: a
                    } = t;
                    b ? .("add" === e ? a : n, e)
                },
                removeIcon: v ? ? J ? .removeIcon ? ? n.createElement(a.default, null),
                addIcon: ($ ? ? J ? .addIcon) || n.createElement(o.default, null),
                showAdd: !0 !== m
            });
            let ei = N(),
                eo = (0, q.default)(f),
                er = (l = _, d = x, l ? l.map(e => ({ ...e,
                    destroyOnHidden: e.destroyOnHidden ? ? e.destroyInactiveTabPane
                })) : (0, Y.toArray)(d).map(e => {
                    if (n.isValidElement(e)) {
                        let {
                            key: t,
                            props: n
                        } = e, {
                            tab: a,
                            ...i
                        } = n || {};
                        return {
                            key: String(t),
                            ...i,
                            label: a
                        }
                    }
                    return null
                }).filter(e => e)),
                el = function(e) {
                    let t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                        inkBar: !0,
                        tabPane: !1
                    };
                    return (t = !1 === n ? {
                        inkBar: !1,
                        tabPane: !1
                    } : !0 === n ? {
                        inkBar: !0,
                        tabPane: !0
                    } : {
                        inkBar: !0,
                        ..."object" == typeof n ? n : {}
                    }).tabPane && (t.tabPaneMotion = { ...V,
                        motionName: (0, U.getTransitionName)(e, "switch")
                    }), t
                }(Q, w),
                ed = {
                    align: R ? .align ? ? J ? .indicator ? .align,
                    size: R ? .size ? ? E ? ? J ? .indicator ? .size ? ? J ? .indicatorSize
                },
                es = n.useMemo(() => {
                    let e = P ? ? T ? ? void 0,
                        t = "rtl" === B;
                    switch (e) {
                        case "start":
                            return t ? "right" : "left";
                        case "end":
                            return t ? "left" : "right";
                        default:
                            return e
                    }
                }, [P, T, B]),
                ec = { ...e,
                    size: eo,
                    tabPlacement: es,
                    items: er
                },
                [eu, ep] = (0, j.useMergeSemantic)([W, C], [G, M], {
                    props: ec
                }, {
                    popup: {
                        _default: "root"
                    }
                });
            return n.createElement(X, {
                ref: ea,
                direction: B,
                getPopupContainer: H,
                ...D,
                items: er,
                className: (0, r.clsx)({
                    [`${Q}-${eo}`]: eo,
                    [`${Q}-card`]: ["card", "editable-card"].includes(c),
                    [`${Q}-editable-card`]: "editable-card" === c,
                    [`${Q}-centered`]: h
                }, O, u, p, eu.root, ee, et, Z),
                classNames: { ...eu,
                    popup: (0, r.clsx)(y, ee, et, Z, eu.popup ? .root)
                },
                styles: ep,
                style: { ...ep.root,
                    ...A,
                    ...S
                },
                editable: s,
                more: {
                    icon: J ? .more ? .icon ? ? J ? .moreIcon ? ? g ? ? n.createElement(i.default, null),
                    transitionName: `${ei}-slide-up`,
                    ...k
                },
                prefixCls: Q,
                animated: el,
                indicator: ed,
                destroyOnHidden: I ? ? L,
                tabPosition: es
            })
        });
    ea.TabPane = () => null, e.s(["default", 0, ea], 721369)
}]);