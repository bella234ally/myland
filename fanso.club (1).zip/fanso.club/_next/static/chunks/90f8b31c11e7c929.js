(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 858405, t => {
    "use strict";
    var e = t.i(843476),
        l = t.i(603594),
        n = t.i(561405);

    function s(t) {
        let {
            files: s,
            index: i,
            handleSlide: a
        } = t;
        return (0, e.jsxs)("div", {
            className: n.default.slide_top,
            children: [(0, e.jsx)("span", {
                className: n.default.count,
                children: `${i+1} / ${s.length}`
            }), (0, e.jsxs)("span", {
                className: n.default.btn_grp,
                children: [(0, e.jsx)("button", {
                    "aria-label": "prev",
                    onClick: () => a("prev"),
                    type: "button",
                    children: (0, e.jsx)(l.LeftSvg, {})
                }), (0, e.jsx)("button", {
                    "aria-label": "next",
                    onClick: () => a("next"),
                    type: "button",
                    children: (0, e.jsx)(l.RightSvg, {})
                })]
            })]
        })
    }
    t.s(["default", () => s])
}, 483461, t => {
    t.n(t.i(858405))
}]);