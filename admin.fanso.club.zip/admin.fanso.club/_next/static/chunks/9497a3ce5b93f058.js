(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 233525, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "warnOnce", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e => {}
}, 818581, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(271645);

    function o(e, t) {
        let r = (0, n.useRef)(null),
            o = (0, n.useRef)(null);
        return (0, n.useCallback)(n => {
            if (null === n) {
                let e = r.current;
                e && (r.current = null, e());
                let t = o.current;
                t && (o.current = null, t())
            } else e && (r.current = u(e, n)), t && (o.current = u(t, n))
        }, [e, t])
    }

    function u(e, t) {
        if ("function" != typeof e) return e.current = t, () => {
            e.current = null
        }; {
            let r = e(t);
            return "function" == typeof r ? r : () => e(null)
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 998183, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        assign: function() {
            return l
        },
        searchParamsToUrlQuery: function() {
            return u
        },
        urlQueryToSearchParams: function() {
            return a
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function u(e) {
        let t = {};
        for (let [r, n] of e.entries()) {
            let e = t[r];
            void 0 === e ? t[r] = n : Array.isArray(e) ? e.push(n) : t[r] = [e, n]
        }
        return t
    }

    function i(e) {
        return "string" == typeof e ? e : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e ? "" : String(e)
    }

    function a(e) {
        let t = new URLSearchParams;
        for (let [r, n] of Object.entries(e))
            if (Array.isArray(n))
                for (let e of n) t.append(r, i(e));
            else t.set(r, i(n));
        return t
    }

    function l(e, ...t) {
        for (let r of t) {
            for (let t of r.keys()) e.delete(t);
            for (let [t, n] of r.entries()) e.append(t, n)
        }
        return e
    }
}, 195057, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        formatUrl: function() {
            return a
        },
        formatWithValidation: function() {
            return c
        },
        urlObjectKeys: function() {
            return l
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(190809)._(e.r(998183)),
        i = /https?|ftp|gopher|file/;

    function a(e) {
        let {
            auth: t,
            hostname: r
        } = e, n = e.protocol || "", o = e.pathname || "", a = e.hash || "", l = e.query || "", c = !1;
        t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? c = t + e.host : r && (c = t + (~r.indexOf(":") ? `[${r}]` : r), e.port && (c += ":" + e.port)), l && "object" == typeof l && (l = String(u.urlQueryToSearchParams(l)));
        let s = e.search || l && `?${l}` || "";
        return n && !n.endsWith(":") && (n += ":"), e.slashes || (!n || i.test(n)) && !1 !== c ? (c = "//" + (c || ""), o && "/" !== o[0] && (o = "/" + o)) : c || (c = ""), a && "#" !== a[0] && (a = "#" + a), s && "?" !== s[0] && (s = "?" + s), o = o.replace(/[?#]/g, encodeURIComponent), s = s.replace("#", "%23"), `${n}${c}${o}${s}${a}`
    }
    let l = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

    function c(e) {
        return a(e)
    }
}, 718967, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DecodeError: function() {
            return m
        },
        MiddlewareNotFoundError: function() {
            return _
        },
        MissingStaticPage: function() {
            return v
        },
        NormalizeError: function() {
            return b
        },
        PageNotFoundError: function() {
            return P
        },
        SP: function() {
            return y
        },
        ST: function() {
            return g
        },
        WEB_VITALS: function() {
            return u
        },
        execOnce: function() {
            return i
        },
        getDisplayName: function() {
            return f
        },
        getLocationOrigin: function() {
            return c
        },
        getURL: function() {
            return s
        },
        isAbsoluteUrl: function() {
            return l
        },
        isResSent: function() {
            return p
        },
        loadGetInitialProps: function() {
            return h
        },
        normalizeRepeatedSlashes: function() {
            return d
        },
        stringifyError: function() {
            return O
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

    function i(e) {
        let t, r = !1;
        return (...n) => (r || (r = !0, t = e(...n)), t)
    }
    let a = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
        l = e => a.test(e);

    function c() {
        let {
            protocol: e,
            hostname: t,
            port: r
        } = window.location;
        return `${e}//${t}${r?":"+r:""}`
    }

    function s() {
        let {
            href: e
        } = window.location, t = c();
        return e.substring(t.length)
    }

    function f(e) {
        return "string" == typeof e ? e : e.displayName || e.name || "Unknown"
    }

    function p(e) {
        return e.finished || e.headersSent
    }

    function d(e) {
        let t = e.split("?");
        return t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (t[1] ? `?${t.slice(1).join("?")}` : "")
    }
    async function h(e, t) {
        let r = t.res || t.ctx && t.ctx.res;
        if (!e.getInitialProps) return t.ctx && t.Component ? {
            pageProps: await h(t.Component, t.ctx)
        } : {};
        let n = await e.getInitialProps(t);
        if (r && p(r)) return n;
        if (!n) throw Object.defineProperty(Error(`"${f(e)}.getInitialProps()" should resolve to an object. But found "${n}" instead.`), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        return n
    }
    let y = "undefined" != typeof performance,
        g = y && ["mark", "measure", "getEntriesByName"].every(e => "function" == typeof performance[e]);
    class m extends Error {}
    class b extends Error {}
    class P extends Error {
        constructor(e) {
            super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = `Cannot find module for page: ${e}`
        }
    }
    class v extends Error {
        constructor(e, t) {
            super(), this.message = `Failed to load static file for page: ${e} ${t}`
        }
    }
    class _ extends Error {
        constructor() {
            super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
        }
    }

    function O(e) {
        return JSON.stringify({
            message: e.message,
            stack: e.stack
        })
    }
}, 573668, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(718967),
        o = e.r(652817);

    function u(e) {
        if (!(0, n.isAbsoluteUrl)(e)) return !0;
        try {
            let t = (0, n.getLocationOrigin)(),
                r = new URL(e, t);
            return r.origin === t && (0, o.hasBasePath)(r.pathname)
        } catch (e) {
            return !1
        }
    }
}, 284508, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e => {}
}, 522016, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return m
        },
        useLinkStatus: function() {
            return P
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(190809),
        i = e.r(843476),
        a = u._(e.r(271645)),
        l = e.r(195057),
        c = e.r(8372),
        s = e.r(818581),
        f = e.r(718967),
        p = e.r(405550);
    e.r(233525);
    let d = e.r(91949),
        h = e.r(573668),
        y = e.r(509396);

    function g(e) {
        return "string" == typeof e ? e : (0, l.formatUrl)(e)
    }

    function m(t) {
        var r;
        let n, o, u, [l, m] = (0, a.useOptimistic)(d.IDLE_LINK_STATUS),
            P = (0, a.useRef)(null),
            {
                href: v,
                as: _,
                children: O,
                prefetch: E = null,
                passHref: j,
                replace: S,
                shallow: T,
                scroll: C,
                onClick: R,
                onMouseEnter: N,
                onTouchStart: L,
                legacyBehavior: M = !1,
                onNavigate: w,
                ref: x,
                unstable_dynamicOnHover: A,
                ...U
            } = t;
        n = O, M && ("string" == typeof n || "number" == typeof n) && (n = (0, i.jsx)("a", {
            children: n
        }));
        let $ = a.default.useContext(c.AppRouterContext),
            I = !1 !== E,
            k = !1 !== E ? null === (r = E) || "auto" === r ? y.FetchStrategy.PPR : y.FetchStrategy.Full : y.FetchStrategy.PPR,
            {
                href: F,
                as: B
            } = a.default.useMemo(() => {
                let e = g(v);
                return {
                    href: e,
                    as: _ ? g(_) : e
                }
            }, [v, _]);
        if (M) {
            if (n ? .$$typeof === Symbol.for("react.lazy")) throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: !1,
                configurable: !0
            });
            o = a.default.Children.only(n)
        }
        let D = M ? o && "object" == typeof o && o.ref : x,
            K = a.default.useCallback(e => (null !== $ && (P.current = (0, d.mountLinkInstance)(e, F, $, k, I, m)), () => {
                P.current && ((0, d.unmountLinkForCurrentNavigation)(P.current), P.current = null), (0, d.unmountPrefetchableInstance)(e)
            }), [I, F, $, k, m]),
            z = {
                ref: (0, s.useMergedRef)(K, D),
                onClick(t) {
                    M || "function" != typeof R || R(t), M && o.props && "function" == typeof o.props.onClick && o.props.onClick(t), !$ || t.defaultPrevented || function(t, r, n, o, u, i, l) {
                        if ("undefined" != typeof window) {
                            let c, {
                                nodeName: s
                            } = t.currentTarget;
                            if ("A" === s.toUpperCase() && ((c = t.currentTarget.getAttribute("target")) && "_self" !== c || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which) || t.currentTarget.hasAttribute("download")) return;
                            if (!(0, h.isLocalURL)(r)) {
                                u && (t.preventDefault(), location.replace(r));
                                return
                            }
                            if (t.preventDefault(), l) {
                                let e = !1;
                                if (l({
                                        preventDefault: () => {
                                            e = !0
                                        }
                                    }), e) return
                            }
                            let {
                                dispatchNavigateAction: f
                            } = e.r(699781);
                            a.default.startTransition(() => {
                                f(n || r, u ? "replace" : "push", i ? ? !0, o.current)
                            })
                        }
                    }(t, F, B, P, S, C, w)
                },
                onMouseEnter(e) {
                    M || "function" != typeof N || N(e), M && o.props && "function" == typeof o.props.onMouseEnter && o.props.onMouseEnter(e), $ && I && (0, d.onNavigationIntent)(e.currentTarget, !0 === A)
                },
                onTouchStart: function(e) {
                    M || "function" != typeof L || L(e), M && o.props && "function" == typeof o.props.onTouchStart && o.props.onTouchStart(e), $ && I && (0, d.onNavigationIntent)(e.currentTarget, !0 === A)
                }
            };
        return (0, f.isAbsoluteUrl)(B) ? z.href = B : M && !j && ("a" !== o.type || "href" in o.props) || (z.href = (0, p.addBasePath)(B)), u = M ? a.default.cloneElement(o, z) : (0, i.jsx)("a", { ...U,
            ...z,
            children: n
        }), (0, i.jsx)(b.Provider, {
            value: l,
            children: u
        })
    }
    e.r(284508);
    let b = (0, a.createContext)(d.IDLE_LINK_STATUS),
        P = () => (0, a.useContext)(b);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);