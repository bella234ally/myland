(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, {
    otherChunks: ["static/chunks/cf31d3c0f8af3efb.js", "static/chunks/1305aa3aa2e74d43.js", "static/chunks/b056a15eec95302c.js", "static/chunks/1ea72d1be604ca55.js", "static/chunks/4a0898171cb5614f.js"],
    runtimeModuleIds: [494553]
}]), (() => {
    let e;
    if (!Array.isArray(globalThis.TURBOPACK)) return;
    let t = "/_next/",
        r = (self.TURBOPACK_CHUNK_SUFFIX ? ? document ? .currentScript ? .getAttribute ? .("src") ? .replace(/^(.*(?=\?)|^.*$)/, "")) || "",
        n = new WeakMap;

    function o(e, t) {
        this.m = e, this.e = t
    }
    let i = o.prototype,
        l = Object.prototype.hasOwnProperty,
        s = "undefined" != typeof Symbol && Symbol.toStringTag;

    function u(e, t, r) {
        l.call(e, t) || Object.defineProperty(e, t, r)
    }

    function a(e, t) {
        let r = e[t];
        return r || (r = c(t), e[t] = r), r
    }

    function c(e) {
        return {
            exports: {},
            error: void 0,
            id: e,
            namespaceObject: void 0
        }
    }

    function f(e, t) {
        u(e, "__esModule", {
            value: !0
        }), s && u(e, s, {
            value: "Module"
        });
        let r = 0;
        for (; r < t.length;) {
            let n = t[r++],
                o = t[r++];
            if ("number" == typeof o)
                if (0 === o) u(e, n, {
                    value: t[r++],
                    enumerable: !0,
                    writable: !1
                });
                else throw Error(`unexpected tag: ${o}`);
            else "function" == typeof t[r] ? u(e, n, {
                get: o,
                set: t[r++],
                enumerable: !0
            }) : u(e, n, {
                get: o,
                enumerable: !0
            })
        }
        Object.seal(e)
    }
    i.s = function(e, t) {
        let r, n;
        null != t ? n = (r = a(this.c, t)).exports : (r = this.m, n = this.e), r.namespaceObject = n, f(n, e)
    }, i.j = function(e, t) {
        var r, o;
        let i, s, u;
        null != t ? s = (i = a(this.c, t)).exports : (i = this.m, s = this.e);
        let c = (r = i, o = s, (u = n.get(r)) || (n.set(r, u = []), r.exports = r.namespaceObject = new Proxy(o, {
            get(e, t) {
                if (l.call(e, t) || "default" === t || "__esModule" === t) return Reflect.get(e, t);
                for (let e of u) {
                    let r = Reflect.get(e, t);
                    if (void 0 !== r) return r
                }
            },
            ownKeys(e) {
                let t = Reflect.ownKeys(e);
                for (let e of u)
                    for (let r of Reflect.ownKeys(e)) "default" === r || t.includes(r) || t.push(r);
                return t
            }
        })), u);
        "object" == typeof e && null !== e && c.push(e)
    }, i.v = function(e, t) {
        (null != t ? a(this.c, t) : this.m).exports = e
    }, i.n = function(e, t) {
        let r;
        (r = null != t ? a(this.c, t) : this.m).exports = r.namespaceObject = e
    };
    let p = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__,
        h = [null, p({}), p([]), p(p)];

    function d(e, t, r) {
        let n = [],
            o = -1;
        for (let t = e;
            ("object" == typeof t || "function" == typeof t) && !h.includes(t); t = p(t))
            for (let r of Object.getOwnPropertyNames(t)) n.push(r, function(e, t) {
                return () => e[t]
            }(e, r)), -1 === o && "default" === r && (o = n.length - 1);
        return r && o >= 0 || (o >= 0 ? n.splice(o, 1, 0, e) : n.push("default", 0, e)), f(t, n), t
    }

    function m(e) {
        let t = B(e, this.m);
        if (t.namespaceObject) return t.namespaceObject;
        let r = t.exports;
        return t.namespaceObject = d(r, "function" == typeof r ? function(...e) {
            return r.apply(this, e)
        } : Object.create(null), r && r.__esModule)
    }

    function b(e) {
        let t = e.indexOf("#"); - 1 !== t && (e = e.substring(0, t));
        let r = e.indexOf("?");
        return -1 !== r && (e = e.substring(0, r)), e
    }

    function y() {
        let e, t;
        return {
            promise: new Promise((r, n) => {
                t = n, e = r
            }),
            resolve: e,
            reject: t
        }
    }
    i.i = m, i.A = function(e) {
        return this.r(e)(m.bind(this))
    }, i.t = "function" == typeof require ? require : function() {
        throw Error("Unexpected use of runtime require")
    }, i.r = function(e) {
        return B(e, this.m).exports
    }, i.f = function(e) {
        function t(t) {
            if (t = b(t), l.call(e, t)) return e[t].module();
            let r = Error(`Cannot find module '${t}'`);
            throw r.code = "MODULE_NOT_FOUND", r
        }
        return t.keys = () => Object.keys(e), t.resolve = t => {
            if (t = b(t), l.call(e, t)) return e[t].id();
            let r = Error(`Cannot find module '${t}'`);
            throw r.code = "MODULE_NOT_FOUND", r
        }, t.import = async e => await t(e), t
    };
    let O = Symbol("turbopack queues"),
        g = Symbol("turbopack exports"),
        w = Symbol("turbopack error");

    function C(e) {
        e && 1 !== e.status && (e.status = 1, e.forEach(e => e.queueCount--), e.forEach(e => e.queueCount-- ? e.queueCount++ : e()))
    }
    i.a = function(e, t) {
        let r = this.m,
            n = t ? Object.assign([], {
                status: -1
            }) : void 0,
            o = new Set,
            {
                resolve: i,
                reject: l,
                promise: s
            } = y(),
            u = Object.assign(s, {
                [g]: r.exports,
                [O]: e => {
                    n && e(n), o.forEach(e), u.catch(() => {})
                }
            }),
            a = {
                get: () => u,
                set(e) {
                    e !== u && (u[g] = e)
                }
            };
        Object.defineProperty(r, "exports", a), Object.defineProperty(r, "namespaceObject", a), e(function(e) {
            let t = e.map(e => {
                    if (null !== e && "object" == typeof e) {
                        if (O in e) return e;
                        if (null != e && "object" == typeof e && "then" in e && "function" == typeof e.then) {
                            let t = Object.assign([], {
                                    status: 0
                                }),
                                r = {
                                    [g]: {},
                                    [O]: e => e(t)
                                };
                            return e.then(e => {
                                r[g] = e, C(t)
                            }, e => {
                                r[w] = e, C(t)
                            }), r
                        }
                    }
                    return {
                        [g]: e,
                        [O]: () => {}
                    }
                }),
                r = () => t.map(e => {
                    if (e[w]) throw e[w];
                    return e[g]
                }),
                {
                    promise: i,
                    resolve: l
                } = y(),
                s = Object.assign(() => l(r), {
                    queueCount: 0
                });

            function u(e) {
                e !== n && !o.has(e) && (o.add(e), e && 0 === e.status && (s.queueCount++, e.push(s)))
            }
            return t.map(e => e[O](u)), s.queueCount ? i : r()
        }, function(e) {
            e ? l(u[w] = e) : i(u[g]), C(n)
        }), n && -1 === n.status && (n.status = 0)
    };
    let U = function(e) {
        let t = new URL(e, "x:/"),
            r = {};
        for (let e in t) r[e] = t[e];
        for (let t in r.href = e, r.pathname = e.replace(/[?#].*/, ""), r.origin = r.protocol = "", r.toString = r.toJSON = (...t) => e, r) Object.defineProperty(this, t, {
            enumerable: !0,
            configurable: !0,
            value: r[t]
        })
    };

    function j(e, t) {
        throw Error(`Invariant: ${t(e)}`)
    }
    U.prototype = URL.prototype, i.U = U, i.z = function(e) {
        throw Error("dynamic usage of require is not supported")
    }, i.g = globalThis;
    let R = o.prototype;
    var k, _ = ((k = _ || {})[k.Runtime = 0] = "Runtime", k[k.Parent = 1] = "Parent", k[k.Update = 2] = "Update", k);
    let v = new Map;
    i.M = v;
    let $ = new Map,
        P = new Map;
    async function S(e, t, r) {
        let n;
        if ("string" == typeof r) return E(e, t, K(r));
        let o = r.included || [],
            i = o.map(e => !!v.has(e) || $.get(e));
        if (i.length > 0 && i.every(e => e)) return void await Promise.all(i);
        let l = r.moduleChunks || [],
            s = l.map(e => P.get(e)).filter(e => e);
        if (s.length > 0) {
            if (s.length === l.length) return void await Promise.all(s);
            let r = new Set;
            for (let e of l) P.has(e) || r.add(e);
            for (let n of r) {
                let r = E(e, t, K(n));
                P.set(n, r), s.push(r)
            }
            n = Promise.all(s)
        } else {
            for (let o of (n = E(e, t, K(r.path)), l)) P.has(o) || P.set(o, n)
        }
        for (let e of o) $.has(e) || $.set(e, n);
        await n
    }
    R.l = function(e) {
        return S(1, this.m.id, e)
    };
    let T = Promise.resolve(void 0),
        A = new WeakMap;

    function E(t, r, n) {
        let o = e.loadChunkCached(t, n),
            i = A.get(o);
        if (void 0 === i) {
            let e = A.set.bind(A, o, T);
            i = o.then(e).catch(e => {
                let o;
                switch (t) {
                    case 0:
                        o = `as a runtime dependency of chunk ${r}`;
                        break;
                    case 1:
                        o = `from module ${r}`;
                        break;
                    case 2:
                        o = "from an HMR update";
                        break;
                    default:
                        j(t, e => `Unknown source type: ${e}`)
                }
                let i = Error(`Failed to load chunk ${n} ${o}${e?`: ${e}`:""}`, e ? {
                    cause: e
                } : void 0);
                throw i.name = "ChunkLoadError", i
            }), A.set(o, i)
        }
        return i
    }

    function K(e) {
        return `${t}${e.split("/").map(e=>encodeURIComponent(e)).join("/")}${r}`
    }
    R.L = function(e) {
        return E(1, this.m.id, e)
    }, R.R = function(e) {
        let t = this.r(e);
        return t ? .default ? ? t
    }, R.P = function(e) {
        return `/ROOT/${e??""}`
    }, R.b = function(e) {
        let t = new Blob([`self.TURBOPACK_WORKER_LOCATION = ${JSON.stringify(location.origin)};
self.TURBOPACK_CHUNK_SUFFIX = ${JSON.stringify(r)};
self.TURBOPACK_NEXT_CHUNK_URLS = ${JSON.stringify(e.reverse().map(K),null,2)};
importScripts(...self.TURBOPACK_NEXT_CHUNK_URLS.map(c => self.TURBOPACK_WORKER_LOCATION + c).reverse());`], {
            type: "text/javascript"
        });
        return URL.createObjectURL(t)
    };
    let x = /\.js(?:\?[^#]*)?(?:#.*)?$/,
        N = /\.css(?:\?[^#]*)?(?:#.*)?$/;

    function M(e) {
        return N.test(e)
    }
    i.w = function(t, r, n) {
        return e.loadWebAssembly(1, this.m.id, t, r, n)
    }, i.u = function(t, r) {
        return e.loadWebAssemblyModule(1, this.m.id, t, r)
    };
    let L = {};
    i.c = L;
    let B = (e, t) => {
        let r = L[e];
        if (r) {
            if (r.error) throw r.error;
            return r
        }
        return q(e, _.Parent, t.id)
    };

    function q(e, t, r) {
        let n = v.get(e);
        if ("function" != typeof n) throw Error(function(e, t, r) {
            let n;
            switch (t) {
                case 0:
                    n = `as a runtime entry of chunk ${r}`;
                    break;
                case 1:
                    n = `because it was required from module ${r}`;
                    break;
                case 2:
                    n = "because of an HMR update";
                    break;
                default:
                    j(t, e => `Unknown source type: ${e}`)
            }
            return `Module ${e} was instantiated ${n}, but the module factory is not available.`
        }(e, t, r));
        let i = c(e),
            l = i.exports;
        L[e] = i;
        let s = new o(i, l);
        try {
            n(s, i, l)
        } catch (e) {
            throw i.error = e, e
        }
        return i.namespaceObject && i.exports !== i.namespaceObject && d(i.exports, i.namespaceObject), i
    }

    function I(r) {
        let n, o = function(e) {
            if ("string" == typeof e) return e;
            let r = decodeURIComponent(("undefined" != typeof TURBOPACK_NEXT_CHUNK_URLS ? TURBOPACK_NEXT_CHUNK_URLS.pop() : e.getAttribute("src")).replace(/[?#].*$/, ""));
            return r.startsWith(t) ? r.slice(t.length) : r
        }(r[0]);
        return 2 === r.length ? n = r[1] : (n = void 0, ! function(e, t, r, n) {
            let o = 1;
            for (; o < e.length;) {
                let t = e[o],
                    n = o + 1;
                for (; n < e.length && "function" != typeof e[n];) n++;
                if (n === e.length) throw Error("malformed chunk format, expected a factory function");
                if (!r.has(t)) {
                    let i = e[n];
                    for (Object.defineProperty(i, "name", {
                            value: "module evaluation"
                        }); o < n; o++) t = e[o], r.set(t, i)
                }
                o = n + 1
            }
        }(r, 0, v)), e.registerChunk(o, n)
    }
    let W = new Map;

    function H(e) {
        let t = W.get(e);
        if (!t) {
            let r, n;
            t = {
                resolved: !1,
                loadingStarted: !1,
                promise: new Promise((e, t) => {
                    r = e, n = t
                }),
                resolve: () => {
                    t.resolved = !0, r()
                },
                reject: n
            }, W.set(e, t)
        }
        return t
    }
    e = {
        async registerChunk(e, t) {
            if (H(K(e)).resolve(), null != t) {
                for (let e of t.otherChunks) H(K("string" == typeof e ? e : e.path));
                if (await Promise.all(t.otherChunks.map(t => S(0, e, t))), t.runtimeModuleIds.length > 0)
                    for (let r of t.runtimeModuleIds) ! function(e, t) {
                        let r = L[t];
                        if (r) {
                            if (r.error) throw r.error;
                            return
                        }
                        q(t, _.Runtime, e)
                    }(e, r)
            }
        },
        loadChunkCached: (e, t) => (function(e, t) {
            let r = H(t);
            if (r.loadingStarted) return r.promise;
            if (e === _.Runtime) return r.loadingStarted = !0, M(t) && r.resolve(), r.promise;
            if ("function" == typeof importScripts)
                if (M(t));
                else if (x.test(t)) self.TURBOPACK_NEXT_CHUNK_URLS.push(t), importScripts(TURBOPACK_WORKER_LOCATION + t);
            else throw Error(`can't infer type of chunk from URL ${t} in worker`);
            else {
                let e = decodeURI(t);
                if (M(t))
                    if (document.querySelectorAll(`link[rel=stylesheet][href="${t}"],link[rel=stylesheet][href^="${t}?"],link[rel=stylesheet][href="${e}"],link[rel=stylesheet][href^="${e}?"]`).length > 0) r.resolve();
                    else {
                        let e = document.createElement("link");
                        e.rel = "stylesheet", e.href = t, e.onerror = () => {
                            r.reject()
                        }, e.onload = () => {
                            r.resolve()
                        }, document.head.appendChild(e)
                    }
                else if (x.test(t)) {
                    let n = document.querySelectorAll(`script[src="${t}"],script[src^="${t}?"],script[src="${e}"],script[src^="${e}?"]`);
                    if (n.length > 0)
                        for (let e of Array.from(n)) e.addEventListener("error", () => {
                            r.reject()
                        });
                    else {
                        let e = document.createElement("script");
                        e.src = t, e.onerror = () => {
                            r.reject()
                        }, document.head.appendChild(e)
                    }
                } else throw Error(`can't infer type of chunk from URL ${t}`)
            }
            return r.loadingStarted = !0, r.promise
        })(e, t),
        async loadWebAssembly(e, t, r, n, o) {
            let i = fetch(K(r)),
                {
                    instance: l
                } = await WebAssembly.instantiateStreaming(i, o);
            return l.exports
        },
        async loadWebAssemblyModule(e, t, r, n) {
            let o = fetch(K(r));
            return await WebAssembly.compileStreaming(o)
        }
    };
    let F = globalThis.TURBOPACK;
    globalThis.TURBOPACK = {
        push: I
    }, F.forEach(I)
})();