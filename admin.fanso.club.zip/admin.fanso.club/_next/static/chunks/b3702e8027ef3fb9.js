(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 213381, 260698, 965044, 704079, 950211, 33578, e => {
    "use strict";
    e.i(247167);
    var t = e.i(207670),
        n = e.i(452410),
        l = e.i(440383),
        r = e.i(987225),
        i = e.i(118696),
        u = e.i(24308),
        o = e.i(271645),
        s = e.i(174080);
    let a = o.createContext(null);

    function c(e) {
        var t;
        return t = o.useContext(a), `${t}-${e}`
    }
    var f = e.i(178749);
    let d = o.createContext(null);

    function p({
        children: e,
        locked: t,
        ...n
    }) {
        let l = o.useContext(d),
            r = (0, f.default)(() => {
                let e;
                return e = { ...l
                }, Object.keys(n).forEach(t => {
                    let l = n[t];
                    void 0 !== l && (e[t] = l)
                }), e
            }, [l, n], (e, n) => !t && (e[0] !== n[0] || !(0, i.default)(e[1], n[1], !0)));
        return o.createElement(d.Provider, {
            value: r
        }, e)
    }
    let m = o.createContext(null);

    function v() {
        return o.useContext(m)
    }
    let b = o.createContext([]);

    function h(e) {
        let t = o.useContext(b);
        return o.useMemo(() => void 0 !== e ? [...t, e] : t, [t, e])
    }
    let g = o.createContext(null);
    e.s(["PathRegisterContext", 0, m, "PathTrackerContext", 0, b, "PathUserContext", 0, g, "useFullPath", () => h, "useMeasure", () => v], 260698);
    let y = o.createContext({});
    var E = e.i(563611),
        C = e.i(830731),
        x = e.i(737434);
    let {
        LEFT: R,
        RIGHT: w,
        UP: $,
        DOWN: k,
        ENTER: N,
        ESC: P,
        HOME: S,
        END: I
    } = C.default, M = [$, k, R, w];

    function T(e, t) {
        return (0, E.getFocusNodeList)(e, !0).filter(e => t.has(e))
    }

    function O(e, t, n, l = 1) {
        if (!e) return null;
        let r = T(e, t),
            i = r.length,
            u = r.findIndex(e => n === e);
        return l < 0 ? -1 === u ? u = i - 1 : u -= 1 : l > 0 && (u += 1), r[u = (u + i) % i]
    }
    let j = (e, t) => {
            let n = new Set,
                l = new Map,
                r = new Map;
            return e.forEach(e => {
                let i = document.querySelector(`[data-menu-id='${t}-${e}']`);
                i && (n.add(i), r.set(i, e), l.set(e, i))
            }), {
                elements: n,
                key2element: l,
                element2key: r
            }
        },
        A = "__RC_UTIL_PATH_SPLIT__",
        L = "rc-menu-more";

    function z(e) {
        let t = o.useRef(e);
        t.current = e;
        let n = o.useCallback((...e) => t.current ? .(...e), []);
        return e ? n : void 0
    }
    var K = e.i(180573),
        D = e.i(232839),
        V = o;

    function B(e, t, n, l) {
        let {
            activeKey: r,
            onActive: i,
            onInactive: u
        } = o.useContext(d), s = {
            active: r === e
        };
        return t || (s.onMouseEnter = t => {
            n ? .({
                key: e,
                domEvent: t
            }), i(e)
        }, s.onMouseLeave = t => {
            l ? .({
                key: e,
                domEvent: t
            }), u(e)
        }), s
    }

    function _(e) {
        let {
            mode: t,
            rtl: n,
            inlineIndent: l
        } = o.useContext(d);
        return "inline" !== t ? null : n ? {
            paddingRight: e * l
        } : {
            paddingLeft: e * l
        }
    }

    function F({
        icon: e,
        props: t,
        children: n
    }) {
        let l;
        return null === e || !1 === e ? null : ("function" == typeof e ? l = o.createElement(e, { ...t
        }) : "boolean" != typeof e && (l = e), l || n || null)
    }

    function U({
        item: e,
        ...t
    }) {
        return Object.defineProperty(t, "item", {
            get: () => ((0, u.default)(!1, "`info.item` is deprecated since we will move to function component that not provides React Node instance in future."), e)
        }), t
    }

    function q() {
        return (q = Object.assign.bind()).apply(this, arguments)
    }
    class H extends V.Component {
        render() {
            let {
                title: e,
                attribute: t,
                elementRef: l,
                ...r
            } = this.props, i = (0, K.default)(r, ["eventKey", "popupClassName", "popupOffset", "onTitleClick"]);
            return (0, u.default)(!t, "`attribute` of Menu.Item is deprecated. Please pass attribute directly."), V.createElement(n.default.Item, q({}, t, {
                title: "string" == typeof e ? e : void 0
            }, i, {
                ref: l
            }))
        }
    }
    let W = V.forwardRef((e, n) => {
            let {
                style: l,
                className: r,
                eventKey: i,
                warnKey: u,
                disabled: o,
                itemIcon: s,
                children: a,
                role: f,
                onMouseEnter: p,
                onMouseLeave: m,
                onClick: v,
                onKeyDown: b,
                onFocus: g,
                ...E
            } = e, x = c(i), {
                prefixCls: R,
                onItemClick: w,
                disabled: $,
                overflowDisabled: k,
                itemIcon: N,
                selectedKeys: P,
                onActive: S
            } = V.useContext(d), {
                _internalRenderMenuItem: I
            } = V.useContext(y), M = `${R}-item`, T = V.useRef(), O = V.useRef(), j = $ || o, A = (0, D.useComposeRef)(n, O), L = h(i), z = e => ({
                key: i,
                keyPath: [...L].reverse(),
                item: T.current,
                domEvent: e
            }), {
                active: W,
                ...G
            } = B(i, j, p, m), X = P.includes(i), Y = _(L.length), J = {};
            "option" === e.role && (J["aria-selected"] = X);
            let Q = V.createElement(H, q({
                ref: T,
                elementRef: A,
                role: null === f ? "none" : f || "menuitem",
                tabIndex: o ? null : -1,
                "data-menu-id": k && x ? null : x
            }, (0, K.default)(E, ["extra"]), G, J, {
                component: "li",
                "aria-disabled": o,
                style: { ...Y,
                    ...l
                },
                className: (0, t.clsx)(M, {
                    [`${M}-active`]: W,
                    [`${M}-selected`]: X,
                    [`${M}-disabled`]: j
                }, r),
                onClick: e => {
                    if (j) return;
                    let t = z(e);
                    v ? .(U(t)), w(t)
                },
                onKeyDown: e => {
                    if (b ? .(e), e.which === C.default.ENTER) {
                        let t = z(e);
                        v ? .(U(t)), w(t)
                    }
                },
                onFocus: e => {
                    S(i), g ? .(e)
                }
            }), a, V.createElement(F, {
                props: { ...e,
                    isSelected: X
                },
                icon: s || N
            }));
            return I && (Q = I(Q, e, {
                selected: X
            })), Q
        }),
        G = V.forwardRef(function(e, t) {
            let {
                eventKey: n
            } = e, l = v(), r = h(n);
            return (V.useEffect(() => {
                if (l) return l.registerPath(n, r), () => {
                    l.unregisterPath(n, r)
                }
            }, [r]), l) ? null : V.createElement(W, q({}, e, {
                ref: t
            }))
        });

    function X() {
        return (X = Object.assign.bind()).apply(this, arguments)
    }
    e.s(["default", 0, G], 965044);
    let Y = o.forwardRef(({
        className: e,
        children: n,
        ...l
    }, r) => {
        let {
            prefixCls: i,
            mode: u,
            rtl: s
        } = o.useContext(d);
        return o.createElement("ul", X({
            className: (0, t.clsx)(i, s && `${i}-rtl`, `${i}-sub`, `${i}-${"inline"===u?"inline":"vertical"}`, e),
            role: "menu"
        }, l, {
            "data-menu-list": !0,
            ref: r
        }), n)
    });
    var J = e.i(167007);

    function Q(e, t) {
        return (0, J.default)(e).map((e, n) => {
            if (o.isValidElement(e)) {
                let {
                    key: l
                } = e, r = e.props ? .eventKey ? ? l;
                null == r && (r = `tmp_key-${[...t,n].join("-")}`);
                let i = {
                    key: r,
                    eventKey: r
                };
                return o.cloneElement(e, i)
            }
            return e
        })
    }
    var Z = e.i(649637);
    let ee = {
            adjustX: 1,
            adjustY: 1
        },
        et = {
            topLeft: {
                points: ["bl", "tl"],
                overflow: ee
            },
            topRight: {
                points: ["br", "tr"],
                overflow: ee
            },
            bottomLeft: {
                points: ["tl", "bl"],
                overflow: ee
            },
            bottomRight: {
                points: ["tr", "br"],
                overflow: ee
            },
            leftTop: {
                points: ["tr", "tl"],
                overflow: ee
            },
            leftBottom: {
                points: ["br", "bl"],
                overflow: ee
            },
            rightTop: {
                points: ["tl", "tr"],
                overflow: ee
            },
            rightBottom: {
                points: ["bl", "br"],
                overflow: ee
            }
        },
        en = {
            topLeft: {
                points: ["bl", "tl"],
                overflow: ee
            },
            topRight: {
                points: ["br", "tr"],
                overflow: ee
            },
            bottomLeft: {
                points: ["tl", "bl"],
                overflow: ee
            },
            bottomRight: {
                points: ["tr", "br"],
                overflow: ee
            },
            rightTop: {
                points: ["tr", "tl"],
                overflow: ee
            },
            rightBottom: {
                points: ["br", "bl"],
                overflow: ee
            },
            leftTop: {
                points: ["tl", "tr"],
                overflow: ee
            },
            leftBottom: {
                points: ["bl", "br"],
                overflow: ee
            }
        };

    function el(e, t, n) {
        return t || (n ? n[e] || n.other : void 0)
    }
    let er = {
        horizontal: "bottomLeft",
        vertical: "rightTop",
        "vertical-left": "rightTop",
        "vertical-right": "leftTop"
    };

    function ei({
        prefixCls: e,
        visible: n,
        children: l,
        popup: r,
        popupStyle: i,
        popupClassName: u,
        popupOffset: s,
        disabled: a,
        mode: c,
        onVisibleChange: f
    }) {
        let {
            getPopupContainer: p,
            rtl: m,
            subMenuOpenDelay: v,
            subMenuCloseDelay: b,
            builtinPlacements: h,
            triggerSubMenuAction: g,
            forceSubMenuRender: y,
            rootClassName: E,
            motion: C,
            defaultMotions: R
        } = o.useContext(d), [w, $] = o.useState(!1), k = m ? { ...en,
            ...h
        } : { ...et,
            ...h
        }, N = er[c], P = el(c, C, R), S = o.useRef(P);
        "inline" !== c && (S.current = P);
        let I = { ...S.current,
                leavedClassName: `${e}-hidden`,
                removeOnLeave: !1,
                motionAppear: !0
            },
            M = o.useRef();
        return o.useEffect(() => (M.current = (0, x.default)(() => {
            $(n)
        }), () => {
            x.default.cancel(M.current)
        }), [n]), o.createElement(Z.default, {
            prefixCls: e,
            popupClassName: (0, t.clsx)(`${e}-popup`, {
                [`${e}-rtl`]: m
            }, u, E),
            stretch: "horizontal" === c ? "minWidth" : null,
            getPopupContainer: p,
            builtinPlacements: k,
            popupPlacement: N,
            popupVisible: w,
            popup: r,
            popupStyle: i,
            popupAlign: s && {
                offset: s
            },
            action: a ? [] : [g],
            mouseEnterDelay: v,
            mouseLeaveDelay: b,
            onPopupVisibleChange: f,
            forceRender: y,
            popupMotion: I,
            fresh: !0
        }, l)
    }
    var eu = e.i(128473);

    function eo() {
        return (eo = Object.assign.bind()).apply(this, arguments)
    }

    function es({
        id: e,
        open: t,
        keyPath: n,
        children: l
    }) {
        let r = "inline",
            {
                prefixCls: i,
                forceSubMenuRender: u,
                motion: s,
                defaultMotions: a,
                mode: c
            } = o.useContext(d),
            f = o.useRef(!1);
        f.current = c === r;
        let [m, v] = o.useState(!f.current), b = !!f.current && t;
        o.useEffect(() => {
            f.current && v(!1)
        }, [c]);
        let h = { ...el(r, s, a)
        };
        n.length > 1 && (h.motionAppear = !1);
        let g = h.onVisibleChanged;
        return (h.onVisibleChanged = e => (f.current || e || v(!0), g ? .(e)), m) ? null : o.createElement(p, {
            mode: r,
            locked: !f.current
        }, o.createElement(eu.default, eo({
            visible: b
        }, h, {
            forceRender: u,
            removeOnLeave: !1,
            leavedClassName: `${i}-hidden`
        }), ({
            className: t,
            style: n
        }) => o.createElement(Y, {
            id: e,
            className: t,
            style: n
        }, l)))
    }

    function ea() {
        return (ea = Object.assign.bind()).apply(this, arguments)
    }
    let ec = o.forwardRef((e, l) => {
            let {
                style: r,
                className: i,
                styles: u,
                classNames: s,
                title: a,
                eventKey: f,
                warnKey: m,
                disabled: v,
                internalPopupClose: b,
                children: E,
                itemIcon: C,
                expandIcon: x,
                popupClassName: R,
                popupOffset: w,
                popupStyle: $,
                onClick: k,
                onMouseEnter: N,
                onMouseLeave: P,
                onTitleClick: S,
                onTitleMouseEnter: I,
                onTitleMouseLeave: M,
                popupRender: T,
                ...O
            } = e, j = c(f), {
                prefixCls: A,
                mode: L,
                openKeys: K,
                disabled: D,
                overflowDisabled: V,
                activeKey: q,
                selectedKeys: H,
                itemIcon: W,
                expandIcon: G,
                onItemClick: X,
                onOpenChange: J,
                onActive: Q,
                popupRender: Z
            } = o.useContext(d), {
                _internalRenderSubMenuItem: ee
            } = o.useContext(y), {
                isSubPathKey: et
            } = o.useContext(g), en = h(), el = `${A}-submenu`, er = D || v, eu = o.useRef(), eo = o.useRef(), ec = x ? ? G, ef = K.includes(f), ed = !V && ef, ep = et(H, f), {
                active: em,
                ...ev
            } = B(f, er, I, M), [eb, eh] = o.useState(!1), eg = e => {
                er || eh(e)
            }, ey = o.useMemo(() => em || "inline" !== L && (eb || et([q], f)), [L, em, q, eb, f, et]), eE = _(en.length), eC = z(e => {
                k ? .(U(e)), X(e)
            }), ex = j && `${j}-popup`, eR = o.useMemo(() => o.createElement(F, {
                icon: "horizontal" !== L ? ec : void 0,
                props: { ...e,
                    isOpen: ed,
                    isSubMenu: !0
                }
            }, o.createElement("i", {
                className: `${el}-arrow`
            })), [L, ec, e, ed, el]), ew = o.createElement("div", ea({
                role: "menuitem",
                style: eE,
                className: `${el}-title`,
                tabIndex: er ? null : -1,
                ref: eu,
                title: "string" == typeof a ? a : null,
                "data-menu-id": V && j ? null : j,
                "aria-expanded": ed,
                "aria-haspopup": !0,
                "aria-controls": ex,
                "aria-disabled": er,
                onClick: e => {
                    er || (S ? .({
                        key: f,
                        domEvent: e
                    }), "inline" === L && J(f, !ef))
                },
                onFocus: () => {
                    Q(f)
                }
            }, ev), a, eR), e$ = o.useRef(L);
            "inline" !== L && en.length > 1 ? e$.current = "vertical" : e$.current = L;
            let ek = e$.current,
                eN = o.useMemo(() => {
                    let t = o.createElement(p, {
                            classNames: s,
                            styles: u,
                            mode: "horizontal" === ek ? "vertical" : ek
                        }, o.createElement(Y, {
                            id: ex,
                            ref: eo
                        }, E)),
                        n = T || Z;
                    return n ? n(t, {
                        item: e,
                        keys: en
                    }) : t
                }, [T, Z, en, ex, E, e, ek]);
            if (!V) {
                let e = e$.current;
                ew = o.createElement(ei, {
                    mode: e,
                    prefixCls: el,
                    visible: !b && ed && "inline" !== L,
                    popupClassName: R,
                    popupOffset: w,
                    popupStyle: $,
                    popup: eN,
                    disabled: er,
                    onVisibleChange: e => {
                        "inline" !== L && J(f, e)
                    }
                }, ew)
            }
            let eP = o.createElement(n.default.Item, ea({
                ref: l,
                role: "none"
            }, O, {
                component: "li",
                style: r,
                className: (0, t.clsx)(el, `${el}-${L}`, i, {
                    [`${el}-open`]: ed,
                    [`${el}-active`]: ey,
                    [`${el}-selected`]: ep,
                    [`${el}-disabled`]: er
                }),
                onMouseEnter: e => {
                    eg(!0), N ? .({
                        key: f,
                        domEvent: e
                    })
                },
                onMouseLeave: e => {
                    eg(!1), P ? .({
                        key: f,
                        domEvent: e
                    })
                }
            }), ew, !V && o.createElement(es, {
                id: ex,
                open: ed,
                keyPath: en
            }, E));
            return ee && (eP = ee(eP, e, {
                selected: ep,
                active: ey,
                open: ed,
                disabled: er
            })), o.createElement(p, {
                classNames: s,
                styles: u,
                onItemClick: eC,
                mode: "horizontal" === L ? "vertical" : L,
                itemIcon: C ? ? W,
                expandIcon: ec
            }, eP)
        }),
        ef = o.forwardRef((e, t) => {
            let n, {
                    eventKey: l,
                    children: r
                } = e,
                i = h(l),
                u = Q(r, i),
                s = v();
            return o.useEffect(() => {
                if (s) return s.registerPath(l, i), () => {
                    s.unregisterPath(l, i)
                }
            }, [i]), n = s ? u : o.createElement(ec, ea({
                ref: t
            }, e), u), o.createElement(b.Provider, {
                value: i
            }, n)
        });

    function ed({
        className: e,
        style: n
    }) {
        let {
            prefixCls: l
        } = o.useContext(d);
        return v() ? null : o.createElement("li", {
            role: "separator",
            className: (0, t.clsx)(`${l}-item-divider`, e),
            style: n
        })
    }

    function ep() {
        return (ep = Object.assign.bind()).apply(this, arguments)
    }
    e.s(["default", 0, ef], 704079), e.s(["default", () => ed], 950211);
    let em = o.forwardRef((e, n) => {
            let {
                className: l,
                title: r,
                eventKey: i,
                children: u,
                ...s
            } = e, {
                prefixCls: a,
                classNames: c,
                styles: f
            } = o.useContext(d), p = `${a}-item-group`;
            return o.createElement("li", ep({
                ref: n,
                role: "presentation"
            }, s, {
                onClick: e => e.stopPropagation(),
                className: (0, t.clsx)(p, l)
            }), o.createElement("div", {
                role: "presentation",
                className: (0, t.clsx)(`${p}-title`, c ? .listTitle),
                style: f ? .listTitle,
                title: "string" == typeof r ? r : void 0
            }, r), o.createElement("ul", {
                role: "group",
                className: (0, t.clsx)(`${p}-list`, c ? .list),
                style: f ? .list
            }, u))
        }),
        ev = o.forwardRef((e, t) => {
            let {
                eventKey: n,
                children: l
            } = e, r = Q(l, h(n));
            return v() ? r : o.createElement(em, ep({
                ref: t
            }, (0, K.default)(e, ["warnKey"])), r)
        });

    function eb() {
        return (eb = Object.assign.bind()).apply(this, arguments)
    }

    function eh(e, t, n, l, r) {
        let i = e,
            u = {
                divider: ed,
                item: G,
                group: ev,
                submenu: ef,
                ...l
            };
        return t && (i = function e(t, n, l) {
            let {
                item: r,
                group: i,
                submenu: u,
                divider: s
            } = n;
            return (t || []).map((t, a) => {
                if (t && "object" == typeof t) {
                    let {
                        label: c,
                        children: f,
                        key: d,
                        type: p,
                        extra: m,
                        ...v
                    } = t, b = d ? ? `tmp-${a}`;
                    return f || "group" === p ? "group" === p ? o.createElement(i, eb({
                        key: b
                    }, v, {
                        title: c
                    }), e(f, n, l)) : o.createElement(u, eb({
                        key: b
                    }, v, {
                        title: c
                    }), e(f, n, l)) : "divider" === p ? o.createElement(s, eb({
                        key: b
                    }, v)) : o.createElement(r, eb({
                        key: b
                    }, v, {
                        extra: m
                    }), c, (!!m || 0 === m) && o.createElement("span", {
                        className: `${l}-item-extra`
                    }, m))
                }
                return null
            }).filter(e => e)
        }(t, u, r)), Q(i, n)
    }

    function eg() {
        return (eg = Object.assign.bind()).apply(this, arguments)
    }
    e.s(["default", 0, ev], 33578);
    let ey = [],
        eE = o.forwardRef((e, u) => {
            var c;
            let f, d, v, {
                    prefixCls: b = "rc-menu",
                    rootClassName: h,
                    style: E,
                    className: C,
                    styles: K,
                    classNames: D,
                    tabIndex: V = 0,
                    items: B,
                    children: _,
                    direction: F,
                    id: q,
                    mode: H = "vertical",
                    inlineCollapsed: W,
                    disabled: X,
                    disabledOverflow: Y,
                    subMenuOpenDelay: J = .1,
                    subMenuCloseDelay: Q = .1,
                    forceSubMenuRender: Z,
                    defaultOpenKeys: ee,
                    openKeys: et,
                    activeKey: en,
                    defaultActiveFirst: el,
                    selectable: er = !0,
                    multiple: ei = !1,
                    defaultSelectedKeys: eu,
                    selectedKeys: eo,
                    onSelect: es,
                    onDeselect: ea,
                    inlineIndent: ec = 24,
                    motion: ed,
                    defaultMotions: ep,
                    triggerSubMenuAction: em = "hover",
                    builtinPlacements: ev,
                    itemIcon: eb,
                    expandIcon: eE,
                    overflowedIndicator: eC = "...",
                    overflowedIndicatorPopupClassName: ex,
                    getPopupContainer: eR,
                    onClick: ew,
                    onOpenChange: e$,
                    onKeyDown: ek,
                    openAnimation: eN,
                    openTransitionName: eP,
                    _internalRenderMenuItem: eS,
                    _internalRenderSubMenuItem: eI,
                    _internalComponents: eM,
                    popupRender: eT,
                    ...eO
                } = e,
                [ej, eA] = o.useMemo(() => [eh(_, B, ey, eM, b), eh(_, B, ey, {}, b)], [_, B, eM]),
                [eL, ez] = o.useState(!1),
                eK = o.useRef(),
                eD = (0, r.default)(q ? `rc-menu-uuid-${q}` : "rc-menu-uuid"),
                eV = "rtl" === F,
                [eB, e_] = (0, l.default)(ee, et),
                eF = eB || ey,
                eU = (e, t = !1) => {
                    function n() {
                        e_(e), e$ ? .(e)
                    }
                    t ? (0, s.flushSync)(n) : n()
                },
                [eq, eH] = o.useState(eF),
                eW = o.useRef(!1),
                [eG, eX] = o.useMemo(() => ("inline" === H || "vertical" === H) && W ? ["vertical", W] : [H, !1], [H, W]),
                eY = "inline" === eG,
                [eJ, eQ] = o.useState(eG),
                [eZ, e0] = o.useState(eX);
            o.useEffect(() => {
                eQ(eG), e0(eX), eW.current && (eY ? e_(eq) : eU(ey))
            }, [eG, eX]);
            let [e1, e6] = o.useState(0), e5 = e1 >= ej.length - 1 || "horizontal" !== eJ || Y;
            o.useEffect(() => {
                eY && eH(eF)
            }, [eF]), o.useEffect(() => (eW.current = !0, () => {
                eW.current = !1
            }), []);
            let {
                registerPath: e2,
                unregisterPath: e7,
                refreshOverflowKeys: e3,
                isSubPathKey: e4,
                getKeyPath: e8,
                getKeys: e9,
                getSubPathKeys: te
            } = function() {
                let [, e] = o.useState({}), t = (0, o.useRef)(new Map), n = (0, o.useRef)(new Map), [l, r] = o.useState([]), i = (0, o.useRef)(0), u = (0, o.useRef)(!1), s = (0, o.useCallback)((l, r) => {
                    let o = r.join(A);
                    n.current.set(o, l), t.current.set(l, o), i.current += 1;
                    let s = i.current;
                    Promise.resolve().then(() => {
                        s === i.current && (u.current || e({}))
                    })
                }, []), a = (0, o.useCallback)((e, l) => {
                    let r = l.join(A);
                    n.current.delete(r), t.current.delete(e)
                }, []), c = (0, o.useCallback)(e => {
                    r(e)
                }, []), f = (0, o.useCallback)((e, n) => {
                    let r = (t.current.get(e) || "").split(A);
                    return n && l.includes(r[0]) && r.unshift(L), r
                }, [l]), d = (0, o.useCallback)((e, t) => e.filter(e => void 0 !== e).some(e => f(e, !0).includes(t)), [f]), p = (0, o.useCallback)(e => {
                    let l = `${t.current.get(e)}${A}`,
                        r = new Set;
                    return [...n.current.keys()].forEach(e => {
                        e.startsWith(l) && r.add(n.current.get(e))
                    }), r
                }, []);
                return o.useEffect(() => () => {
                    u.current = !0
                }, []), {
                    registerPath: s,
                    unregisterPath: a,
                    refreshOverflowKeys: c,
                    isSubPathKey: d,
                    getKeyPath: f,
                    getKeys: () => {
                        let e = [...t.current.keys()];
                        return l.length && e.push(L), e
                    },
                    getSubPathKeys: p
                }
            }(), tt = o.useMemo(() => ({
                registerPath: e2,
                unregisterPath: e7
            }), [e2, e7]), tn = o.useMemo(() => ({
                isSubPathKey: e4
            }), [e4]);
            o.useEffect(() => {
                e3(e5 ? ey : ej.slice(e1 + 1).map(e => e.key))
            }, [e1, e5]);
            let [tl, tr] = (0, l.default)(en || el && ej[0] ? .key, en), ti = z(e => {
                tr(e)
            }), tu = z(() => {
                tr(void 0)
            });
            (0, o.useImperativeHandle)(u, () => ({
                list: eK.current,
                focus: e => {
                    let t, n = e9(),
                        {
                            elements: l,
                            key2element: r,
                            element2key: i
                        } = j(n, eD),
                        u = T(eK.current, l);
                    t = tl && n.includes(tl) ? tl : u[0] ? i.get(u[0]) : ej.find(e => !e.props.disabled) ? .key;
                    let o = r.get(t);
                    t && o && o ? .focus ? .(e)
                },
                findItem: ({
                    key: e
                }) => {
                    let {
                        key2element: t
                    } = j(e9(), eD);
                    return t.get(e) || null
                }
            }));
            let [to, ts] = (0, l.default)(eu || [], eo), ta = o.useMemo(() => Array.isArray(to) ? to : null == to ? ey : [to], [to]), tc = z(e => {
                ew ? .(U(e)), (e => {
                    if (er) {
                        let t, {
                                key: n
                            } = e,
                            l = ta.includes(n);
                        ts(t = ei ? l ? ta.filter(e => e !== n) : [...ta, n] : [n]);
                        let r = { ...e,
                            selectedKeys: t
                        };
                        l ? ea ? .(r) : es ? .(r)
                    }!ei && eF.length && "inline" !== eJ && eU(ey)
                })(e)
            }), tf = z((e, t) => {
                let n = eF.filter(t => t !== e);
                if (t) n.push(e);
                else if ("inline" !== eJ) {
                    let t = te(e);
                    n = n.filter(e => !t.has(e))
                }(0, i.default)(eF, n, !0) || eU(n, !0)
            }), td = (c = (e, t) => {
                let n = t ? ? !eF.includes(e);
                tf(e, n)
            }, f = o.useRef(), (d = o.useRef()).current = tl, v = () => {
                x.default.cancel(f.current)
            }, o.useEffect(() => () => {
                v()
            }, []), e => {
                let {
                    which: t
                } = e;
                if ([...M, N, P, S, I].includes(t)) {
                    let n = e9(),
                        l = j(n, eD),
                        {
                            elements: r,
                            key2element: i,
                            element2key: u
                        } = l,
                        o = function(e, t) {
                            let n = e || document.activeElement;
                            for (; n;) {
                                if (t.has(n)) return n;
                                n = n.parentElement
                            }
                            return null
                        }(i.get(tl), r),
                        s = u.get(o),
                        a = function(e, t, n, l) {
                            let r = "prev",
                                i = "next",
                                u = "children",
                                o = "parent";
                            if ("inline" === e && l === N) return {
                                inlineTrigger: !0
                            };
                            let s = {
                                    [$]: r,
                                    [k]: i
                                },
                                a = {
                                    [$]: r,
                                    [k]: i,
                                    [N]: u,
                                    [P]: o,
                                    [R]: n ? u : o,
                                    [w]: n ? o : u
                                };
                            switch (({
                                inline: s,
                                horizontal: {
                                    [R]: n ? i : r,
                                    [w]: n ? r : i,
                                    [k]: u,
                                    [N]: u
                                },
                                vertical: a,
                                inlineSub: s,
                                horizontalSub: a,
                                verticalSub: a
                            })[`${e}${t?"":"Sub"}`] ? .[l]) {
                                case r:
                                    return {
                                        offset: -1,
                                        sibling: !0
                                    };
                                case i:
                                    return {
                                        offset: 1,
                                        sibling: !0
                                    };
                                case o:
                                    return {
                                        offset: -1,
                                        sibling: !1
                                    };
                                case u:
                                    return {
                                        offset: 1,
                                        sibling: !1
                                    };
                                default:
                                    return null
                            }
                        }(eJ, 1 === e8(s, !0).length, eV, t);
                    if (!a && t !== S && t !== I) return;
                    (M.includes(t) || [S, I].includes(t)) && e.preventDefault();
                    let p = e => {
                        if (e) {
                            let t = e,
                                n = e.querySelector("a");
                            n ? .getAttribute("href") && (t = n);
                            let l = u.get(e);
                            tr(l), v(), f.current = (0, x.default)(() => {
                                d.current === l && t.focus()
                            })
                        }
                    };
                    if ([S, I].includes(t) || a.sibling || !o) {
                        let e, n = T(e = o && "inline" !== eJ ? function(e) {
                            let t = e;
                            for (; t;) {
                                if (t.getAttribute("data-menu-list")) return t;
                                t = t.parentElement
                            }
                            return null
                        }(o) : eK.current, r);
                        p(t === S ? n[0] : t === I ? n[n.length - 1] : O(e, r, o, a.offset))
                    } else if (a.inlineTrigger) c(s);
                    else if (a.offset > 0) c(s, !0), v(), f.current = (0, x.default)(() => {
                        l = j(n, eD);
                        let e = o.getAttribute("aria-controls");
                        p(O(document.getElementById(e), l.elements))
                    }, 5);
                    else if (a.offset < 0) {
                        let e = e8(s, !0),
                            t = e[e.length - 2],
                            n = i.get(t);
                        c(t, !1), p(n)
                    }
                }
                ek ? .(e)
            });
            o.useEffect(() => {
                ez(!0)
            }, []);
            let tp = o.useMemo(() => ({
                    _internalRenderMenuItem: eS,
                    _internalRenderSubMenuItem: eI
                }), [eS, eI]),
                tm = "horizontal" !== eJ || Y ? ej : ej.map((e, t) => o.createElement(p, {
                    key: e.key,
                    overflowDisabled: t > e1,
                    classNames: D,
                    styles: K
                }, e)),
                tv = o.createElement(n.default, eg({
                    id: q,
                    ref: eK,
                    prefixCls: `${b}-overflow`,
                    component: "ul",
                    itemComponent: G,
                    className: (0, t.clsx)(b, `${b}-root`, `${b}-${eJ}`, C, {
                        [`${b}-inline-collapsed`]: eZ,
                        [`${b}-rtl`]: eV
                    }, h),
                    dir: F,
                    style: E,
                    role: "menu",
                    tabIndex: V,
                    data: tm,
                    renderRawItem: e => e,
                    renderRawRest: e => {
                        let t = e.length,
                            n = t ? ej.slice(-t) : null;
                        return o.createElement(ef, {
                            eventKey: L,
                            title: eC,
                            disabled: e5,
                            internalPopupClose: 0 === t,
                            popupClassName: ex
                        }, n)
                    },
                    maxCount: "horizontal" !== eJ || Y ? n.default.INVALIDATE : n.default.RESPONSIVE,
                    ssr: "full",
                    "data-menu-list": !0,
                    onVisibleChange: e => {
                        e6(e)
                    },
                    onKeyDown: td
                }, eO));
            return o.createElement(y.Provider, {
                value: tp
            }, o.createElement(a.Provider, {
                value: eD
            }, o.createElement(p, {
                prefixCls: b,
                rootClassName: h,
                classNames: D,
                styles: K,
                mode: eJ,
                openKeys: eF,
                rtl: eV,
                disabled: X,
                motion: eL ? ed : null,
                defaultMotions: eL ? ep : null,
                activeKey: tl,
                onActive: ti,
                onInactive: tu,
                selectedKeys: ta,
                inlineIndent: ec,
                subMenuOpenDelay: J,
                subMenuCloseDelay: Q,
                forceSubMenuRender: Z,
                builtinPlacements: ev,
                triggerSubMenuAction: em,
                getPopupContainer: eR,
                itemIcon: eb,
                expandIcon: eE,
                onItemClick: tc,
                onOpenChange: tf,
                popupRender: eT
            }, o.createElement(g.Provider, {
                value: tn
            }, tv), o.createElement("div", {
                style: {
                    display: "none"
                },
                "aria-hidden": !0
            }, o.createElement(m.Provider, {
                value: tt
            }, eA)))))
        });
    eE.Item = G, eE.SubMenu = ef, eE.ItemGroup = ev, eE.Divider = ed, e.s(["default", 0, eE], 213381)
}, 539563, e => {
    "use strict";
    e.i(247167);
    var t = e.i(271645);
    let n = {
        icon: {
            tag: "svg",
            attrs: {
                viewBox: "64 64 896 896",
                focusable: "false"
            },
            children: [{
                tag: "path",
                attrs: {
                    d: "M176 511a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0z"
                }
            }]
        },
        name: "ellipsis",
        theme: "outlined"
    };
    var l = e.i(406575);

    function r() {
        return (r = Object.assign.bind()).apply(this, arguments)
    }
    let i = t.forwardRef((e, i) => t.createElement(l.default, r({}, e, {
        ref: i,
        icon: n
    })));
    e.s(["default", 0, i], 539563)
}]);