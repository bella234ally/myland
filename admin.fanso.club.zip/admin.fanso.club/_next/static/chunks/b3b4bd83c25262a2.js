(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 756135, 641755, 422499, 297590, e => {
    "use strict";
    e.i(247167);
    var t = e.i(271645),
        r = e.i(440383),
        l = e.i(940487),
        a = e.i(118696),
        n = e.i(24308),
        o = e.i(207670),
        u = e.i(174080);

    function i(e, t, r, l) {
        let a = (t - r) / (l - r),
            n = {};
        switch (e) {
            case "rtl":
                n.right = `${100*a}%`, n.transform = "translateX(50%)";
                break;
            case "btt":
                n.bottom = `${100*a}%`, n.transform = "translateY(50%)";
                break;
            case "ttb":
                n.top = `${100*a}%`, n.transform = "translateY(-50%)";
                break;
            default:
                n.left = `${100*a}%`, n.transform = "translateX(-50%)"
        }
        return n
    }

    function s(e, t) {
        return Array.isArray(e) ? e[t] : e
    }
    var c = e.i(830731);
    let d = t.createContext({
            min: 0,
            max: 0,
            direction: "ltr",
            step: 1,
            includedStart: 0,
            includedEnd: 0,
            tabIndex: 0,
            keyboard: !0,
            styles: {},
            classNames: {}
        }),
        f = t.createContext({});

    function m() {
        return (m = Object.assign.bind()).apply(this, arguments)
    }
    e.s(["UnstableContext", 0, f, "default", 0, d], 641755);
    let g = t.forwardRef((e, r) => {
        let {
            prefixCls: l,
            value: a,
            valueIndex: n,
            onStartMove: u,
            onDelete: f,
            style: g,
            render: h,
            dragging: p,
            draggingDelete: b,
            onOffsetChange: v,
            onChangeComplete: k,
            onFocus: $,
            onMouseEnter: C,
            ...E
        } = e, {
            min: x,
            max: y,
            direction: S,
            disabled: M,
            keyboard: w,
            range: B,
            tabIndex: R,
            ariaLabelForHandle: D,
            ariaLabelledByForHandle: P,
            ariaRequired: H,
            ariaValueTextFormatterForHandle: N,
            styles: I,
            classNames: A
        } = t.useContext(d), q = `${l}-handle`, L = e => {
            M || u(e, n)
        }, T = i(S, a, x, y), F = {};
        null !== n && (F = {
            tabIndex: M ? null : s(R, n),
            role: "slider",
            "aria-valuemin": x,
            "aria-valuemax": y,
            "aria-valuenow": a,
            "aria-disabled": M,
            "aria-label": s(D, n),
            "aria-labelledby": s(P, n),
            "aria-required": s(H, n),
            "aria-valuetext": s(N, n) ? .(a),
            "aria-orientation": "ltr" === S || "rtl" === S ? "horizontal" : "vertical",
            onMouseDown: L,
            onTouchStart: L,
            onFocus: e => {
                $ ? .(e, n)
            },
            onMouseEnter: e => {
                C(e, n)
            },
            onKeyDown: e => {
                if (!M && w) {
                    let t = null;
                    switch (e.which || e.keyCode) {
                        case c.default.LEFT:
                            t = "ltr" === S || "btt" === S ? -1 : 1;
                            break;
                        case c.default.RIGHT:
                            t = "ltr" === S || "btt" === S ? 1 : -1;
                            break;
                        case c.default.UP:
                            t = "ttb" !== S ? 1 : -1;
                            break;
                        case c.default.DOWN:
                            t = "ttb" !== S ? -1 : 1;
                            break;
                        case c.default.HOME:
                            t = "min";
                            break;
                        case c.default.END:
                            t = "max";
                            break;
                        case c.default.PAGE_UP:
                            t = 2;
                            break;
                        case c.default.PAGE_DOWN:
                            t = -2;
                            break;
                        case c.default.BACKSPACE:
                        case c.default.DELETE:
                            f ? .(n)
                    }
                    null !== t && (e.preventDefault(), v(t, n))
                }
            },
            onKeyUp: e => {
                switch (e.which || e.keyCode) {
                    case c.default.LEFT:
                    case c.default.RIGHT:
                    case c.default.UP:
                    case c.default.DOWN:
                    case c.default.HOME:
                    case c.default.END:
                    case c.default.PAGE_UP:
                    case c.default.PAGE_DOWN:
                        k ? .()
                }
            }
        });
        let O = t.createElement("div", m({
            ref: r,
            className: (0, o.clsx)(q, {
                [`${q}-${n+1}`]: null !== n && B,
                [`${q}-dragging`]: p,
                [`${q}-dragging-delete`]: b
            }, A.handle),
            style: { ...T,
                ...g,
                ...I.handle
            }
        }, F, E));
        return h && (O = h(O, {
            index: n,
            prefixCls: l,
            value: a,
            dragging: p,
            draggingDelete: b
        })), O
    });

    function h() {
        return (h = Object.assign.bind()).apply(this, arguments)
    }
    let p = t.forwardRef((e, r) => {
            let {
                prefixCls: l,
                style: a,
                onStartMove: n,
                onOffsetChange: o,
                values: i,
                handleRender: c,
                activeHandleRender: d,
                draggingIndex: f,
                draggingDelete: m,
                onFocus: p,
                ...b
            } = e, v = t.useRef({}), [k, $] = t.useState(!1), [C, E] = t.useState(-1), x = e => {
                E(e), $(!0)
            };
            t.useImperativeHandle(r, () => ({
                focus: e => {
                    v.current[e] ? .focus()
                },
                hideHelp: () => {
                    (0, u.flushSync)(() => {
                        $(!1)
                    })
                }
            }));
            let y = {
                prefixCls: l,
                onStartMove: n,
                onOffsetChange: o,
                render: c,
                onFocus: (e, t) => {
                    x(t), p ? .(e)
                },
                onMouseEnter: (e, t) => {
                    x(t)
                },
                ...b
            };
            return t.createElement(t.Fragment, null, i.map((e, r) => {
                let l = f === r;
                return t.createElement(g, h({
                    ref: e => {
                        e ? v.current[r] = e : delete v.current[r]
                    },
                    dragging: l,
                    draggingDelete: l && m,
                    style: s(a, r),
                    key: r,
                    value: e,
                    valueIndex: r
                }, y))
            }), d && k && t.createElement(g, h({
                key: "a11y"
            }, y, {
                value: i[C],
                valueIndex: null,
                dragging: -1 !== f,
                draggingDelete: m,
                render: d,
                style: {
                    pointerEvents: "none"
                },
                tabIndex: null,
                "aria-hidden": !0
            })))
        }),
        b = e => {
            let {
                prefixCls: r,
                style: l,
                children: a,
                value: n,
                onClick: u
            } = e, {
                min: s,
                max: c,
                direction: f,
                includedStart: m,
                includedEnd: g,
                included: h
            } = t.useContext(d), p = `${r}-text`, b = i(f, n, s, c);
            return t.createElement("span", {
                className: (0, o.clsx)(p, {
                    [`${p}-active`]: h && m <= n && n <= g
                }),
                style: { ...b,
                    ...l
                },
                onMouseDown: e => {
                    e.stopPropagation()
                },
                onClick: () => {
                    u(n)
                }
            }, a)
        },
        v = e => {
            let {
                prefixCls: r,
                marks: l,
                onClick: a
            } = e, n = `${r}-mark`;
            return l.length ? t.createElement("div", {
                className: n
            }, l.map(({
                value: e,
                style: r,
                label: l
            }) => t.createElement(b, {
                key: e,
                prefixCls: n,
                style: r,
                value: e,
                onClick: a
            }, l))) : null
        },
        k = e => {
            let {
                prefixCls: r,
                value: l,
                style: a,
                activeStyle: n
            } = e, {
                min: u,
                max: s,
                direction: c,
                included: f,
                includedStart: m,
                includedEnd: g
            } = t.useContext(d), h = `${r}-dot`, p = f && m <= l && l <= g, b = { ...i(c, l, u, s),
                ..."function" == typeof a ? a(l) : a
            };
            return p && (b = { ...b,
                ..."function" == typeof n ? n(l) : n
            }), t.createElement("span", {
                className: (0, o.clsx)(h, {
                    [`${h}-active`]: p
                }),
                style: b
            })
        },
        $ = e => {
            let {
                prefixCls: r,
                marks: l,
                dots: a,
                style: n,
                activeStyle: o
            } = e, {
                min: u,
                max: i,
                step: s
            } = t.useContext(d), c = t.useMemo(() => {
                let e = new Set;
                if (l.forEach(t => {
                        e.add(t.value)
                    }), a && null !== s) {
                    let t = u;
                    for (; t <= i;) e.add(t), t += s
                }
                return Array.from(e)
            }, [u, i, s, a, l]);
            return t.createElement("div", {
                className: `${r}-step`
            }, c.map(e => t.createElement(k, {
                prefixCls: r,
                key: e,
                value: e,
                style: n,
                activeStyle: o
            })))
        },
        C = e => {
            let {
                prefixCls: r,
                style: l,
                start: a,
                end: n,
                index: u,
                onStartMove: i,
                replaceCls: s
            } = e, {
                direction: c,
                min: f,
                max: m,
                disabled: g,
                range: h,
                classNames: p
            } = t.useContext(d), b = `${r}-track`, v = (a - f) / (m - f), k = (n - f) / (m - f), $ = e => {
                !g && i && i(e, -1)
            }, C = {};
            switch (c) {
                case "rtl":
                    C.right = `${100*v}%`, C.width = `${100*k-100*v}%`;
                    break;
                case "btt":
                    C.bottom = `${100*v}%`, C.height = `${100*k-100*v}%`;
                    break;
                case "ttb":
                    C.top = `${100*v}%`, C.height = `${100*k-100*v}%`;
                    break;
                default:
                    C.left = `${100*v}%`, C.width = `${100*k-100*v}%`
            }
            let E = s || (0, o.clsx)(b, {
                [`${b}-${u+1}`]: null !== u && h,
                [`${r}-track-draggable`]: i
            }, p.track);
            return t.createElement("div", {
                className: E,
                style: { ...C,
                    ...l
                },
                onMouseDown: $,
                onTouchStart: $
            })
        },
        E = e => {
            let {
                prefixCls: r,
                style: l,
                values: a,
                startPoint: n,
                onStartMove: u
            } = e, {
                included: i,
                range: c,
                min: f,
                styles: m,
                classNames: g
            } = t.useContext(d), h = t.useMemo(() => {
                if (!c) {
                    if (0 === a.length) return [];
                    let e = n ? ? f,
                        t = a[0];
                    return [{
                        start: Math.min(e, t),
                        end: Math.max(e, t)
                    }]
                }
                let e = [];
                for (let t = 0; t < a.length - 1; t += 1) e.push({
                    start: a[t],
                    end: a[t + 1]
                });
                return e
            }, [a, c, n, f]);
            if (!i) return null;
            let p = h ? .length && (g.tracks || m.tracks) ? t.createElement(C, {
                index: null,
                prefixCls: r,
                start: h[0].start,
                end: h[h.length - 1].end,
                replaceCls: (0, o.clsx)(g.tracks, `${r}-tracks`),
                style: m.tracks
            }) : null;
            return t.createElement(t.Fragment, null, p, h.map(({
                start: e,
                end: a
            }, n) => t.createElement(C, {
                index: n,
                prefixCls: r,
                style: { ...s(l, n),
                    ...m.track
                },
                start: e,
                end: a,
                key: n,
                onStartMove: u
            })))
        };
    var x = e.i(401676);

    function y(e) {
        let t = "targetTouches" in e ? e.targetTouches[0] : e;
        return {
            pageX: t.pageX,
            pageY: t.pageY
        }
    }
    let S = function(e, r, a, n, o, u, i, s, c, d, m) {
            let [g, h] = t.useState(null), [p, b] = t.useState(-1), [v, k] = t.useState(!1), [$, C] = t.useState(a), [E, S] = t.useState(a), M = t.useRef(null), w = t.useRef(null), B = t.useRef(null), {
                onDragStart: R,
                onDragChange: D
            } = t.useContext(f);
            (0, x.default)(() => {
                -1 === p && C(a)
            }, [a, p]), t.useEffect(() => () => {
                document.removeEventListener("mousemove", M.current), document.removeEventListener("mouseup", w.current), B.current && (B.current.removeEventListener("touchmove", M.current), B.current.removeEventListener("touchend", w.current))
            }, []);
            let P = (e, t, r) => {
                    void 0 !== t && h(t), C(e);
                    let l = e;
                    r && (l = e.filter((e, t) => t !== p)), i(l), D && D({
                        rawValues: e,
                        deleteIndex: r ? p : -1,
                        draggingIndex: p,
                        draggingValue: t
                    })
                },
                H = (0, l.default)((e, t, r) => {
                    if (-1 === e) {
                        let e = E[0],
                            r = E[E.length - 1],
                            l = t * (o - n);
                        l = Math.min(l = Math.max(l, n - e), o - r), l = u(e + l) - e, P(E.map(e => e + l))
                    } else {
                        let l = [...$];
                        l[e] = E[e];
                        let a = c(l, (o - n) * t, e, "dist");
                        P(a.values, a.value, r)
                    }
                });
            return [p, g, v, t.useMemo(() => {
                let e = [...a].sort((e, t) => e - t),
                    t = [...$].sort((e, t) => e - t),
                    r = {};
                t.forEach(e => {
                    r[e] = (r[e] || 0) + 1
                }), e.forEach(e => {
                    r[e] = (r[e] || 0) - 1
                });
                let l = +!!d;
                return Object.values(r).reduce((e, t) => e + Math.abs(t), 0) <= l ? $ : a
            }, [a, $, d]), (t, l, n) => {
                t.stopPropagation();
                let o = n || a,
                    u = o[l];
                b(l), h(u), S(o), C(o), k(!1);
                let {
                    pageX: i,
                    pageY: c
                } = y(t), f = !1;
                R && R({
                    rawValues: o,
                    draggingIndex: l,
                    draggingValue: u
                });
                let g = t => {
                        let a, n;
                        t.preventDefault();
                        let {
                            pageX: o,
                            pageY: u
                        } = y(t), s = o - i, g = u - c, {
                            width: h,
                            height: p
                        } = e.current.getBoundingClientRect();
                        switch (r) {
                            case "btt":
                                a = -g / p, n = s;
                                break;
                            case "ttb":
                                a = g / p, n = s;
                                break;
                            case "rtl":
                                a = -s / h, n = g;
                                break;
                            default:
                                a = s / h, n = g
                        }
                        k(f = !!d && Math.abs(n) > 130 && m < $.length), H(l, a, f)
                    },
                    p = e => {
                        e.preventDefault(), document.removeEventListener("mouseup", p), document.removeEventListener("mousemove", g), B.current && (B.current.removeEventListener("touchmove", M.current), B.current.removeEventListener("touchend", w.current)), M.current = null, w.current = null, B.current = null, s(f), b(-1), k(!1)
                    };
                document.addEventListener("mouseup", p), document.addEventListener("mousemove", g), t.currentTarget.addEventListener("touchend", p), t.currentTarget.addEventListener("touchmove", g), M.current = g, w.current = p, B.current = t.currentTarget
            }]
        },
        M = t.forwardRef((e, u) => {
            let i, s, c, f, m, g, {
                    prefixCls: h = "rc-slider",
                    className: b,
                    style: k,
                    classNames: C,
                    styles: x,
                    id: y,
                    disabled: M = !1,
                    keyboard: w = !0,
                    autoFocus: B,
                    onFocus: R,
                    onBlur: D,
                    min: P = 0,
                    max: H = 100,
                    step: N = 1,
                    value: I,
                    defaultValue: A,
                    range: q,
                    count: L,
                    onChange: T,
                    onBeforeChange: F,
                    onAfterChange: O,
                    onChangeComplete: z,
                    allowCross: W = !0,
                    pushable: X = !1,
                    reverse: G,
                    vertical: U,
                    included: Y = !0,
                    startPoint: j,
                    trackStyle: K,
                    handleStyle: V,
                    railStyle: _,
                    dotStyle: J,
                    activeDotStyle: Q,
                    marks: Z,
                    dots: ee,
                    handleRender: et,
                    activeHandleRender: er,
                    track: el,
                    tabIndex: ea = 0,
                    ariaLabelForHandle: en,
                    ariaLabelledByForHandle: eo,
                    ariaRequired: eu,
                    ariaValueTextFormatterForHandle: ei
                } = e,
                es = t.useRef(null),
                ec = t.useRef(null),
                ed = t.useMemo(() => U ? G ? "ttb" : "btt" : G ? "rtl" : "ltr", [G, U]),
                [ef, em, eg, eh, ep] = (0, t.useMemo)(() => {
                    if (!0 === q || !q) return [!!q, !1, !1, 0];
                    let {
                        editable: e,
                        draggableTrack: t,
                        minCount: r,
                        maxCount: l
                    } = q;
                    return [!0, e, !e && t, r || 0, l]
                }, [q]),
                eb = t.useMemo(() => isFinite(P) ? P : 0, [P]),
                ev = t.useMemo(() => isFinite(H) ? H : 100, [H]),
                ek = t.useMemo(() => null !== N && N <= 0 ? 1 : N, [N]),
                e$ = t.useMemo(() => "boolean" == typeof X ? !!X && ek : X >= 0 && X, [X, ek]),
                eC = t.useMemo(() => Object.keys(Z || {}).map(e => {
                    let r = Z[e],
                        l = {
                            value: Number(e)
                        };
                    return r && "object" == typeof r && !t.isValidElement(r) && ("label" in r || "style" in r) ? (l.style = r.style, l.label = r.label) : l.label = r, l
                }).filter(({
                    label: e
                }) => e || "number" == typeof e).sort((e, t) => e.value - t.value), [Z]),
                [eE, ex] = (i = t.useCallback(e => Math.max(eb, Math.min(ev, e)), [eb, ev]), s = t.useCallback(e => {
                    if (null !== ek) {
                        let t = eb + Math.round((i(e) - eb) / ek) * ek,
                            r = e => (String(e).split(".")[1] || "").length,
                            l = Math.max(r(ek), r(ev), r(eb)),
                            a = Number(t.toFixed(l));
                        return eb <= a && a <= ev ? a : null
                    }
                    return null
                }, [ek, eb, ev, i]), c = t.useCallback(e => {
                    let t = i(e),
                        r = eC.map(e => e.value);
                    null !== ek && r.push(s(e)), r.push(eb, ev);
                    let l = r[0],
                        a = ev - eb;
                    return r.forEach(e => {
                        let r = Math.abs(t - e);
                        r <= a && (l = e, a = r)
                    }), l
                }, [eb, ev, eC, ek, i, s]), f = (e, t, r, l = "unit") => {
                    if ("number" == typeof t) {
                        let a, n = e[r],
                            o = n + t,
                            u = [];
                        eC.forEach(e => {
                            u.push(e.value)
                        }), u.push(eb, ev), u.push(s(n));
                        let i = t > 0 ? 1 : -1;
                        "unit" === l ? u.push(s(n + i * ek)) : u.push(s(o)), u = u.filter(e => null !== e).filter(e => t < 0 ? e <= n : e >= n), "unit" === l && (u = u.filter(e => e !== n));
                        let c = "unit" === l ? n : o,
                            d = Math.abs((a = u[0]) - c);
                        if (u.forEach(e => {
                                let t = Math.abs(e - c);
                                t < d && (a = e, d = t)
                            }), void 0 === a) return t < 0 ? eb : ev;
                        if ("dist" === l) return a;
                        if (Math.abs(t) > 1) {
                            let n = [...e];
                            return n[r] = a, f(n, t - i, r, l)
                        }
                        return a
                    }
                    return "min" === t ? eb : "max" === t ? ev : void 0
                }, m = (e, t, r, l = "unit") => {
                    let a = e[r],
                        n = f(e, t, r, l);
                    return {
                        value: n,
                        changed: n !== a
                    }
                }, g = e => null === e$ && 0 === e || "number" == typeof e$ && e < e$, [c, (e, t, r, l = "unit") => {
                    let a = e.map(c),
                        n = a[r],
                        o = f(a, t, r, l);
                    if (a[r] = o, !1 === W) {
                        let e = e$ || 0;
                        r > 0 && a[r - 1] !== n && (a[r] = Math.max(a[r], a[r - 1] + e)), r < a.length - 1 && a[r + 1] !== n && (a[r] = Math.min(a[r], a[r + 1] - e))
                    } else if ("number" == typeof e$ || null === e$) {
                        for (let e = r + 1; e < a.length; e += 1) {
                            let t = !0;
                            for (; g(a[e] - a[e - 1]) && t;)({
                                value: a[e],
                                changed: t
                            } = m(a, 1, e))
                        }
                        for (let e = r; e > 0; e -= 1) {
                            let t = !0;
                            for (; g(a[e] - a[e - 1]) && t;)({
                                value: a[e - 1],
                                changed: t
                            } = m(a, -1, e - 1))
                        }
                        for (let e = a.length - 1; e > 0; e -= 1) {
                            let t = !0;
                            for (; g(a[e] - a[e - 1]) && t;)({
                                value: a[e - 1],
                                changed: t
                            } = m(a, -1, e - 1))
                        }
                        for (let e = 0; e < a.length - 1; e += 1) {
                            let t = !0;
                            for (; g(a[e + 1] - a[e]) && t;)({
                                value: a[e + 1],
                                changed: t
                            } = m(a, 1, e + 1))
                        }
                    }
                    return {
                        value: a[r],
                        values: a
                    }
                }]),
                [ey, eS] = (0, r.default)(A, I),
                eM = t.useMemo(() => {
                    let e = null == ey ? [] : Array.isArray(ey) ? ey : [ey],
                        [t = eb] = e,
                        r = null === ey ? [] : [t];
                    if (ef) {
                        if (r = [...e], L || void 0 === ey) {
                            let e = L >= 0 ? L + 1 : 2;
                            for (r = r.slice(0, e); r.length < e;) r.push(r[r.length - 1] ? ? eb)
                        }
                        r.sort((e, t) => e - t)
                    }
                    return r.forEach((e, t) => {
                        r[t] = eE(e)
                    }), r
                }, [ey, ef, eb, L, eE]),
                ew = e => ef ? e : e[0],
                eB = (0, l.default)(e => {
                    let t = [...e].sort((e, t) => e - t);
                    T && !(0, a.default)(t, eM, !0) && T(ew(t)), eS(t)
                }),
                eR = (0, l.default)(e => {
                    e && es.current.hideHelp();
                    let t = ew(eM);
                    O ? .(t), (0, n.default)(!O, "[rc-slider] `onAfterChange` is deprecated. Please use `onChangeComplete` instead."), z ? .(t)
                }),
                [eD, eP, eH, eN, eI] = S(ec, ed, eM, eb, ev, eE, eB, eR, ex, em, eh),
                eA = (e, t) => {
                    if (!M) {
                        let r = [...eM],
                            l = 0,
                            a = 0,
                            o = ev - eb;
                        eM.forEach((t, r) => {
                            let n = Math.abs(e - t);
                            n <= o && (o = n, l = r), t < e && (a = r)
                        });
                        let u = l;
                        em && 0 !== o && (!ep || eM.length < ep) ? (r.splice(a + 1, 0, e), u = a + 1) : r[l] = e, ef && !eM.length && void 0 === L && r.push(e);
                        let i = ew(r);
                        F ? .(i), eB(r), t ? (document.activeElement ? .blur ? .(), es.current.focus(u), eI(t, u, r)) : (O ? .(i), (0, n.default)(!O, "[rc-slider] `onAfterChange` is deprecated. Please use `onChangeComplete` instead."), z ? .(i))
                    }
                },
                [eq, eL] = t.useState(null);
            t.useEffect(() => {
                if (null !== eq) {
                    let e = eM.indexOf(eq);
                    e >= 0 && es.current.focus(e)
                }
                eL(null)
            }, [eq]);
            let eT = t.useMemo(() => (!eg || null !== ek) && eg, [eg, ek]),
                eF = (0, l.default)((e, t) => {
                    eI(e, t), F ? .(ew(eM))
                }),
                eO = -1 !== eD;
            t.useEffect(() => {
                if (!eO) {
                    let e = eM.lastIndexOf(eP);
                    es.current.focus(e)
                }
            }, [eO]);
            let ez = t.useMemo(() => [...eN].sort((e, t) => e - t), [eN]),
                [eW, eX] = t.useMemo(() => ef ? [ez[0], ez[ez.length - 1]] : [eb, ez[0]], [ez, ef, eb]);
            t.useImperativeHandle(u, () => ({
                focus: () => {
                    es.current.focus(0)
                },
                blur: () => {
                    let {
                        activeElement: e
                    } = document;
                    ec.current ? .contains(e) && e ? .blur()
                }
            })), t.useEffect(() => {
                B && es.current.focus(0)
            }, []);
            let eG = t.useMemo(() => ({
                min: eb,
                max: ev,
                direction: ed,
                disabled: M,
                keyboard: w,
                step: ek,
                included: Y,
                includedStart: eW,
                includedEnd: eX,
                range: ef,
                tabIndex: ea,
                ariaLabelForHandle: en,
                ariaLabelledByForHandle: eo,
                ariaRequired: eu,
                ariaValueTextFormatterForHandle: ei,
                styles: x || {},
                classNames: C || {}
            }), [eb, ev, ed, M, w, ek, Y, eW, eX, ef, ea, en, eo, eu, ei, x, C]);
            return t.createElement(d.Provider, {
                value: eG
            }, t.createElement("div", {
                ref: ec,
                className: (0, o.clsx)(h, b, {
                    [`${h}-disabled`]: M,
                    [`${h}-vertical`]: U,
                    [`${h}-horizontal`]: !U,
                    [`${h}-with-marks`]: eC.length
                }),
                style: k,
                onMouseDown: e => {
                    let t;
                    e.preventDefault();
                    let {
                        width: r,
                        height: l,
                        left: a,
                        top: n,
                        bottom: o,
                        right: u
                    } = ec.current.getBoundingClientRect(), {
                        clientX: i,
                        clientY: s
                    } = e;
                    switch (ed) {
                        case "btt":
                            t = (o - s) / l;
                            break;
                        case "ttb":
                            t = (s - n) / l;
                            break;
                        case "rtl":
                            t = (u - i) / r;
                            break;
                        default:
                            t = (i - a) / r
                    }
                    eA(eE(eb + t * (ev - eb)), e)
                },
                id: y
            }, t.createElement("div", {
                className: (0, o.clsx)(`${h}-rail`, C ? .rail),
                style: { ..._,
                    ...x ? .rail
                }
            }), !1 !== el && t.createElement(E, {
                prefixCls: h,
                style: K,
                values: eM,
                startPoint: j,
                onStartMove: eT ? eF : void 0
            }), t.createElement($, {
                prefixCls: h,
                marks: eC,
                dots: ee,
                style: J,
                activeStyle: Q
            }), t.createElement(p, {
                ref: es,
                prefixCls: h,
                style: V,
                values: eN,
                draggingIndex: eD,
                draggingDelete: eH,
                onStartMove: eF,
                onOffsetChange: (e, t) => {
                    if (!M) {
                        let r = ex(eM, e, t);
                        F ? .(ew(eM)), eB(r.values), eL(r.value)
                    }
                },
                onFocus: R,
                onBlur: D,
                handleRender: et,
                activeHandleRender: er,
                onChangeComplete: eR,
                onDelete: em ? e => {
                    if (M || !em || eM.length <= eh) return;
                    let t = [...eM];
                    t.splice(e, 1), F ? .(ew(t)), eB(t);
                    let r = Math.max(0, e - 1);
                    es.current.hideHelp(), es.current.focus(r)
                } : void 0
            }), t.createElement(v, {
                prefixCls: h,
                marks: eC,
                onClick: eA
            })))
        });
    e.s(["default", 0, M], 422499);
    var w = e.i(737434),
        B = e.i(711517),
        R = e.i(548817),
        D = e.i(242064),
        P = e.i(937328);
    let H = (0, t.createContext)({});
    e.s(["default", 0, H], 297590);
    var N = e.i(232839),
        I = e.i(491816);
    let A = t.forwardRef((e, r) => {
        let {
            open: l,
            draggingDelete: a,
            value: n
        } = e, o = (0, t.useRef)(null), u = l && !a, i = (0, t.useRef)(null);

        function s() {
            w.default.cancel(i.current), i.current = null
        }
        return t.useEffect(() => (u ? i.current = (0, w.default)(() => {
            o.current ? .forceAlign(), i.current = null
        }) : s(), s), [u, e.title, n]), t.createElement(I.default, {
            ref: (0, N.composeRef)(o, r),
            ...e,
            open: u
        })
    });
    var q = e.i(687385);
    e.i(262370);
    var L = e.i(135551),
        T = e.i(183293),
        F = e.i(246422),
        O = e.i(838378);
    let z = (e, t) => {
            let {
                componentCls: r,
                railSize: l,
                handleSize: a,
                dotSize: n,
                marginFull: o,
                calc: u
            } = e, i = t ? "width" : "height", s = t ? "height" : "width", c = t ? "insetBlockStart" : "insetInlineStart", d = t ? "top" : "insetInlineStart", f = u(l).mul(3).sub(a).div(2).equal(), m = u(a).sub(l).div(2).equal(), g = t ? {
                borderWidth: `${(0,q.unit)(m)} 0`,
                transform: `translateY(${(0,q.unit)(u(m).mul(-1).equal())})`
            } : {
                borderWidth: `0 ${(0,q.unit)(m)}`,
                transform: `translateX(${(0,q.unit)(e.calc(m).mul(-1).equal())})`
            };
            return {
                [t ? "paddingBlock" : "paddingInline"]: l,
                [s]: u(l).mul(3).equal(),
                [`${r}-rail`]: {
                    [i]: "100%",
                    [s]: l
                },
                [`${r}-track,${r}-tracks`]: {
                    [s]: l
                },
                [`${r}-track-draggable`]: { ...g
                },
                [`${r}-handle`]: {
                    [c]: f
                },
                [`${r}-mark`]: {
                    insetInlineStart: 0,
                    top: 0,
                    [d]: u(l).mul(3).add(t ? 0 : o).equal(),
                    [i]: "100%"
                },
                [`${r}-step`]: {
                    insetInlineStart: 0,
                    top: 0,
                    [d]: l,
                    [i]: "100%",
                    [s]: l
                },
                [`${r}-dot`]: {
                    position: "absolute",
                    [c]: u(l).sub(n).div(2).equal()
                }
            }
        },
        W = (0, F.genStyleHooks)("Slider", e => {
            let t = (0, O.mergeToken)(e, {
                marginPart: e.calc(e.controlHeight).sub(e.controlSize).div(2).equal(),
                marginFull: e.calc(e.controlSize).div(2).equal(),
                marginPartWithMark: e.calc(e.controlHeightLG).sub(e.controlSize).equal()
            });
            return [(e => {
                let {
                    componentCls: t,
                    antCls: r,
                    controlSize: l,
                    dotSize: a,
                    marginFull: n,
                    marginPart: o,
                    colorFillContentHover: u,
                    handleColorDisabled: i,
                    calc: s,
                    handleSize: c,
                    handleSizeHover: d,
                    handleActiveColor: f,
                    handleActiveOutlineColor: m,
                    handleLineWidth: g,
                    handleLineWidthHover: h,
                    motionDurationMid: p
                } = e;
                return {
                    [t]: { ...(0, T.resetComponent)(e),
                        position: "relative",
                        height: l,
                        margin: `${(0,q.unit)(o)} ${(0,q.unit)(n)}`,
                        padding: 0,
                        cursor: "pointer",
                        touchAction: "none",
                        "&-vertical": {
                            margin: `${(0,q.unit)(n)} ${(0,q.unit)(o)}`
                        },
                        [`${t}-rail`]: {
                            position: "absolute",
                            backgroundColor: e.railBg,
                            borderRadius: e.borderRadiusXS,
                            transition: `background-color ${p}`
                        },
                        [`${t}-track,${t}-tracks`]: {
                            position: "absolute",
                            transition: `background-color ${p}`
                        },
                        [`${t}-track`]: {
                            backgroundColor: e.trackBg,
                            borderRadius: e.borderRadiusXS
                        },
                        [`${t}-track-draggable`]: {
                            boxSizing: "content-box",
                            backgroundClip: "content-box",
                            border: "solid rgba(0,0,0,0)"
                        },
                        "&:hover": {
                            [`${t}-rail`]: {
                                backgroundColor: e.railHoverBg
                            },
                            [`${t}-track`]: {
                                backgroundColor: e.trackHoverBg
                            },
                            [`${t}-dot`]: {
                                borderColor: u
                            },
                            [`${t}-handle::after`]: {
                                boxShadow: `0 0 0 ${(0,q.unit)(g)} ${e.colorPrimaryBorderHover}`
                            },
                            [`${t}-dot-active`]: {
                                borderColor: e.dotActiveBorderColor
                            }
                        },
                        [`${t}-handle`]: {
                            position: "absolute",
                            width: c,
                            height: c,
                            outline: "none",
                            userSelect: "none",
                            "&-dragging-delete": {
                                opacity: 0
                            },
                            "&::before": {
                                content: '""',
                                position: "absolute",
                                insetInlineStart: s(g).mul(-1).equal(),
                                insetBlockStart: s(g).mul(-1).equal(),
                                width: s(c).add(s(g).mul(2)).equal(),
                                height: s(c).add(s(g).mul(2)).equal(),
                                backgroundColor: "transparent"
                            },
                            "&::after": {
                                content: '""',
                                position: "absolute",
                                insetBlockStart: 0,
                                insetInlineStart: 0,
                                width: c,
                                height: c,
                                backgroundColor: e.colorBgElevated,
                                boxShadow: `0 0 0 ${(0,q.unit)(g)} ${e.handleColor}`,
                                outline: "0px solid transparent",
                                borderRadius: "50%",
                                cursor: "pointer",
                                transition: `
            inset-inline-start ${p},
            inset-block-start ${p},
            width ${p},
            height ${p},
            box-shadow ${p},
            outline ${p}
          `
                            },
                            "&:hover, &:active, &:focus": {
                                "&::before": {
                                    insetInlineStart: s(d).sub(c).div(2).add(h).mul(-1).equal(),
                                    insetBlockStart: s(d).sub(c).div(2).add(h).mul(-1).equal(),
                                    width: s(d).add(s(h).mul(2)).equal(),
                                    height: s(d).add(s(h).mul(2)).equal()
                                },
                                "&::after": {
                                    boxShadow: `0 0 0 ${(0,q.unit)(h)} ${f}`,
                                    outline: `6px solid ${m}`,
                                    width: d,
                                    height: d,
                                    insetInlineStart: e.calc(c).sub(d).div(2).equal(),
                                    insetBlockStart: e.calc(c).sub(d).div(2).equal()
                                }
                            }
                        },
                        [`&-lock ${t}-handle`]: {
                            "&::before, &::after": {
                                transition: "none"
                            }
                        },
                        [`${t}-mark`]: {
                            position: "absolute",
                            fontSize: e.fontSize
                        },
                        [`${t}-mark-text`]: {
                            position: "absolute",
                            display: "inline-block",
                            color: e.colorTextDescription,
                            textAlign: "center",
                            wordBreak: "keep-all",
                            cursor: "pointer",
                            userSelect: "none",
                            "&-active": {
                                color: e.colorText
                            }
                        },
                        [`${t}-step`]: {
                            position: "absolute",
                            background: "transparent",
                            pointerEvents: "none"
                        },
                        [`${t}-dot`]: {
                            position: "absolute",
                            width: a,
                            height: a,
                            backgroundColor: e.colorBgElevated,
                            border: `${(0,q.unit)(g)} solid ${e.dotBorderColor}`,
                            borderRadius: "50%",
                            cursor: "pointer",
                            transition: `border-color ${e.motionDurationSlow}`,
                            pointerEvents: "auto",
                            "&-active": {
                                borderColor: e.dotActiveBorderColor
                            }
                        },
                        [`&${t}-disabled`]: {
                            cursor: "not-allowed",
                            [`${t}-rail`]: {
                                backgroundColor: `${e.railBg} !important`
                            },
                            [`${t}-track`]: {
                                backgroundColor: `${e.trackBgDisabled} !important`
                            },
                            [`
          ${t}-dot
        `]: {
                                backgroundColor: e.colorBgElevated,
                                borderColor: e.trackBgDisabled,
                                boxShadow: "none",
                                cursor: "not-allowed"
                            },
                            [`${t}-handle::after`]: {
                                backgroundColor: e.colorBgElevated,
                                cursor: "not-allowed",
                                width: c,
                                height: c,
                                boxShadow: `0 0 0 ${(0,q.unit)(g)} ${i}`,
                                insetInlineStart: 0,
                                insetBlockStart: 0
                            },
                            [`
          ${t}-mark-text,
          ${t}-dot
        `]: {
                                cursor: "not-allowed !important"
                            }
                        },
                        [`&-tooltip ${r}-tooltip-container`]: {
                            minWidth: "unset"
                        }
                    }
                }
            })(t), (e => {
                let {
                    componentCls: t,
                    marginPartWithMark: r
                } = e;
                return {
                    [`${t}-horizontal`]: { ...z(e, !0),
                        [`&${t}-with-marks`]: {
                            marginBottom: r
                        }
                    }
                }
            })(t), (e => {
                let {
                    componentCls: t
                } = e;
                return {
                    [`${t}-vertical`]: { ...z(e, !1),
                        height: "100%"
                    }
                }
            })(t)]
        }, e => {
            let t = e.controlHeightLG / 4,
                r = e.controlHeightSM / 2,
                l = e.lineWidth + 1,
                a = e.lineWidth + 1.5,
                n = e.colorPrimary,
                o = new L.FastColor(n).setA(.2).toRgbString();
            return {
                controlSize: t,
                railSize: 4,
                handleSize: t,
                handleSizeHover: r,
                dotSize: 8,
                handleLineWidth: l,
                handleLineWidthHover: a,
                railBg: e.colorFillTertiary,
                railHoverBg: e.colorFillSecondary,
                trackBg: e.colorPrimaryBorder,
                trackHoverBg: e.colorPrimaryBorderHover,
                handleColor: e.colorPrimaryBorder,
                handleActiveColor: n,
                handleActiveOutlineColor: o,
                handleColorDisabled: new L.FastColor(e.colorTextDisabled).onBackground(e.colorBgContainer).toHexString(),
                dotBorderColor: e.colorBorderSecondary,
                dotActiveBorderColor: e.colorPrimaryBorder,
                trackBgDisabled: e.colorBgContainerDisabled
            }
        });

    function X() {
        let [e, r] = t.useState(!1), l = t.useRef(null), a = () => {
            w.default.cancel(l.current)
        };
        return t.useEffect(() => a, []), [e, e => {
            a(), e ? r(e) : l.current = (0, w.default)(() => {
                r(e)
            })
        }]
    }
    let G = t.default.forwardRef((e, r) => {
        let {
            prefixCls: l,
            range: a,
            className: n,
            rootClassName: u,
            style: i,
            disabled: s,
            tooltip: c = {},
            onChangeComplete: d,
            classNames: f,
            styles: m,
            vertical: g,
            orientation: h,
            ...p
        } = e, [, b] = (0, R.useOrientation)(h, g), {
            getPrefixCls: v,
            direction: k,
            className: $,
            style: C,
            classNames: E,
            styles: x,
            getPopupContainer: y
        } = (0, D.useComponentConfig)("slider"), S = t.default.useContext(P.default), N = s ? ? S, I = { ...e,
            disabled: N,
            vertical: b
        }, [q, L] = (0, B.useMergeSemantic)([E, f], [x, m], {
            props: I
        }), {
            handleRender: T,
            direction: F
        } = t.default.useContext(H), O = "rtl" === (F || k), [z, G] = X(), [U, Y] = X(), j = { ...c
        }, {
            open: K,
            placement: V,
            getPopupContainer: _,
            prefixCls: J,
            formatter: Q
        } = j, Z = (z || U) && !1 !== K, ee = Q || null === Q ? Q : e => "number" == typeof e ? e.toString() : "", [et, er] = X(), el = (e, t) => e || (t ? O ? "left" : "right" : "top"), ea = v("slider", l), [en, eo] = W(ea), eu = (0, o.clsx)(n, $, q.root, u, {
            [`${ea}-rtl`]: O,
            [`${ea}-lock`]: et
        }, en, eo);
        O && !b && (p.reverse = !p.reverse), t.default.useEffect(() => {
            let e = () => {
                (0, w.default)(() => {
                    Y(!1)
                }, 1)
            };
            return document.addEventListener("mouseup", e), () => {
                document.removeEventListener("mouseup", e)
            }
        }, []);
        let ei = a && !K,
            es = T || ((e, r) => {
                let {
                    index: l
                } = r, a = e.props;

                function n(e, t, r) {
                    r && p[e] ? .(t), a[e] ? .(t)
                }
                let o = { ...a,
                        onMouseEnter: e => {
                            G(!0), n("onMouseEnter", e)
                        },
                        onMouseLeave: e => {
                            G(!1), n("onMouseLeave", e)
                        },
                        onMouseDown: e => {
                            Y(!0), er(!0), n("onMouseDown", e)
                        },
                        onFocus: e => {
                            Y(!0), p.onFocus ? .(e), n("onFocus", e, !0)
                        },
                        onBlur: e => {
                            Y(!1), p.onBlur ? .(e), n("onBlur", e, !0)
                        }
                    },
                    u = t.default.cloneElement(e, o),
                    i = (!!K || Z) && null !== ee;
                return ei ? u : t.default.createElement(A, { ...j,
                    prefixCls: v("tooltip", J),
                    title: ee ? ee(r.value) : "",
                    value: r.value,
                    open: i,
                    placement: el(V, b),
                    key: l,
                    classNames: {
                        root: `${ea}-tooltip`
                    },
                    getPopupContainer: _ || y
                }, u)
            }),
            ec = ei ? (e, r) => {
                let l = t.default.cloneElement(e, {
                    style: { ...e.props.style,
                        visibility: "hidden"
                    }
                });
                return t.default.createElement(A, { ...j,
                    prefixCls: v("tooltip", J),
                    title: ee ? ee(r.value) : "",
                    open: null !== ee && Z,
                    placement: el(V, b),
                    key: "tooltip",
                    classNames: {
                        root: `${ea}-tooltip`
                    },
                    getPopupContainer: _ || y,
                    draggingDelete: r.draggingDelete
                }, l)
            } : void 0,
            ed = { ...L.root,
                ...C,
                ...i
            };
        return t.default.createElement(M, { ...p,
            classNames: q,
            styles: L,
            step: p.step,
            range: a,
            className: eu,
            style: ed,
            disabled: N,
            vertical: b,
            ref: r,
            prefixCls: ea,
            handleRender: es,
            activeHandleRender: ec,
            onChangeComplete: e => {
                d ? .(e), er(!1)
            }
        })
    });
    e.s(["default", 0, G], 756135)
}]);