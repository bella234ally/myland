(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 742732, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "HeadManagerContext", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(555682)._(e.r(271645)).default.createContext({})
}, 168027, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(843476),
        o = e.r(912354),
        l = {
            fontFamily: 'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
            height: "100vh",
            textAlign: "center",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center"
        },
        i = {
            fontSize: "14px",
            fontWeight: 400,
            lineHeight: "28px",
            margin: "0 8px"
        },
        a = function({
            error: e
        }) {
            let t = e ? .digest;
            return (0, n.jsxs)("html", {
                id: "__next_error__",
                children: [(0, n.jsx)("head", {}), (0, n.jsxs)("body", {
                    children: [(0, n.jsx)(o.HandleISRError, {
                        error: e
                    }), (0, n.jsx)("div", {
                        style: l,
                        children: (0, n.jsxs)("div", {
                            children: [(0, n.jsxs)("h2", {
                                style: i,
                                children: ["Application error: a ", t ? "server" : "client", "-side exception has occurred while loading ", window.location.hostname, " (see the", " ", t ? "server logs" : "browser console", " for more information)."]
                            }), t ? (0, n.jsx)("p", {
                                style: i,
                                children: `Digest: ${t}`
                            }) : null]
                        })
                    })]
                })]
            })
        };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 974575, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "getAssetPrefix", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(312718);

    function o() {
        let e = document.currentScript;
        if (!(e instanceof HTMLScriptElement)) throw Object.defineProperty(new n.InvariantError(`Expected document.currentScript to be a <script> element. Received ${e} instead.`), "__NEXT_ERROR_CODE", {
            value: "E783",
            enumerable: !1,
            configurable: !0
        });
        let {
            pathname: t
        } = new URL(e.src), r = t.indexOf("/_next/");
        if (-1 === r) throw Object.defineProperty(new n.InvariantError(`Expected document.currentScript src to contain '/_next/'. Received ${e.src} instead.`), "__NEXT_ERROR_CODE", {
            value: "E784",
            enumerable: !1,
            configurable: !0
        });
        return t.slice(0, r)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 922737, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "setAttributesFromProps", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = {
            acceptCharset: "accept-charset",
            className: "class",
            htmlFor: "for",
            httpEquiv: "http-equiv",
            noModule: "noModule"
        },
        o = ["onLoad", "onReady", "dangerouslySetInnerHTML", "children", "onError", "strategy", "stylesheets"];

    function l(e) {
        return ["async", "defer", "noModule"].includes(e)
    }

    function i(e, t) {
        for (let [r, i] of Object.entries(t)) {
            if (!t.hasOwnProperty(r) || o.includes(r) || void 0 === i) continue;
            let a = n[r] || r.toLowerCase();
            "SCRIPT" === e.tagName && l(a) ? e[a] = !!i : e.setAttribute(a, String(i)), (!1 === i || "SCRIPT" === e.tagName && l(a) && (!i || "false" === i)) && (e.setAttribute(a, ""), e.removeAttribute(a))
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 396517, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "appBootstrap", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(974575),
        o = e.r(922737);

    function l(e) {
        var t, r;
        let l = (0, n.getAssetPrefix)();
        t = self.__next_s, r = () => {
            e(l)
        }, t && t.length ? t.reduce((e, [t, r]) => e.then(() => new Promise((e, n) => {
            let l = document.createElement("script");
            r && (0, o.setAttributesFromProps)(l, r), t ? (l.src = t, l.onload = () => e(), l.onerror = n) : r && (l.innerHTML = r.children, setTimeout(e)), document.head.appendChild(l)
        })), Promise.resolve()).catch(e => {
            console.error(e)
        }).then(() => {
            r()
        }) : r()
    }
    window.next = {
        version: "16.1.0",
        appDir: !0
    }, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 816565, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getObjectClassLabel: function() {
            return l
        },
        isPlainObject: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function l(e) {
        return Object.prototype.toString.call(e)
    }

    function i(e) {
        if ("[object Object]" !== l(e)) return !1;
        let t = Object.getPrototypeOf(e);
        return null === t || t.hasOwnProperty("isPrototypeOf")
    }
}, 302023, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return i
        },
        getProperError: function() {
            return a
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let l = e.r(816565);

    function i(e) {
        return "object" == typeof e && null !== e && "name" in e && "message" in e
    }

    function a(e) {
        let t;
        return i(e) ? e : Object.defineProperty(Error((0, l.isPlainObject)(e) ? (t = new WeakSet, JSON.stringify(e, (e, r) => {
            if ("object" == typeof r && null !== r) {
                if (t.has(r)) return "[Circular]";
                t.add(r)
            }
            return r
        })) : e + ""), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        })
    }
}, 528279, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "reportGlobalError", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = "function" == typeof reportError ? reportError : e => {
        globalThis.console.error(e)
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 597238, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        isRecoverableError: function() {
            return s
        },
        onRecoverableError: function() {
            return c
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let l = e.r(555682),
        i = e.r(132061),
        a = l._(e.r(302023)),
        u = e.r(528279),
        d = new WeakSet;

    function s(e) {
        return d.has(e)
    }
    let c = e => {
        let t = (0, a.default)(e) && "cause" in e ? e.cause : e;
        (0, i.isBailoutToCSRError)(t) || (0, u.reportGlobalError)(t)
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 5526, (e, t, r) => {
    "use strict";
    t.exports = {}
}, 966849, (e, t, r) => {
    "trimStart" in String.prototype || (String.prototype.trimStart = String.prototype.trimLeft), "trimEnd" in String.prototype || (String.prototype.trimEnd = String.prototype.trimRight), "description" in Symbol.prototype || Object.defineProperty(Symbol.prototype, "description", {
        configurable: !0,
        get: function() {
            var e = /\((.*)\)/.exec(this.toString());
            return e ? e[1] : void 0
        }
    }), Array.prototype.flat || (Array.prototype.flat = function(e, t) {
        return t = this.concat.apply([], this), e > 1 && t.some(Array.isArray) ? t.flat(e - 1) : t
    }, Array.prototype.flatMap = function(e, t) {
        return this.map(e, t).flat()
    }), Promise.prototype.finally || (Promise.prototype.finally = function(e) {
        if ("function" != typeof e) return this.then(e, e);
        var t = this.constructor || Promise;
        return this.then(function(r) {
            return t.resolve(e()).then(function() {
                return r
            })
        }, function(r) {
            return t.resolve(e()).then(function() {
                throw r
            })
        })
    }), Object.fromEntries || (Object.fromEntries = function(e) {
        return Array.from(e).reduce(function(e, t) {
            return e[t[0]] = t[1], e
        }, {})
    }), Array.prototype.at || (Array.prototype.at = function(e) {
        var t = Math.trunc(e) || 0;
        if (t < 0 && (t += this.length), !(t < 0 || t >= this.length)) return this[t]
    }), Object.hasOwn || (Object.hasOwn = function(e, t) {
        if (null == e) throw TypeError("Cannot convert undefined or null to object");
        return Object.prototype.hasOwnProperty.call(Object(e), t)
    }), "canParse" in URL || (URL.canParse = function(e, t) {
        try {
            return new URL(e, t), !0
        } catch (e) {
            return !1
        }
    })
}, 523911, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), e.r(966849), ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 851323, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        onCaughtError: function() {
            return f
        },
        onUncaughtError: function() {
            return p
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let l = e.r(555682),
        i = e.r(265713),
        a = e.r(132061),
        u = e.r(528279),
        d = e.r(972383),
        s = l._(e.r(168027)),
        c = {
            decorateDevError: e => e,
            handleClientError: () => {},
            originConsoleError: console.error.bind(console)
        };

    function f(e, t) {
        let r, n = t.errorBoundary ? .constructor;
        if (r = r || n === d.ErrorBoundaryHandler && t.errorBoundary.props.errorComponent === s.default) return p(e);
        (0, a.isBailoutToCSRError)(e) || (0, i.isNextRouterError)(e) || c.originConsoleError(e)
    }

    function p(e) {
        (0, a.isBailoutToCSRError)(e) || (0, i.isNextRouterError)(e) || (0, u.reportGlobalError)(e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 762634, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "AppRouterAnnouncer", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(271645),
        o = e.r(174080),
        l = "next-route-announcer";

    function i({
        tree: e
    }) {
        let [t, r] = (0, n.useState)(null);
        (0, n.useEffect)(() => (r(function() {
            let e = document.getElementsByName(l)[0];
            if (e ? .shadowRoot ? .childNodes[0]) return e.shadowRoot.childNodes[0]; {
                let e = document.createElement(l);
                e.style.cssText = "position:absolute";
                let t = document.createElement("div");
                return t.ariaLive = "assertive", t.id = "__next-route-announcer__", t.role = "alert", t.style.cssText = "position:absolute;border:0;height:1px;margin:-1px;padding:0;width:1px;clip:rect(0 0 0 0);overflow:hidden;white-space:nowrap;word-wrap:normal", e.attachShadow({
                    mode: "open"
                }).appendChild(t), document.body.appendChild(e), t
            }
        }()), () => {
            let e = document.getElementsByTagName(l)[0];
            e ? .isConnected && document.body.removeChild(e)
        }), []);
        let [i, a] = (0, n.useState)(""), u = (0, n.useRef)(void 0);
        return (0, n.useEffect)(() => {
            let e = "";
            if (document.title) e = document.title;
            else {
                let t = document.querySelector("h1");
                t && (e = t.innerText || t.textContent || "")
            }
            void 0 !== u.current && u.current !== e && a(e), u.current = e
        }, [e]), t ? (0, o.createPortal)(i, t) : null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 425018, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "findHeadInCache", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(813258),
        o = e.r(270725);

    function l(e, t) {
        return function e(t, r, l, i) {
            if (0 === Object.keys(r).length) return [t, l, i];
            let a = Object.keys(r).filter(e => "children" !== e);
            for (let i of ("children" in r && a.unshift("children"), a)) {
                let [a, u] = r[i];
                if (a === n.DEFAULT_SEGMENT_KEY) continue;
                let d = t.parallelRoutes.get(i);
                if (!d) continue;
                let s = (0, o.createRouterCacheKey)(a),
                    c = (0, o.createRouterCacheKey)(a, !0),
                    f = d.get(s);
                if (!f) continue;
                let p = e(f, u, l + "/" + s, l + "/" + c);
                if (p) return p
            }
            return null
        }(e, t, "", "")
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 241624, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        GracefulDegradeBoundary: function() {
            return a
        },
        default: function() {
            return u
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let l = e.r(843476),
        i = e.r(271645);
    class a extends i.Component {
        constructor(e) {
            super(e), this.state = {
                hasError: !1
            }, this.rootHtml = "", this.htmlAttributes = {}, this.htmlRef = (0, i.createRef)()
        }
        static getDerivedStateFromError(e) {
            return {
                hasError: !0
            }
        }
        componentDidMount() {
            let e = this.htmlRef.current;
            this.state.hasError && e && Object.entries(this.htmlAttributes).forEach(([t, r]) => {
                e.setAttribute(t, r)
            })
        }
        render() {
            let {
                hasError: e
            } = this.state;
            return ("undefined" == typeof window || this.rootHtml || (this.rootHtml = document.documentElement.innerHTML, this.htmlAttributes = function(e) {
                let t = {};
                for (let r = 0; r < e.attributes.length; r++) {
                    let n = e.attributes[r];
                    t[n.name] = n.value
                }
                return t
            }(document.documentElement)), e) ? (0, l.jsx)("html", {
                ref: this.htmlRef,
                suppressHydrationWarning: !0,
                dangerouslySetInnerHTML: {
                    __html: this.rootHtml
                }
            }) : this.props.children
        }
    }
    let u = a;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 794109, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return d
        }
    });
    let n = e.r(555682),
        o = e.r(843476);
    e.r(271645);
    let l = n._(e.r(241624)),
        i = e.r(972383),
        a = e.r(82604),
        u = "undefined" != typeof window && (0, a.isBot)(window.navigator.userAgent);

    function d({
        children: e,
        errorComponent: t,
        errorStyles: r,
        errorScripts: n
    }) {
        return u ? (0, o.jsx)(l.default, {
            children: e
        }) : (0, o.jsx)(i.ErrorBoundary, {
            errorComponent: t,
            errorStyles: r,
            errorScripts: n,
            children: e
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 875530, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return N
        }
    });
    let n = e.r(555682),
        o = e.r(190809),
        l = e.r(843476),
        i = o._(e.r(271645)),
        a = e.r(8372),
        u = e.r(388540),
        d = e.r(451191),
        s = e.r(261994),
        c = e.r(941538),
        f = e.r(762634),
        p = e.r(358442),
        h = e.r(425018),
        _ = e.r(201244),
        y = e.r(387250),
        b = e.r(652817),
        m = e.r(734727),
        v = e.r(178377),
        E = e.r(699781),
        j = e.r(124063),
        g = e.r(968391),
        w = e.r(91949),
        P = n._(e.r(794109)),
        O = n._(e.r(168027)),
        R = e.r(897367),
        S = e.r(543369),
        x = {};

    function M({
        appRouterState: e
    }) {
        return (0, i.useInsertionEffect)(() => {
            let {
                tree: t,
                pushRef: r,
                canonicalUrl: n,
                renderedSearch: o
            } = e, l = { ...r.preserveCustomHistoryState ? window.history.state : {},
                __NA: !0,
                __PRIVATE_NEXTJS_INTERNALS_TREE: {
                    tree: t,
                    renderedSearch: o
                }
            };
            r.pendingPush && (0, d.createHrefFromUrl)(new URL(window.location.href)) !== n ? (r.pendingPush = !1, window.history.pushState(l, "", n)) : window.history.replaceState(l, "", n)
        }, [e]), (0, i.useEffect)(() => {
            (0, w.pingVisibleLinks)(e.nextUrl, e.tree)
        }, [e.nextUrl, e.tree]), null
    }

    function T(e) {
        null == e && (e = {});
        let t = window.history.state,
            r = t ? .__NA;
        r && (e.__NA = r);
        let n = t ? .__PRIVATE_NEXTJS_INTERNALS_TREE;
        return n && (e.__PRIVATE_NEXTJS_INTERNALS_TREE = n), e
    }

    function A({
        headCacheNode: e
    }) {
        let t = null !== e ? e.head : null,
            r = null !== e ? e.prefetchHead : null,
            n = null !== r ? r : t;
        return (0, i.useDeferredValue)(t, n)
    }

    function C({
        actionQueue: e,
        globalError: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        let o, d = (0, c.useActionQueue)(e),
            {
                canonicalUrl: v
            } = d,
            {
                searchParams: w,
                pathname: O
            } = (0, i.useMemo)(() => {
                let e = new URL(v, "undefined" == typeof window ? "http://n" : window.location.href);
                return {
                    searchParams: e.searchParams,
                    pathname: (0, b.hasBasePath)(e.pathname) ? (0, y.removeBasePath)(e.pathname) : e.pathname
                }
            }, [v]);
        (0, i.useEffect)(() => {
            function e(e) {
                e.persisted && window.history.state ? .__PRIVATE_NEXTJS_INTERNALS_TREE && (x.pendingMpaPath = void 0, (0, c.dispatchAppRouterAction)({
                    type: u.ACTION_RESTORE,
                    url: new URL(window.location.href),
                    historyState: window.history.state.__PRIVATE_NEXTJS_INTERNALS_TREE
                }))
            }
            return window.addEventListener("pageshow", e), () => {
                window.removeEventListener("pageshow", e)
            }
        }, []), (0, i.useEffect)(() => {
            function e(e) {
                let t = "reason" in e ? e.reason : e.error;
                if ((0, g.isRedirectError)(t)) {
                    e.preventDefault();
                    let r = (0, j.getURLFromRedirectError)(t);
                    (0, j.getRedirectTypeFromError)(t) === g.RedirectType.push ? E.publicAppRouterInstance.push(r, {}) : E.publicAppRouterInstance.replace(r, {})
                }
            }
            return window.addEventListener("error", e), window.addEventListener("unhandledrejection", e), () => {
                window.removeEventListener("error", e), window.removeEventListener("unhandledrejection", e)
            }
        }, []);
        let {
            pushRef: S
        } = d;
        if (S.mpaNavigation) {
            if (x.pendingMpaPath !== v) {
                let e = window.location;
                S.pendingPush ? e.assign(v) : e.replace(v), x.pendingMpaPath = v
            }
            throw _.unresolvedThenable
        }(0, i.useEffect)(() => {
            let e = window.history.pushState.bind(window.history),
                t = window.history.replaceState.bind(window.history),
                r = e => {
                    let t = window.location.href,
                        r = window.history.state ? .__PRIVATE_NEXTJS_INTERNALS_TREE;
                    (0, i.startTransition)(() => {
                        (0, c.dispatchAppRouterAction)({
                            type: u.ACTION_RESTORE,
                            url: new URL(e ? ? t, t),
                            historyState: r
                        })
                    })
                };
            window.history.pushState = function(t, n, o) {
                return t ? .__NA || t ? ._N || (t = T(t), o && r(o)), e(t, n, o)
            }, window.history.replaceState = function(e, n, o) {
                return e ? .__NA || e ? ._N || (e = T(e), o && r(o)), t(e, n, o)
            };
            let n = e => {
                if (e.state) {
                    if (!e.state.__NA) return void window.location.reload();
                    (0, i.startTransition)(() => {
                        (0, E.dispatchTraverseAction)(window.location.href, e.state.__PRIVATE_NEXTJS_INTERNALS_TREE)
                    })
                }
            };
            return window.addEventListener("popstate", n), () => {
                window.history.pushState = e, window.history.replaceState = t, window.removeEventListener("popstate", n)
            }
        }, []);
        let {
            cache: C,
            tree: N,
            nextUrl: L,
            focusAndScrollRef: I,
            previousNextUrl: F
        } = d, H = (0, i.useMemo)(() => (0, h.findHeadInCache)(C, N[1]), [C, N]), D = (0, i.useMemo)(() => (0, m.getSelectedParams)(N), [N]), B = (0, i.useMemo)(() => ({
            parentTree: N,
            parentCacheNode: C,
            parentSegmentPath: null,
            parentParams: {},
            debugNameContext: "/",
            url: v,
            isActive: !0
        }), [N, C, v]), X = (0, i.useMemo)(() => ({
            tree: N,
            focusAndScrollRef: I,
            nextUrl: L,
            previousNextUrl: F
        }), [N, I, L, F]);
        if (null !== H) {
            let [e, t, r] = H;
            o = (0, l.jsx)(A, {
                headCacheNode: e
            }, "undefined" == typeof window ? r : t)
        } else o = null;
        let k = (0, l.jsxs)(p.RedirectBoundary, {
            children: [o, (0, l.jsx)(R.RootLayoutBoundary, {
                children: C.rsc
            }), (0, l.jsx)(f.AppRouterAnnouncer, {
                tree: N
            })]
        });
        return k = (0, l.jsx)(P.default, {
            errorComponent: t[0],
            errorStyles: t[1],
            children: k
        }), (0, l.jsxs)(l.Fragment, {
            children: [(0, l.jsx)(M, {
                appRouterState: d
            }), (0, l.jsx)(U, {}), (0, l.jsx)(s.NavigationPromisesContext.Provider, {
                value: null,
                children: (0, l.jsx)(s.PathParamsContext.Provider, {
                    value: D,
                    children: (0, l.jsx)(s.PathnameContext.Provider, {
                        value: O,
                        children: (0, l.jsx)(s.SearchParamsContext.Provider, {
                            value: w,
                            children: (0, l.jsx)(a.GlobalLayoutRouterContext.Provider, {
                                value: X,
                                children: (0, l.jsx)(a.AppRouterContext.Provider, {
                                    value: E.publicAppRouterInstance,
                                    children: (0, l.jsx)(a.LayoutRouterContext.Provider, {
                                        value: B,
                                        children: k
                                    })
                                })
                            })
                        })
                    })
                })
            })]
        })
    }

    function N({
        actionQueue: e,
        globalErrorState: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        (0, v.useNavFailureHandler)();
        let o = (0, l.jsx)(C, {
            actionQueue: e,
            globalError: t,
            webSocket: r,
            staticIndicatorState: n
        });
        return (0, l.jsx)(P.default, {
            errorComponent: O.default,
            children: o
        })
    }
    let L = new Set,
        I = new Set;

    function U() {
        let [, e] = i.default.useState(0), t = L.size;
        (0, i.useEffect)(() => {
            let r = () => e(e => e + 1);
            return I.add(r), t !== L.size && r(), () => {
                I.delete(r)
            }
        }, [t, e]);
        let r = (0, S.getDeploymentIdQueryOrEmptyString)();
        return [...L].map((e, t) => (0, l.jsx)("link", {
            rel: "stylesheet",
            href: `${e}${r}`,
            precedence: "next"
        }, t))
    }
    globalThis._N_E_STYLE_LOAD = function(e) {
        let t = L.size;
        return L.add(e), L.size !== t && I.forEach(e => e()), Promise.resolve()
    }, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 665716, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createInitialRouterState", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(451191),
        o = e.r(734727),
        l = e.r(450590),
        i = e.r(595871);

    function a({
        navigatedAt: e,
        initialFlightData: t,
        initialCanonicalUrlParts: r,
        initialRenderedSearch: a,
        location: u
    }) {
        let d = r.join("/"),
            {
                tree: s,
                seedData: c,
                head: f
            } = (0, l.getFlightDataPartsFromPath)(t[0]),
            p = u ? (0, n.createHrefFromUrl)(u) : d;
        return {
            tree: s,
            cache: (0, i.createInitialCacheNodeForHydration)(e, s, c, f),
            pushRef: {
                pendingPush: !1,
                mpaNavigation: !1,
                preserveCustomHistoryState: !0
            },
            focusAndScrollRef: {
                apply: !1,
                onlyHashChange: !1,
                hashFragment: null,
                segmentPaths: []
            },
            canonicalUrl: p,
            renderedSearch: a,
            nextUrl: ((0, o.extractPathFromFlightRouterState)(s) || u ? .pathname) ? ? null,
            previousNextUrl: null,
            debugInfo: null
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 198569, (e, t, r) => {
    "use strict";
    let n, o, l, i;
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "hydrate", {
        enumerable: !0,
        get: function() {
            return H
        }
    });
    let a = e.r(555682),
        u = e.r(843476);
    e.r(523911);
    let d = a._(e.r(88014)),
        s = a._(e.r(271645)),
        c = e.r(235326),
        f = e.r(742732),
        p = e.r(597238),
        h = e.r(851323),
        _ = e.r(132120),
        y = e.r(92245),
        b = e.r(699781),
        m = a._(e.r(875530)),
        v = e.r(665716);
    e.r(8372);
    let E = e.r(814297),
        j = e.r(450590),
        g = c.createFromReadableStream,
        w = c.createFromFetch,
        P = document,
        O = new TextEncoder,
        R = !1,
        S = !1,
        x = null;

    function M(e) {
        if (0 === e[0]) l = [];
        else if (1 === e[0]) {
            if (!l) throw Object.defineProperty(Error("Unexpected server data: missing bootstrap script."), "__NEXT_ERROR_CODE", {
                value: "E18",
                enumerable: !1,
                configurable: !0
            });
            i ? i.enqueue(O.encode(e[1])) : l.push(e[1])
        } else if (2 === e[0]) x = e[1];
        else if (3 === e[0]) {
            if (!l) throw Object.defineProperty(Error("Unexpected server data: missing bootstrap script."), "__NEXT_ERROR_CODE", {
                value: "E18",
                enumerable: !1,
                configurable: !0
            });
            let r = atob(e[1]),
                n = new Uint8Array(r.length);
            for (var t = 0; t < r.length; t++) n[t] = r.charCodeAt(t);
            i ? i.enqueue(n) : l.push(n)
        }
    }
    let T = function() {
        i && !S && (i.close(), S = !0, l = void 0), R = !0
    };
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", T, !1) : setTimeout(T);
    let A = self.__next_f = self.__next_f || [];
    A.forEach(M), A.length = 0, A.push = M;
    let C = new ReadableStream({
            start(e) {
                l && (l.forEach(t => {
                    e.enqueue("string" == typeof t ? O.encode(t) : t)
                }), R && !S) && (null === e.desiredSize || e.desiredSize < 0 ? e.error(Object.defineProperty(Error("The connection to the page was unexpectedly closed, possibly due to the stop button being clicked, loss of Wi-Fi, or an unstable internet connection."), "__NEXT_ERROR_CODE", {
                    value: "E117",
                    enumerable: !1,
                    configurable: !0
                })) : e.close(), S = !0, l = void 0), i = e
            }
        }),
        N = window.__NEXT_CLIENT_RESUME;

    function L({
        initialRSCPayload: e,
        actionQueue: t,
        webSocket: r,
        staticIndicatorState: n
    }) {
        return (0, u.jsx)(m.default, {
            actionQueue: t,
            globalErrorState: e.G,
            webSocket: r,
            staticIndicatorState: n
        })
    }
    o = N ? Promise.resolve(w(N, {
        callServer: _.callServer,
        findSourceMapURL: y.findSourceMapURL,
        debugChannel: n
    })).then(async e => (0, j.createInitialRSCPayloadFromFallbackPrerender)(await N, e)) : g(C, {
        callServer: _.callServer,
        findSourceMapURL: y.findSourceMapURL,
        debugChannel: n,
        startTime: 0
    });
    let I = s.default.Fragment;

    function U({
        children: e
    }) {
        return e
    }
    let F = {
        onDefaultTransitionIndicator: function() {
            return () => {}
        },
        onRecoverableError: p.onRecoverableError,
        onCaughtError: h.onCaughtError,
        onUncaughtError: h.onUncaughtError
    };
    async function H(e, t) {
        let r, n, l = await o;
        (0, E.setAppBuildId)(l.b);
        let i = Date.now(),
            a = (0, b.createMutableActionQueue)((0, v.createInitialRouterState)({
                navigatedAt: i,
                initialFlightData: l.f,
                initialCanonicalUrlParts: l.c,
                initialRenderedSearch: l.q,
                location: window.location
            }), e),
            c = (0, u.jsx)(I, {
                children: (0, u.jsx)(f.HeadManagerContext.Provider, {
                    value: {
                        appDir: !0
                    },
                    children: (0, u.jsx)(U, {
                        children: (0, u.jsx)(L, {
                            initialRSCPayload: l,
                            actionQueue: a,
                            webSocket: n,
                            staticIndicatorState: r
                        })
                    })
                })
            });
        "__next_error__" === document.documentElement.id ? d.default.createRoot(P, F).render(c) : s.default.startTransition(() => {
            d.default.hydrateRoot(P, c, { ...F,
                formState: x
            })
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 494553, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    let n = e.r(396517);
    e.r(597238), window.next.turbopack = !0, self.__webpack_hash__ = "";
    let o = e.r(5526);
    (0, n.appBootstrap)(t => {
        let {
            hydrate: r
        } = e.r(198569);
        r(o, t)
    }), ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);