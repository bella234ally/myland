(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 839598, e => {
    "use strict";
    e.i(247167);
    var t = e.i(271645),
        n = e.i(440383),
        o = e.i(207670),
        r = e.i(128473),
        i = e.i(951160);
    e.i(63335);
    var l = e.i(580251),
        a = e.i(401676),
        c = e.i(830731);
    let s = t.createContext(null);

    function u() {
        return {
            width: document.documentElement.clientWidth,
            height: window.innerHeight || document.documentElement.clientHeight
        }
    }
    var d = e.i(118696),
        m = e.i(737434);
    let f = {
        x: 0,
        y: 0,
        rotate: 0,
        scale: 1,
        flipX: !1,
        flipY: !1
    };
    var p = e.i(24308);

    function g(e, t, n, o) {
        let r = t + n,
            i = (n - o) / 2;
        if (n > o) {
            if (t > 0) return {
                [e]: i
            };
            if (t < 0 && r < o) return {
                [e]: -i
            }
        } else if (t < 0 || r > o) return {
            [e]: t < 0 ? i : -i
        };
        return {}
    }

    function v(e, t, n, o) {
        let {
            width: r,
            height: i
        } = u(), l = null;
        return e <= r && t <= i ? l = {
            x: 0,
            y: 0
        } : (e > r || t > i) && (l = { ...g("x", n, e, r),
            ...g("y", o, t, i)
        }), l
    }

    function h({
        src: e,
        isCustomPlaceholder: n,
        fallback: o
    }) {
        let [r, i] = (0, t.useState)(n ? "loading" : "normal"), l = (0, t.useRef)(!1), a = "error" === r;
        (0, t.useEffect)(() => {
            let t = !0;
            return new Promise(t => {
                if (!e) return void t(!1);
                let n = document.createElement("img");
                n.onerror = () => t(!1), n.onload = () => t(!0), n.src = e
            }).then(e => {
                !e && t && i("error")
            }), () => {
                t = !1
            }
        }, [e]), (0, t.useEffect)(() => {
            n && !l.current ? i("loading") : a && i("normal")
        }, [e]);
        let c = () => {
            i("normal")
        };
        return [e => {
            l.current = !1, "loading" === r && e ? .complete && (e.naturalWidth || e.naturalHeight) && (l.current = !0, c())
        }, a && o ? {
            src: o
        } : {
            onLoad: c,
            src: e
        }, r]
    }

    function y(e, t) {
        return Math.hypot(e.x - t.x, e.y - t.y)
    }

    function w(e) {
        let {
            prefixCls: n,
            icon: o,
            onClick: r
        } = e;
        return t.createElement("button", {
            className: `${n}-close`,
            onClick: r
        }, o)
    }

    function b(e) {
        let {
            prefixCls: n,
            showProgress: r,
            current: i,
            count: l,
            showSwitch: a,
            classNames: c,
            styles: s,
            icons: u,
            image: d,
            transform: m,
            countRender: f,
            actionsRender: p,
            scale: g,
            minScale: v,
            maxScale: h,
            onActive: y,
            onFlipY: w,
            onFlipX: b,
            onRotateLeft: x,
            onRotateRight: E,
            onZoomOut: C,
            onZoomIn: M,
            onClose: $,
            onReset: I
        } = e, {
            left: k,
            right: S,
            prev: N,
            next: L,
            flipY: A,
            flipX: z,
            rotateLeft: j,
            rotateRight: R,
            zoomOut: T,
            zoomIn: Y
        } = u, D = r && t.createElement("div", {
            className: `${n}-progress`
        }, f ? f(i + 1, l) : t.createElement("bdi", null, `${i+1} / ${l}`)), O = `${n}-actions-action`, P = ({
            type: e,
            disabled: n,
            onClick: r,
            icon: i
        }) => t.createElement("div", {
            key: e,
            className: (0, o.clsx)(O, `${O}-${e}`, {
                [`${O}-disabled`]: !!n
            }),
            onClick: r
        }, i), X = a ? P({
            icon: N ? ? k,
            onClick: () => y(-1),
            type: "prev",
            disabled: 0 === i
        }) : void 0, H = a ? P({
            icon: L ? ? S,
            onClick: () => y(1),
            type: "next",
            disabled: i === l - 1
        }) : void 0, B = P({
            icon: A,
            onClick: w,
            type: "flipY"
        }), Z = P({
            icon: z,
            onClick: b,
            type: "flipX"
        }), W = P({
            icon: j,
            onClick: x,
            type: "rotateLeft"
        }), F = P({
            icon: R,
            onClick: E,
            type: "rotateRight"
        }), V = P({
            icon: T,
            onClick: C,
            type: "zoomOut",
            disabled: g <= v
        }), G = P({
            icon: Y,
            onClick: M,
            type: "zoomIn",
            disabled: g === h
        }), U = t.createElement("div", {
            className: (0, o.clsx)(`${n}-actions`, c.actions),
            style: s.actions
        }, B, Z, W, F, V, G);
        return t.createElement("div", {
            className: (0, o.clsx)(`${n}-footer`, c.footer),
            style: s.footer
        }, D, p ? p(U, {
            icons: {
                prevIcon: X,
                nextIcon: H,
                flipYIcon: B,
                flipXIcon: Z,
                rotateLeftIcon: W,
                rotateRightIcon: F,
                zoomOutIcon: V,
                zoomInIcon: G
            },
            actions: {
                onActive: y,
                onFlipY: w,
                onFlipX: b,
                onRotateLeft: x,
                onRotateRight: E,
                onZoomOut: C,
                onZoomIn: M,
                onReset: I,
                onClose: $
            },
            transform: m,
            current: i,
            total: l,
            image: d
        }) : U)
    }

    function x(e) {
        let {
            prefixCls: n,
            onActive: r,
            current: i,
            count: l,
            icons: {
                left: a,
                right: c,
                prev: s,
                next: u
            }
        } = e, d = `${n}-switch`;
        return t.createElement(t.Fragment, null, t.createElement("div", {
            className: (0, o.clsx)(d, `${d}-prev`, {
                [`${d}-disabled`]: 0 === i
            }),
            onClick: () => r(-1)
        }, s ? ? a), t.createElement("div", {
            className: (0, o.clsx)(d, `${d}-next`, {
                [`${d}-disabled`]: i === l - 1
            }),
            onClick: () => r(1)
        }, u ? ? c))
    }

    function E() {
        return (E = Object.assign.bind()).apply(this, arguments)
    }
    let C = ({
            fallback: e,
            src: n,
            imgRef: o,
            ...r
        }) => {
            let [i, l] = h({
                src: n,
                fallback: e
            });
            return t.default.createElement("img", E({
                ref: e => {
                    o.current = e, i(e)
                }
            }, r, l))
        },
        M = e => {
            let {
                prefixCls: n,
                rootClassName: g,
                src: h,
                alt: M,
                imageInfo: $,
                fallback: I,
                movable: k = !0,
                onClose: S,
                open: N,
                afterOpenChange: L,
                icons: A = {},
                closeIcon: z,
                getContainer: j,
                current: R = 0,
                count: T = 1,
                countRender: Y,
                scaleStep: D = .5,
                minScale: O = 1,
                maxScale: P = 50,
                motionName: X = "fade",
                imageRender: H,
                imgCommonProps: B,
                actionsRender: Z,
                onTransform: W,
                onChange: F,
                classNames: V = {},
                styles: G = {},
                mousePosition: U,
                zIndex: Q
            } = e, _ = (0, t.useRef)(), J = (0, t.useContext)(s), K = J && T > 1, q = J && T >= 1, [ee, et] = (0, t.useState)(!0), {
                transform: en,
                resetTransform: eo,
                updateTransform: er,
                dispatchZoomChange: ei
            } = function(e, n, o, r) {
                let i = (0, t.useRef)(null),
                    l = (0, t.useRef)([]),
                    [a, c] = (0, t.useState)(f),
                    s = (e, t) => {
                        null === i.current && (l.current = [], i.current = (0, m.default)(() => {
                            c(e => {
                                let n = e;
                                return l.current.forEach(e => {
                                    n = { ...n,
                                        ...e
                                    }
                                }), i.current = null, r ? .({
                                    transform: n,
                                    action: t
                                }), n
                            })
                        })), l.current.push({ ...a,
                            ...e
                        })
                    };
                return {
                    transform: a,
                    resetTransform: e => {
                        c(f), (0, d.default)(f, a) || r ? .({
                            transform: f,
                            action: e
                        })
                    },
                    updateTransform: s,
                    dispatchZoomChange: (t, r, i, l, c) => {
                        let {
                            width: d,
                            height: m,
                            offsetWidth: f,
                            offsetHeight: p,
                            offsetLeft: g,
                            offsetTop: v
                        } = e.current, h = t, y = a.scale * t;
                        y > o ? (y = o, h = o / a.scale) : y < n && (h = (y = c ? y : n) / a.scale);
                        let w = l ? ? innerHeight / 2,
                            b = h - 1,
                            x = b * ((i ? ? innerWidth / 2) - a.x - g),
                            E = b * (w - a.y - v),
                            C = a.x - (x - b * d * .5),
                            M = a.y - (E - b * m * .5);
                        if (t < 1 && 1 === y) {
                            let e = f * y,
                                t = p * y,
                                {
                                    width: n,
                                    height: o
                                } = u();
                            e <= n && t <= o && (C = 0, M = 0)
                        }
                        s({
                            x: C,
                            y: M,
                            scale: y
                        }, r)
                    }
                }
            }(_, O, P, W), {
                isMoving: el,
                onMouseDown: ea,
                onWheel: ec
            } = function(e, n, o, r, i, l, a) {
                let {
                    rotate: c,
                    scale: s,
                    x: u,
                    y: d
                } = i, [m, f] = (0, t.useState)(!1), g = (0, t.useRef)({
                    diffX: 0,
                    diffY: 0,
                    transformX: 0,
                    transformY: 0
                }), h = e => {
                    o && m && l({
                        x: e.pageX - g.current.diffX,
                        y: e.pageY - g.current.diffY
                    }, "move")
                }, y = () => {
                    if (o && m) {
                        f(!1);
                        let {
                            transformX: t,
                            transformY: n
                        } = g.current;
                        if (u === t || d === n) return;
                        let o = e.current.offsetWidth * s,
                            r = e.current.offsetHeight * s,
                            {
                                left: i,
                                top: a
                            } = e.current.getBoundingClientRect(),
                            m = c % 180 != 0,
                            p = v(m ? r : o, m ? o : r, i, a);
                        p && l({ ...p
                        }, "dragRebound")
                    }
                };
                return (0, t.useEffect)(() => {
                    if (n) {
                        window.addEventListener("mouseup", y, !1), window.addEventListener("mousemove", h, !1);
                        try {
                            window.top !== window.self && (window.top.addEventListener("mouseup", y, !1), window.top.addEventListener("mousemove", h, !1))
                        } catch (e) {
                            (0, p.warning)(!1, `[rc-image] ${e}`)
                        }
                    }
                    return () => {
                        window.removeEventListener("mouseup", y), window.removeEventListener("mousemove", h);
                        try {
                            window.top ? .removeEventListener("mouseup", y), window.top ? .removeEventListener("mousemove", h)
                        } catch (e) {}
                    }
                }, [o, m, u, d, c, n]), {
                    isMoving: m,
                    onMouseDown: e => {
                        n && 0 === e.button && (e.preventDefault(), e.stopPropagation(), g.current = {
                            diffX: e.pageX - u,
                            diffY: e.pageY - d,
                            transformX: u,
                            transformY: d
                        }, f(!0))
                    },
                    onMouseMove: h,
                    onMouseUp: y,
                    onWheel: e => {
                        if (!o || 0 == e.deltaY) return;
                        let t = 1 + Math.min(Math.abs(e.deltaY / 100), 1) * r;
                        e.deltaY > 0 && (t = 1 / t), a(t, "wheel", e.clientX, e.clientY)
                    }
                }
            }(_, k, N, D, en, er, ei), {
                isTouching: es,
                onTouchStart: eu,
                onTouchMove: ed,
                onTouchEnd: em
            } = function(e, n, o, r, i, l, a) {
                let {
                    rotate: c,
                    scale: s,
                    x: u,
                    y: d
                } = i, [m, f] = (0, t.useState)(!1), p = (0, t.useRef)({
                    point1: {
                        x: 0,
                        y: 0
                    },
                    point2: {
                        x: 0,
                        y: 0
                    },
                    eventType: "none"
                }), g = e => {
                    p.current = { ...p.current,
                        ...e
                    }
                };
                return (0, t.useEffect)(() => {
                    let e = e => {
                        e.preventDefault()
                    };
                    return o && n && window.addEventListener("touchmove", e, {
                        passive: !1
                    }), () => {
                        window.removeEventListener("touchmove", e)
                    }
                }, [o, n]), {
                    isTouching: m,
                    onTouchStart: e => {
                        if (!n) return;
                        e.stopPropagation(), f(!0);
                        let {
                            touches: t = []
                        } = e;
                        t.length > 1 ? g({
                            point1: {
                                x: t[0].clientX,
                                y: t[0].clientY
                            },
                            point2: {
                                x: t[1].clientX,
                                y: t[1].clientY
                            },
                            eventType: "touchZoom"
                        }) : g({
                            point1: {
                                x: t[0].clientX - u,
                                y: t[0].clientY - d
                            },
                            eventType: "move"
                        })
                    },
                    onTouchMove: e => {
                        let {
                            touches: t = []
                        } = e, {
                            point1: n,
                            point2: o,
                            eventType: r
                        } = p.current;
                        if (t.length > 1 && "touchZoom" === r) {
                            let e = {
                                    x: t[0].clientX,
                                    y: t[0].clientY
                                },
                                r = {
                                    x: t[1].clientX,
                                    y: t[1].clientY
                                },
                                [i, l] = function(e, t, n, o) {
                                    let r = y(e, n),
                                        i = y(t, o);
                                    if (0 === r && 0 === i) return [e.x, e.y];
                                    let l = r / (r + i);
                                    return [e.x + l * (t.x - e.x), e.y + l * (t.y - e.y)]
                                }(n, o, e, r);
                            a(y(e, r) / y(n, o), "touchZoom", i, l, !0), g({
                                point1: e,
                                point2: r,
                                eventType: "touchZoom"
                            })
                        } else "move" === r && (l({
                            x: t[0].clientX - n.x,
                            y: t[0].clientY - n.y
                        }, "move"), g({
                            eventType: "move"
                        }))
                    },
                    onTouchEnd: () => {
                        if (!o) return;
                        if (m && f(!1), g({
                                eventType: "none"
                            }), r > s) return l({
                            x: 0,
                            y: 0,
                            scale: r
                        }, "touchZoom");
                        let t = e.current.offsetWidth * s,
                            n = e.current.offsetHeight * s,
                            {
                                left: i,
                                top: a
                            } = e.current.getBoundingClientRect(),
                            u = c % 180 != 0,
                            d = v(u ? n : t, u ? t : n, i, a);
                        d && l({ ...d
                        }, "dragRebound")
                    }
                }
            }(_, k, N, O, en, er, ei), {
                rotate: ef,
                scale: ep
            } = en;
            (0, t.useEffect)(() => {
                ee || et(!0)
            }, [ee]), (0, t.useEffect)(() => {
                N || eo("close")
            }, [N]);
            let eg = t.default.createElement(C, E({}, B, {
                    width: e.width,
                    height: e.height,
                    imgRef: _,
                    className: `${n}-img`,
                    alt: M,
                    style: {
                        transform: `translate3d(${en.x}px, ${en.y}px, 0) scale3d(${en.flipX?"-":""}${ep}, ${en.flipY?"-":""}${ep}, 1) rotate(${ef}deg)`,
                        transitionDuration: (!ee || es) && "0s"
                    },
                    fallback: I,
                    src: h,
                    onWheel: ec,
                    onMouseDown: ea,
                    onDoubleClick: e => {
                        N && (1 !== ep ? er({
                            x: 0,
                            y: 0,
                            scale: 1
                        }, "doubleClick") : ei(1 + D, "doubleClick", e.clientX, e.clientY))
                    },
                    onTouchStart: eu,
                    onTouchMove: ed,
                    onTouchEnd: em,
                    onTouchCancel: em
                })),
                ev = {
                    url: h,
                    alt: M,
                    ...$
                },
                eh = () => {
                    ei(1 + D, "zoomIn")
                },
                ey = () => {
                    ei(1 / (1 + D), "zoomOut")
                },
                ew = () => {
                    er({
                        rotate: ef + 90
                    }, "rotateRight")
                },
                eb = () => {
                    er({
                        rotate: ef - 90
                    }, "rotateLeft")
                },
                ex = () => {
                    er({
                        flipX: !en.flipX
                    }, "flipX")
                },
                eE = () => {
                    er({
                        flipY: !en.flipY
                    }, "flipY")
                },
                eC = () => {
                    eo("reset")
                },
                eM = e => {
                    let t = R + e;
                    t >= 0 && t <= T - 1 && (et(!1), eo(e < 0 ? "prev" : "next"), F ? .(t, R))
                },
                e$ = (0, l.useEvent)(e => {
                    if (N) {
                        let {
                            keyCode: t
                        } = e;
                        t === c.default.ESC && S ? .(), K && (t === c.default.LEFT ? eM(-1) : t === c.default.RIGHT && eM(1))
                    }
                });
            (0, t.useEffect)(() => {
                if (N) return window.addEventListener("keydown", e$), () => {
                    window.removeEventListener("keydown", e$)
                }
            }, [N]);
            let [eI, ek] = (0, t.useState)(!1);
            t.default.useEffect(() => {
                N && ek(!0)
            }, [N]);
            let [eS, eN] = (0, t.useState)(!1);
            (0, a.default)(() => {
                N && eN(!0)
            }, [N]);
            let eL = { ...G.body
            };
            return U && (eL.transformOrigin = `${U.x}px ${U.y}px`), t.default.createElement(i.default, {
                open: eS,
                getContainer: j,
                autoLock: eI
            }, t.default.createElement(r.default, {
                motionName: X,
                visible: eS && N,
                motionAppear: !0,
                motionEnter: !0,
                motionLeave: !0,
                onVisibleChanged: e => {
                    e || ek(!1), L ? .(e)
                }
            }, ({
                className: e,
                style: r
            }) => {
                let i = { ...G.root,
                    ...r
                };
                return Q && (i.zIndex = Q), t.default.createElement("div", {
                    className: (0, o.clsx)(n, g, V.root, e, {
                        [`${n}-moving`]: el
                    }),
                    style: i
                }, t.default.createElement("div", {
                    className: (0, o.clsx)(`${n}-mask`, V.mask),
                    style: G.mask,
                    onClick: S
                }), t.default.createElement("div", {
                    className: (0, o.clsx)(`${n}-body`, V.body),
                    style: eL
                }, H ? H(eg, {
                    transform: en,
                    image: ev,
                    ...J ? {
                        current: R
                    } : {}
                }) : eg), !1 !== z && null !== z && t.default.createElement(w, {
                    prefixCls: n,
                    icon: !0 === z ? A.close : z || A.close,
                    onClick: S
                }), K && t.default.createElement(x, {
                    prefixCls: n,
                    current: R,
                    count: T,
                    icons: A,
                    onActive: eM
                }), t.default.createElement(b, {
                    prefixCls: n,
                    showProgress: q,
                    current: R,
                    count: T,
                    showSwitch: K,
                    classNames: V,
                    styles: G,
                    image: ev,
                    transform: en,
                    icons: A,
                    countRender: Y,
                    actionsRender: Z,
                    scale: ep,
                    minScale: O,
                    maxScale: P,
                    onActive: eM,
                    onFlipY: eE,
                    onFlipX: ex,
                    onRotateLeft: eb,
                    onRotateRight: ew,
                    onZoomOut: ey,
                    onZoomIn: eh,
                    onClose: S,
                    onReset: eC
                }))
            }))
        };
    var $ = e.i(940487);
    let I = ["crossOrigin", "decoding", "draggable", "loading", "referrerPolicy", "sizes", "srcSet", "useMap", "alt"];

    function k() {
        return (k = Object.assign.bind()).apply(this, arguments)
    }
    let S = 0;

    function N() {
        return (N = Object.assign.bind()).apply(this, arguments)
    }
    let L = e => {
        let {
            prefixCls: r = "rc-image",
            previewPrefixCls: i = `${r}-preview`,
            rootClassName: l,
            className: a,
            style: c,
            classNames: u = {},
            styles: d = {},
            width: m,
            height: f,
            src: p,
            alt: g,
            placeholder: v,
            fallback: y,
            preview: w = !0,
            onClick: b,
            onError: x,
            ...E
        } = e, C = (0, t.useContext)(s), $ = !!w, {
            src: k,
            open: L,
            onOpenChange: A,
            cover: z,
            rootClassName: j,
            ...R
        } = w && "object" == typeof w ? w : {}, T = "object" == typeof z && z.placement && z.placement || "center", Y = "object" == typeof z && z.coverNode ? z.coverNode : z, [D, O] = (0, n.default)(!!L, L), [P, X] = (0, t.useState)(null), H = e => {
            O(e), A ? .(e)
        }, B = k ? ? p, [Z, W, F] = h({
            src: p,
            isCustomPlaceholder: v && !0 !== v,
            fallback: y
        }), V = (0, t.useMemo)(() => {
            let t = {};
            return I.forEach(n => {
                void 0 !== e[n] && (t[n] = e[n])
            }), t
        }, I.map(t => e[t])), G = function(e, n) {
            let [o] = t.useState(() => String(S += 1)), r = t.useContext(s), i = {
                data: n,
                canPreview: e
            };
            return t.useEffect(() => {
                if (r) return r.register(o, i)
            }, []), t.useEffect(() => {
                r && r.register(o, i)
            }, [e, n]), o
        }($, (0, t.useMemo)(() => ({ ...V,
            src: B
        }), [B, V]));
        return t.createElement(t.Fragment, null, t.createElement("div", N({}, E, {
            className: (0, o.clsx)(r, l, u.root, {
                [`${r}-error`]: "error" === F
            }),
            onClick: $ ? e => {
                let t = e.target.getBoundingClientRect(),
                    n = t.x + t.width / 2,
                    o = t.y + t.height / 2;
                C ? C.onPreview(G, B, n, o) : (X({
                    x: n,
                    y: o
                }), H(!0)), b ? .(e)
            } : b,
            style: {
                width: m,
                height: f,
                ...d.root
            }
        }), t.createElement("img", N({}, V, {
            className: (0, o.clsx)(`${r}-img`, {
                [`${r}-img-placeholder`]: !0 === v
            }, u.image, a),
            style: {
                height: f,
                ...d.image,
                ...c
            },
            ref: Z
        }, W, {
            width: m,
            height: f,
            onError: x
        })), "loading" === F && t.createElement("div", {
            "aria-hidden": "true",
            className: `${r}-placeholder`
        }, v), !1 !== z && $ && t.createElement("div", {
            className: (0, o.clsx)(`${r}-cover`, u.cover, `${r}-cover-${T}`),
            style: {
                display: c ? .display === "none" ? "none" : void 0,
                ...d.cover
            }
        }, Y)), !C && $ && t.createElement(M, N({
            "aria-hidden": !D,
            open: D,
            prefixCls: i,
            onClose: () => {
                H(!1)
            },
            mousePosition: P,
            src: B,
            alt: g,
            imageInfo: {
                width: m,
                height: f
            },
            fallback: y,
            imgCommonProps: V
        }, R, {
            classNames: u ? .popup,
            styles: d ? .popup,
            rootClassName: (0, o.clsx)(j, l)
        })))
    };
    L.PreviewGroup = ({
        previewPrefixCls: e = "rc-image-preview",
        classNames: o,
        styles: r,
        children: i,
        icons: l = {},
        items: a,
        preview: c,
        fallback: u
    }) => {
        let {
            open: d,
            onOpenChange: m,
            current: f,
            onChange: p,
            ...g
        } = c && "object" == typeof c ? c : {}, [v, h, y] = function(e) {
            let [n, o] = t.useState({}), r = t.useCallback((e, t) => (o(n => ({ ...n,
                [e]: t
            })), () => {
                o(t => {
                    let n = { ...t
                    };
                    return delete n[e], n
                })
            }), []);
            return [t.useMemo(() => e ? e.map(e => {
                if ("string" == typeof e) return {
                    data: {
                        src: e
                    }
                };
                let t = {};
                return Object.keys(e).forEach(n => {
                    ["src", ...I].includes(n) && (t[n] = e[n])
                }), {
                    data: t
                }
            }) : Object.keys(n).reduce((e, t) => {
                let {
                    canPreview: o,
                    data: r
                } = n[t];
                return o && e.push({
                    data: r,
                    id: t
                }), e
            }, []), [e, n]), r, !!e]
        }(a), [w, b] = (0, n.default)(0, f), [x, E] = (0, t.useState)(!1), {
            src: C,
            ...S
        } = v[w] ? .data || {}, [N, L] = (0, n.default)(!!d, d), A = (0, $.default)(e => {
            L(e), e !== N && m ? .(e, {
                current: w
            })
        }), [z, j] = (0, t.useState)(null), R = t.useCallback((e, t, n, o) => {
            let r = y ? v.findIndex(e => e.data.src === t) : v.findIndex(t => t.id === e);
            b(r < 0 ? 0 : r), A(!0), j({
                x: n,
                y: o
            }), E(!0)
        }, [v, y]);
        t.useEffect(() => {
            N ? x || b(0) : E(!1)
        }, [N]);
        let T = t.useMemo(() => ({
            register: h,
            onPreview: R
        }), [h, R]);
        return t.createElement(s.Provider, {
            value: T
        }, i, t.createElement(M, k({
            "aria-hidden": !N,
            open: N,
            prefixCls: e,
            onClose: () => {
                A(!1), j(null)
            },
            mousePosition: z,
            imgCommonProps: S,
            src: C,
            fallback: u,
            icons: l,
            current: w,
            count: v.length,
            onChange: (e, t) => {
                b(e), p ? .(e, t)
            }
        }, g, {
            classNames: o ? .popup,
            styles: r ? .popup
        })))
    };
    var A = e.i(711517),
        z = e.i(242064),
        j = e.i(321883),
        R = e.i(690121),
        T = e.i(122767),
        Y = e.i(613541);
    let D = (e, n, r, i, l, a, c) => {
        let [s] = (0, T.useZIndex)("ImagePreview", e ? .zIndex), [u, d] = (0, R.useMergedMask)(e ? .mask, n ? .mask, `${r}-preview`);
        return t.default.useMemo(() => {
            if (!e) return e;
            let {
                cover: t,
                getContainer: m,
                closeIcon: f,
                rootClassName: p
            } = e, {
                closeIcon: g
            } = n ? ? {};
            return {
                motionName: (0, Y.getTransitionName)(`${r}-preview`, "fade"),
                ...e,
                ...c ? {
                    cover: t ? ? c
                } : {},
                icons: a,
                getContainer: m ? ? l,
                zIndex: s,
                closeIcon: f ? ? g,
                rootClassName: (0, o.clsx)(i, p),
                mask: u,
                blurClassName: d.mask
            }
        }, [e, n, r, i, l, c, a, s, u, d])
    };

    function O(e) {
        let n = (0, t.useMemo)(() => "boolean" == typeof e ? e ? {} : null : e && "object" == typeof e ? e : {}, [e]);
        return (0, t.useMemo)(() => {
            let e;
            if (!n) return [n, "", ""];
            let {
                open: o,
                onOpenChange: r,
                cover: i,
                actionsRender: l,
                visible: a,
                onVisibleChange: c,
                rootClassName: s,
                maskClassName: u,
                mask: d,
                forceRender: m,
                destroyOnClose: f,
                toolbarRender: p,
                ...g
            } = n;
            r ? e = r : c && (e = (e, t) => {
                let {
                    current: n
                } = t || {};
                void 0 !== n ? c(e, !e, n) : c(e, !e)
            });
            let [v, h] = (0, t.isValidElement)(d) ? [d, void 0] : "boolean" == typeof d || d && "object" == typeof d ? [void 0, d] : [void 0, void 0];
            return [{ ...g,
                open: o ? ? a,
                onOpenChange: e,
                cover: i ? ? v,
                mask: h,
                actionsRender: l ? ? p
            }, s, u]
        }, [n])
    }
    var P = e.i(750963),
        X = e.i(876083),
        H = e.i(631829),
        B = {
            icon: {
                tag: "svg",
                attrs: {
                    viewBox: "64 64 896 896",
                    focusable: "false"
                },
                children: [{
                    tag: "defs",
                    attrs: {},
                    children: [{
                        tag: "style",
                        attrs: {}
                    }]
                }, {
                    tag: "path",
                    attrs: {
                        d: "M672 418H144c-17.7 0-32 14.3-32 32v414c0 17.7 14.3 32 32 32h528c17.7 0 32-14.3 32-32V450c0-17.7-14.3-32-32-32zm-44 402H188V494h440v326z"
                    }
                }, {
                    tag: "path",
                    attrs: {
                        d: "M819.3 328.5c-78.8-100.7-196-153.6-314.6-154.2l-.2-64c0-6.5-7.6-10.1-12.6-6.1l-128 101c-4 3.1-3.9 9.1 0 12.3L492 318.6c5.1 4 12.7.4 12.6-6.1v-63.9c12.9.1 25.9.9 38.8 2.5 42.1 5.2 82.1 18.2 119 38.7 38.1 21.2 71.2 49.7 98.4 84.3 27.1 34.7 46.7 73.7 58.1 115.8a325.95 325.95 0 016.5 140.9h74.9c14.8-103.6-11.3-213-81-302.3z"
                    }
                }]
            },
            name: "rotate-left",
            theme: "outlined"
        },
        Z = e.i(406575);

    function W() {
        return (W = Object.assign.bind()).apply(this, arguments)
    }
    let F = t.forwardRef((e, n) => t.createElement(Z.default, W({}, e, {
        ref: n,
        icon: B
    })));
    var V = {
        icon: {
            tag: "svg",
            attrs: {
                viewBox: "64 64 896 896",
                focusable: "false"
            },
            children: [{
                tag: "defs",
                attrs: {},
                children: [{
                    tag: "style",
                    attrs: {}
                }]
            }, {
                tag: "path",
                attrs: {
                    d: "M480.5 251.2c13-1.6 25.9-2.4 38.8-2.5v63.9c0 6.5 7.5 10.1 12.6 6.1L660 217.6c4-3.2 4-9.2 0-12.3l-128-101c-5.1-4-12.6-.4-12.6 6.1l-.2 64c-118.6.5-235.8 53.4-314.6 154.2A399.75 399.75 0 00123.5 631h74.9c-.9-5.3-1.7-10.7-2.4-16.1-5.1-42.1-2.1-84.1 8.9-124.8 11.4-42.2 31-81.1 58.1-115.8 27.2-34.7 60.3-63.2 98.4-84.3 37-20.6 76.9-33.6 119.1-38.8z"
                }
            }, {
                tag: "path",
                attrs: {
                    d: "M880 418H352c-17.7 0-32 14.3-32 32v414c0 17.7 14.3 32 32 32h528c17.7 0 32-14.3 32-32V450c0-17.7-14.3-32-32-32zm-44 402H396V494h440v326z"
                }
            }]
        },
        name: "rotate-right",
        theme: "outlined"
    };

    function G() {
        return (G = Object.assign.bind()).apply(this, arguments)
    }
    let U = t.forwardRef((e, n) => t.createElement(Z.default, G({}, e, {
            ref: n,
            icon: V
        }))),
        Q = {
            icon: {
                tag: "svg",
                attrs: {
                    viewBox: "64 64 896 896",
                    focusable: "false"
                },
                children: [{
                    tag: "path",
                    attrs: {
                        d: "M847.9 592H152c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h605.2L612.9 851c-4.1 5.2-.4 13 6.3 13h72.5c4.9 0 9.5-2.2 12.6-6.1l168.8-214.1c16.5-21 1.6-51.8-25.2-51.8zM872 356H266.8l144.3-183c4.1-5.2.4-13-6.3-13h-72.5c-4.9 0-9.5 2.2-12.6 6.1L150.9 380.2c-16.5 21-1.6 51.8 25.1 51.8h696c4.4 0 8-3.6 8-8v-60c0-4.4-3.6-8-8-8z"
                    }
                }]
            },
            name: "swap",
            theme: "outlined"
        };

    function _() {
        return (_ = Object.assign.bind()).apply(this, arguments)
    }
    let J = t.forwardRef((e, n) => t.createElement(Z.default, _({}, e, {
            ref: n,
            icon: Q
        }))),
        K = {
            icon: {
                tag: "svg",
                attrs: {
                    viewBox: "64 64 896 896",
                    focusable: "false"
                },
                children: [{
                    tag: "path",
                    attrs: {
                        d: "M637 443H519V309c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8v134H325c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h118v134c0 4.4 3.6 8 8 8h60c4.4 0 8-3.6 8-8V519h118c4.4 0 8-3.6 8-8v-60c0-4.4-3.6-8-8-8zm284 424L775 721c122.1-148.9 113.6-369.5-26-509-148-148.1-388.4-148.1-537 0-148.1 148.6-148.1 389 0 537 139.5 139.6 360.1 148.1 509 26l146 146c3.2 2.8 8.3 2.8 11 0l43-43c2.8-2.7 2.8-7.8 0-11zM696 696c-118.8 118.7-311.2 118.7-430 0-118.7-118.8-118.7-311.2 0-430 118.8-118.7 311.2-118.7 430 0 118.7 118.8 118.7 311.2 0 430z"
                    }
                }]
            },
            name: "zoom-in",
            theme: "outlined"
        };

    function q() {
        return (q = Object.assign.bind()).apply(this, arguments)
    }
    let ee = t.forwardRef((e, n) => t.createElement(Z.default, q({}, e, {
            ref: n,
            icon: K
        }))),
        et = {
            icon: {
                tag: "svg",
                attrs: {
                    viewBox: "64 64 896 896",
                    focusable: "false"
                },
                children: [{
                    tag: "path",
                    attrs: {
                        d: "M637 443H325c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h312c4.4 0 8-3.6 8-8v-60c0-4.4-3.6-8-8-8zm284 424L775 721c122.1-148.9 113.6-369.5-26-509-148-148.1-388.4-148.1-537 0-148.1 148.6-148.1 389 0 537 139.5 139.6 360.1 148.1 509 26l146 146c3.2 2.8 8.3 2.8 11 0l43-43c2.8-2.7 2.8-7.8 0-11zM696 696c-118.8 118.7-311.2 118.7-430 0-118.7-118.8-118.7-311.2 0-430 118.8-118.7 311.2-118.7 430 0 118.7 118.8 118.7 311.2 0 430z"
                    }
                }]
            },
            name: "zoom-out",
            theme: "outlined"
        };

    function en() {
        return (en = Object.assign.bind()).apply(this, arguments)
    }
    let eo = t.forwardRef((e, n) => t.createElement(Z.default, en({}, e, {
        ref: n,
        icon: et
    })));
    var er = e.i(687385);
    e.i(262370);
    var ei = e.i(135551),
        el = e.i(246422),
        ea = e.i(838378);
    let ec = e => ({
            position: e || "absolute",
            inset: 0
        }),
        es = (0, el.genStyleHooks)("Image", e => {
            let t = `${e.componentCls}-preview`,
                n = (0, ea.mergeToken)(e, {
                    previewCls: t,
                    imagePreviewSwitchSize: e.controlHeightLG
                });
            return [(e => {
                let {
                    componentCls: t
                } = e;
                return {
                    [t]: {
                        position: "relative",
                        display: "inline-block",
                        [`${t}-img`]: {
                            width: "100%",
                            height: "auto",
                            verticalAlign: "middle"
                        },
                        [`${t}-img-placeholder`]: {
                            backgroundColor: e.colorBgContainerDisabled,
                            backgroundImage: "url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTQuNSAyLjVoLTEzQS41LjUgMCAwIDAgMSAzdjEwYS41LjUgMCAwIDAgLjUuNWgxM2EuNS41IDAgMCAwIC41LS41VjNhLjUuNSAwIDAgMC0uNS0uNXpNNS4yODEgNC43NWExIDEgMCAwIDEgMCAyIDEgMSAwIDAgMSAwLTJ6bTguMDMgNi44M2EuMTI3LjEyNyAwIDAgMS0uMDgxLjAzSDIuNzY5YS4xMjUuMTI1IDAgMCAxLS4wOTYtLjIwN2wyLjY2MS0zLjE1NmEuMTI2LjEyNiAwIDAgMSAuMTc3LS4wMTZsLjAxNi4wMTZMNy4wOCAxMC4wOWwyLjQ3LTIuOTNhLjEyNi4xMjYgMCAwIDEgLjE3Ny0uMDE2bC4wMTUuMDE2IDMuNTg4IDQuMjQ0YS4xMjcuMTI3IDAgMCAxLS4wMi4xNzV6IiBmaWxsPSIjOEM4QzhDIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz48L3N2Zz4=')",
                            backgroundRepeat: "no-repeat",
                            backgroundPosition: "center center",
                            backgroundSize: "30%"
                        },
                        [`${t}-placeholder`]: { ...ec()
                        }
                    }
                }
            })(n), (e => {
                let {
                    componentCls: t,
                    motionDurationSlow: n,
                    colorTextLightSolid: o
                } = e;
                return {
                    [t]: {
                        [`${t}-cover`]: {
                            position: "absolute",
                            inset: 0,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            color: o,
                            background: new ei.FastColor("#000").setA(.3).toRgbString(),
                            cursor: "pointer",
                            opacity: 0,
                            transition: `opacity ${n}`
                        },
                        "&:hover": {
                            [`${t}-cover`]: {
                                opacity: 1
                            }
                        },
                        [`${t}-cover-top`]: {
                            inset: "0 0 auto 0",
                            justifyContent: "center"
                        },
                        [`${t}-cover-bottom`]: {
                            inset: "auto 0 0 0",
                            justifyContent: "center"
                        }
                    }
                }
            })(n), (e => {
                let {
                    motionEaseOut: t,
                    previewCls: n,
                    motionDurationSlow: o,
                    componentCls: r,
                    colorBgMask: i,
                    marginXL: l,
                    marginSM: a,
                    margin: c,
                    colorTextLightSolid: s,
                    paddingSM: u,
                    paddingLG: d,
                    previewOperationHoverColor: m,
                    previewOperationColorDisabled: f,
                    previewOperationSize: p,
                    zIndexPopup: g
                } = e, v = new ei.FastColor(i).setA(.1), h = v.clone().setA(.2), y = {
                    position: "absolute",
                    color: s,
                    backgroundColor: v.toRgbString(),
                    borderRadius: "50%",
                    padding: u,
                    outline: 0,
                    border: 0,
                    cursor: "pointer",
                    transition: `all ${o}`,
                    display: "flex",
                    fontSize: p,
                    "&:hover": {
                        backgroundColor: h.toRgbString()
                    },
                    "&:active": {
                        backgroundColor: v.toRgbString()
                    }
                };
                return {
                    [`${r}-preview`]: {
                        textAlign: "center",
                        inset: 0,
                        position: "fixed",
                        userSelect: "none",
                        zIndex: g,
                        [`${n}-mask`]: {
                            inset: 0,
                            position: "absolute",
                            background: i,
                            [`&${r}-preview-mask-blur`]: {
                                backdropFilter: "blur(4px)"
                            },
                            [`&${r}-preview-mask-hidden`]: {
                                display: "none"
                            }
                        },
                        [`${n}-body`]: { ...ec(),
                            "pointer-events": "none",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            "> *": {
                                pointerEvents: "auto"
                            }
                        },
                        [`${n}-img`]: {
                            maxWidth: "100%",
                            maxHeight: "70%",
                            verticalAlign: "middle",
                            transform: "scale3d(1, 1, 1)",
                            cursor: "grab",
                            transition: `transform ${o} ${t} 0s`
                        },
                        [`&-moving ${n}-img`]: {
                            cursor: "grabbing"
                        },
                        [`${n}-close`]: { ...y,
                            top: a,
                            insetInlineEnd: a
                        },
                        [`${n}-switch`]: { ...y,
                            top: "50%",
                            transform: "translateY(-50%)",
                            "&-disabled": {
                                "&, &:hover, &:active": {
                                    color: f,
                                    background: "transparent",
                                    cursor: "not-allowed"
                                }
                            },
                            "&-prev": {
                                insetInlineStart: a
                            },
                            "&-next": {
                                insetInlineEnd: a
                            }
                        },
                        [`${n}-footer`]: {
                            position: "absolute",
                            bottom: l,
                            left: {
                                _skip_check_: !0,
                                value: "50%"
                            },
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            color: e.previewOperationColor,
                            transform: "translateX(-50%)",
                            gap: c
                        },
                        [`${n}-actions`]: {
                            display: "flex",
                            gap: u,
                            padding: `0 ${(0,er.unit)(d)}`,
                            backgroundColor: v.toRgbString(),
                            borderRadius: 100,
                            fontSize: p,
                            "&-action": {
                                padding: u,
                                cursor: "pointer",
                                transition: `all ${o}`,
                                display: "flex",
                                [`&:not(${n}-actions-action-disabled):hover`]: {
                                    color: m
                                },
                                "&-disabled": {
                                    color: f,
                                    cursor: "not-allowed"
                                }
                            }
                        }
                    }
                }
            })(n), (e => {
                let {
                    previewCls: t,
                    motionDurationSlow: n
                } = e;
                return {
                    [t]: {
                        "&-fade": {
                            transition: `opacity ${n}`,
                            "&-enter, &-appear": {
                                opacity: 0,
                                [`${t}-body`]: {
                                    transform: "scale(0)"
                                },
                                "&-active": {
                                    opacity: 1,
                                    [`${t}-body`]: {
                                        transform: "scale(1)",
                                        transition: `transform ${n}`
                                    }
                                }
                            },
                            "&-leave": {
                                opacity: 1,
                                "&-active": {
                                    opacity: 0,
                                    [`${t}-body`]: {
                                        transform: "scale(0)",
                                        transition: `transform ${n}`
                                    }
                                }
                            }
                        }
                    }
                }
            })(n)]
        }, e => ({
            zIndexPopup: e.zIndexPopupBase + 80,
            previewOperationColor: new ei.FastColor(e.colorTextLightSolid).setA(.65).toRgbString(),
            previewOperationHoverColor: new ei.FastColor(e.colorTextLightSolid).setA(.85).toRgbString(),
            previewOperationColorDisabled: new ei.FastColor(e.colorTextLightSolid).setA(.25).toRgbString(),
            previewOperationSize: 1.5 * e.fontSizeIcon
        })),
        eu = {
            rotateLeft: t.createElement(F, null),
            rotateRight: t.createElement(U, null),
            zoomIn: t.createElement(ee, null),
            zoomOut: t.createElement(eo, null),
            close: t.createElement(P.default, null),
            left: t.createElement(X.default, null),
            right: t.createElement(H.default, null),
            flipX: t.createElement(J, null),
            flipY: t.createElement(J, {
                rotate: 90
            })
        },
        ed = e => {
            let {
                prefixCls: n,
                preview: r,
                className: i,
                rootClassName: l,
                style: a,
                styles: c,
                classNames: s,
                wrapperStyle: u,
                fallback: d,
                ...m
            } = e, {
                getPrefixCls: f,
                getPopupContainer: p,
                className: g,
                style: v,
                preview: h,
                styles: y,
                classNames: w,
                fallback: b
            } = (0, z.useComponentConfig)("image"), x = f("image", n), E = (0, j.default)(x), [C, M] = es(x, E), $ = (0, o.clsx)(l, C, M, E), I = (0, o.clsx)(i, C, g), [k, S, N] = O(r), [R, T, Y] = O(h), P = D(k, R, x, $, p, eu, !0), X = { ...e,
                preview: P
            }, H = t.useMemo(() => ({
                cover: (0, o.clsx)(Y, N),
                popup: {
                    root: (0, o.clsx)(T, S)
                }
            }), [S, N, T, Y]), {
                mask: B,
                blurClassName: Z
            } = P ? ? {}, W = t.useMemo(() => ({
                mask: (0, o.clsx)({
                    [`${x}-preview-mask-hidden`]: !B
                }, Z)
            }), [B, x, Z]), F = t.useMemo(() => [w, s, H, {
                popup: W
            }], [w, s, H, W]), [V, G] = (0, A.useMergeSemantic)(F, [y, {
                root: u
            }, c], {
                props: X
            }, {
                popup: {
                    _default: "root"
                }
            }), U = { ...v,
                ...a
            };
            return t.createElement(L, {
                prefixCls: x,
                preview: P || !1,
                rootClassName: $,
                className: I,
                style: U,
                fallback: d ? ? b,
                ...m,
                classNames: V,
                styles: G
            })
        };
    ed.PreviewGroup = ({
        previewPrefixCls: e,
        preview: n,
        classNames: r,
        styles: i,
        ...l
    }) => {
        let {
            getPrefixCls: a,
            getPopupContainer: c,
            direction: s,
            preview: u,
            classNames: d,
            styles: m
        } = (0, z.useComponentConfig)("image"), f = a("image", e), p = `${f}-preview`, g = (0, j.default)(f), [v, h] = es(f, g), y = (0, o.clsx)(v, h, g), [w, b, x] = O(n), [E, C, M] = O(u), $ = t.useMemo(() => ({ ...eu,
            left: "rtl" === s ? t.createElement(H.default, null) : t.createElement(X.default, null),
            right: "rtl" === s ? t.createElement(X.default, null) : t.createElement(H.default, null)
        }), [s]), I = D(w, E, f, y, c, eu), {
            mask: k,
            blurClassName: S
        } = I ? ? {}, N = { ...l,
            classNames: r,
            styles: i
        }, [R, T] = (0, A.useMergeSemantic)([d, r, {
            cover: (0, o.clsx)(M, x),
            popup: {
                root: (0, o.clsx)(C, b),
                mask: (0, o.clsx)({
                    [`${f}-preview-mask-hidden`]: !k
                }, S)
            }
        }], [m, i], {
            props: N
        }, {
            popup: {
                _default: "root"
            }
        });
        return t.createElement(L.PreviewGroup, {
            preview: I,
            previewPrefixCls: p,
            icons: $,
            ...l,
            classNames: R,
            styles: T
        })
    }, e.s(["default", 0, ed], 839598)
}]);